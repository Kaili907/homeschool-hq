[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"

$repositoryRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$ownedRelativeRoots = @(
  "adaptive-learning/mastery",
  "app/features/mastery",
  "tests/mastery"
)
$artifactRelativeDirectory = "adaptive-learning/mastery/artifacts"
$archiveRelativePath =
  "$artifactRelativeDirectory/manuel-academy-mastery-map-session-1.zip"
$archiveHashRelativePath = "$archiveRelativePath.sha256"
$manifestRelativePath = "$artifactRelativeDirectory/SOURCE-MANIFEST.sha256"
$verificationRelativePath = "tests/mastery/zip-verification-result.json"
$packageWorkRelativeRoot = "tests/mastery/.package-work"

function Get-NormalizedRelativePath {
  param([Parameter(Mandatory)][string]$AbsolutePath)

  $absolute = [System.IO.Path]::GetFullPath($AbsolutePath)
  $rootWithSeparator = $repositoryRoot.TrimEnd("\") + "\"
  if (-not $absolute.StartsWith(
    $rootWithSeparator,
    [System.StringComparison]::OrdinalIgnoreCase
  )) {
    throw "Cannot create a repository-relative path for: $absolute"
  }
  $relative = $absolute.Substring($rootWithSeparator.Length)
  return $relative.Replace("\", "/")
}

function Assert-PathInsideRepository {
  param([Parameter(Mandatory)][string]$AbsolutePath)

  $rootWithSeparator = $repositoryRoot.TrimEnd("\") + "\"
  $candidate = [System.IO.Path]::GetFullPath($AbsolutePath)
  if (-not $candidate.StartsWith(
    $rootWithSeparator,
    [System.StringComparison]::OrdinalIgnoreCase
  )) {
    throw "Refusing to use a package path outside the repository: $candidate"
  }
}

function Write-Utf8File {
  param(
    [Parameter(Mandatory)][string]$LiteralPath,
    [Parameter(Mandatory)][string]$Content
  )

  $utf8WithoutBom = [System.Text.UTF8Encoding]::new($false)
  [System.IO.File]::WriteAllText($LiteralPath, $Content, $utf8WithoutBom)
}

$archivePath = Join-Path $repositoryRoot $archiveRelativePath
$archiveHashPath = Join-Path $repositoryRoot $archiveHashRelativePath
$manifestPath = Join-Path $repositoryRoot $manifestRelativePath
$verificationPath = Join-Path $repositoryRoot $verificationRelativePath
$packageWorkRoot = Join-Path $repositoryRoot $packageWorkRelativeRoot

@(
  $archivePath,
  $archiveHashPath,
  $manifestPath,
  $verificationPath,
  $packageWorkRoot
) | ForEach-Object { Assert-PathInsideRepository $_ }

$excludedExactPaths = @(
  $archiveRelativePath,
  $archiveHashRelativePath,
  $manifestRelativePath,
  $verificationRelativePath,
  "tests/mastery/preview-server.out.log",
  "tests/mastery/preview-server.err.log"
)
$excludedPrefixes = @(
  "app/features/mastery/.preview-dist/",
  "$packageWorkRelativeRoot/"
)

$sourceFiles = foreach ($relativeRoot in $ownedRelativeRoots) {
  $absoluteRoot = Join-Path $repositoryRoot $relativeRoot
  if (-not (Test-Path -LiteralPath $absoluteRoot -PathType Container)) {
    throw "Owned source root is missing: $relativeRoot"
  }

  Get-ChildItem -LiteralPath $absoluteRoot -Recurse -File -Force |
    Where-Object {
      $relativePath = Get-NormalizedRelativePath $_.FullName
      $excludedByExactPath = $excludedExactPaths -contains $relativePath
      $excludedByPrefix = $false
      foreach ($prefix in $excludedPrefixes) {
        if ($relativePath.StartsWith(
          $prefix,
          [System.StringComparison]::OrdinalIgnoreCase
        )) {
          $excludedByPrefix = $true
          break
        }
      }
      -not $excludedByExactPath -and -not $excludedByPrefix
    }
}

$sourceFiles = @(
  $sourceFiles |
    Sort-Object { Get-NormalizedRelativePath $_.FullName }
)
if ($sourceFiles.Count -eq 0) {
  throw "No owned source files were selected for packaging."
}

$artifactDirectory = Split-Path -Parent $archivePath
New-Item -ItemType Directory -Path $artifactDirectory -Force | Out-Null

$manifestLines = foreach ($file in $sourceFiles) {
  $relativePath = Get-NormalizedRelativePath $file.FullName
  $hash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
  "$hash  $relativePath"
}
Write-Utf8File -LiteralPath $manifestPath -Content (
  ($manifestLines -join [Environment]::NewLine) + [Environment]::NewLine
)

$workId = [Guid]::NewGuid().ToString("N")
$workRoot = Join-Path $packageWorkRoot $workId
$stageRoot = Join-Path $workRoot "stage"
$expandedRoot = Join-Path $workRoot "expanded"
Assert-PathInsideRepository $workRoot

try {
  New-Item -ItemType Directory -Path $stageRoot -Force | Out-Null

  foreach ($file in $sourceFiles) {
    $relativePath = Get-NormalizedRelativePath $file.FullName
    $destination = Join-Path $stageRoot $relativePath
    $destinationDirectory = Split-Path -Parent $destination
    New-Item -ItemType Directory -Path $destinationDirectory -Force |
      Out-Null
    Copy-Item -LiteralPath $file.FullName -Destination $destination
  }

  $stagedManifestPath = Join-Path $stageRoot $manifestRelativePath
  New-Item -ItemType Directory -Path (
    Split-Path -Parent $stagedManifestPath
  ) -Force | Out-Null
  Copy-Item -LiteralPath $manifestPath -Destination $stagedManifestPath

  $expectedEntryPaths = @(
    $sourceFiles | ForEach-Object {
      Get-NormalizedRelativePath $_.FullName
    }
    $manifestRelativePath
    $verificationRelativePath
  ) | Sort-Object -Unique

  $verificationRecord = [ordered]@{
    status = "passed"
    verifiedAt = [DateTimeOffset]::UtcNow.ToString("o")
    archive = $archiveRelativePath
    manifest = $manifestRelativePath
    ownedRoots = $ownedRelativeRoots
    sourceFileCount = $sourceFiles.Count
    metadataEntryCount = 2
    archiveEntryCount = $expectedEntryPaths.Count
    exactEntrySetMatched = $true
    sourceHashesMatched = $true
    missingEntries = @()
    extraEntries = @()
    mismatchedHashes = @()
  }
  $stagedVerificationPath = Join-Path $stageRoot $verificationRelativePath
  New-Item -ItemType Directory -Path (
    Split-Path -Parent $stagedVerificationPath
  ) -Force | Out-Null
  Write-Utf8File -LiteralPath $stagedVerificationPath -Content (
    ($verificationRecord | ConvertTo-Json -Depth 5) +
      [Environment]::NewLine
  )

  if (Test-Path -LiteralPath $archivePath -PathType Leaf) {
    Remove-Item -LiteralPath $archivePath -Force
  }
  Compress-Archive -Path (Join-Path $stageRoot "*") `
    -DestinationPath $archivePath `
    -CompressionLevel Optimal

  New-Item -ItemType Directory -Path $expandedRoot -Force | Out-Null
  Expand-Archive -LiteralPath $archivePath -DestinationPath $expandedRoot

  $actualEntryPaths = @(
    Get-ChildItem -LiteralPath $expandedRoot -Recurse -File -Force |
      ForEach-Object {
        $expandedRootWithSeparator = $expandedRoot.TrimEnd("\") + "\"
        $_.FullName.Substring($expandedRootWithSeparator.Length).Replace(
          "\",
          "/"
        )
      } |
      Sort-Object -Unique
  )
  $missingEntries = @(
    $expectedEntryPaths | Where-Object { $_ -notin $actualEntryPaths }
  )
  $extraEntries = @(
    $actualEntryPaths | Where-Object { $_ -notin $expectedEntryPaths }
  )
  if ($missingEntries.Count -gt 0 -or $extraEntries.Count -gt 0) {
    throw (
      "Archive entry mismatch. Missing: {0}. Extra: {1}." -f
        ($missingEntries -join ", "),
        ($extraEntries -join ", ")
    )
  }

  $mismatchedHashes = @()
  foreach ($file in $sourceFiles) {
    $relativePath = Get-NormalizedRelativePath $file.FullName
    $expandedPath = Join-Path $expandedRoot $relativePath
    $sourceHash =
      (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash
    $expandedHash =
      (Get-FileHash -LiteralPath $expandedPath -Algorithm SHA256).Hash
    if ($sourceHash -ne $expandedHash) {
      $mismatchedHashes += $relativePath
    }
  }

  foreach ($metadataRelativePath in @(
    $manifestRelativePath,
    $verificationRelativePath
  )) {
    $stagePath = Join-Path $stageRoot $metadataRelativePath
    $expandedPath = Join-Path $expandedRoot $metadataRelativePath
    $stageHash = (Get-FileHash -LiteralPath $stagePath -Algorithm SHA256).Hash
    $expandedHash =
      (Get-FileHash -LiteralPath $expandedPath -Algorithm SHA256).Hash
    if ($stageHash -ne $expandedHash) {
      $mismatchedHashes += $metadataRelativePath
    }
  }

  if ($mismatchedHashes.Count -gt 0) {
    throw "Archive hash mismatch: $($mismatchedHashes -join ', ')"
  }

  Copy-Item -LiteralPath $stagedVerificationPath -Destination $verificationPath
  $archiveHash =
    (Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant()
  Write-Utf8File -LiteralPath $archiveHashPath -Content (
    "$archiveHash *$([System.IO.Path]::GetFileName($archivePath))" +
      [Environment]::NewLine
  )

  [pscustomobject]@{
    status = "passed"
    archive = $archiveRelativePath
    sha256 = $archiveHash
    sourceFileCount = $sourceFiles.Count
    archiveEntryCount = $expectedEntryPaths.Count
    sourceHashesMatched = $true
    exactEntrySetMatched = $true
  } | ConvertTo-Json -Depth 3
} finally {
  if (Test-Path -LiteralPath $workRoot -PathType Container) {
    $resolvedWorkRoot = (Resolve-Path -LiteralPath $workRoot).Path
    Assert-PathInsideRepository $resolvedWorkRoot
    Remove-Item -LiteralPath $resolvedWorkRoot -Recurse -Force
  }
  if (
    (Test-Path -LiteralPath $packageWorkRoot -PathType Container) -and
    -not (Get-ChildItem -LiteralPath $packageWorkRoot -Force)
  ) {
    $resolvedPackageWorkRoot =
      (Resolve-Path -LiteralPath $packageWorkRoot).Path
    Assert-PathInsideRepository $resolvedPackageWorkRoot
    Remove-Item -LiteralPath $resolvedPackageWorkRoot -Force
  }
}
