import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  applyParentPrecedence,
  handleVersion,
  isOpaqueId,
  projectLearner,
  validateEvent
} from "../../reconciliation/compatibility-probe.mjs";

const here = path.dirname(fileURLToPath(import.meta.url));
const reconciliation = path.resolve(here, "../../reconciliation");
const manifest = JSON.parse(await readFile(path.join(reconciliation, "reconciliation-manifest.json")));
const traces = JSON.parse(await readFile(path.join(reconciliation, "flow-traces.json")));

test("ZIP/checksum inventory declares all five inputs", () => {
  assert.equal(manifest.artifacts.length, 5);
  assert.equal(manifest.artifacts.filter((x) => x.availability === "missing").length, 4);
  assert.equal(manifest.artifacts.find((x) => x.id === "tutor-core-v0.2").manifestHashesPassed, 248);
});

test("ownership report remains audit-only", () => {
  assert.equal(manifest.package.productionMerge, false);
  assert.equal(manifest.package.finalAssembly, false);
});

test("contract and enum mappings remain blocked without canonical input", () => {
  assert.equal(manifest.package.status, "blocked_missing_authoritative_inputs");
  assert.ok(manifest.classifications.some((x) => x.classification === "BLOCKER"));
});

test("event mapping requires namespaced event name, opaque IDs and semver", () => {
  const seen = new Set();
  const good = {
    eventId: "A7mQ2xZ9pL4vN8kR",
    streamId: "S8dF4gH2jK7lP9qW",
    name: "study_session.started",
    version: "1.0.0"
  };
  assert.deepEqual(validateEvent(good, seen), { valid: true, errors: [] });
  assert.ok(validateEvent(good, seen).errors.includes("duplicateEventId"));
  assert.equal(validateEvent({ ...good, eventId: "lesson-one" }, new Set()).valid, false);
});

test("unknown or unsupported versions quarantine", () => {
  assert.equal(handleVersion({ version: "1.2.3" }).accepted, true);
  assert.equal(handleVersion({ version: "2.0.0" }).quarantineRequired, true);
  assert.equal(handleVersion({ version: "unknown" }).quarantineRequired, true);
});

test("all required flow/state traces are present", () => {
  assert.equal(traces.traces.length, 15);
  for (const trace of traces.traces) {
    assert.ok(trace.inputContract);
    assert.ok(trace.transitions.length >= 2);
    assert.ok(trace.events.length >= 1);
    assert.ok(trace.authority.length >= 1);
    assert.ok(trace.finalState);
  }
});

test("resume trace protects exact position and duplicate prevention", () => {
  const trace = traces.traces.find((x) => x.id === "exact-resume-after-refresh");
  assert.match(trace.finalState, /event IDs retained/);
  assert.ok(trace.events.includes("segment.resumed"));
});

test("parent precedence: safety then accommodation then hard maximum", () => {
  const result = applyParentPrecedence({
    gradeBandDefault: 40,
    engineRecommendation: 50,
    parentManualOverride: 45,
    parentHardMaximum: 35,
    requiredAccommodation: { maximumDuration: 30 },
    safetyMaximum: 25,
    minimumDuration: 10
  });
  assert.deepEqual(result, {
    status: "applied",
    duration: 25,
    reasons: ["required_accommodation", "safety_limit"]
  });
});

test("conflicting minimum routes to manual review", () => {
  assert.equal(applyParentPrecedence({
    gradeBandDefault: 20,
    requiredAccommodation: { maximumDuration: 10 },
    minimumDuration: 15
  }).status, "manual_review");
});

test("learner projection excludes PII, raw content and adult-private fields", () => {
  const projected = projectLearner({
    status: "active",
    adultPrivateNote: "private",
    rawAnswer: "answer",
    rawTranscript: "transcript",
    emailAddress: "learner@example.com",
    legalName: "Example",
    diagnosis: "unsupported",
    hiddenBehaviorScore: 1
  });
  assert.deepEqual(projected, { status: "active" });
});

test("low accuracy and retrieval failure lead to reteaching, not labeling", () => {
  const trace = traces.traces.find((x) => x.id === "retrieval-failure");
  assert.equal(trace.finalState, "reteaching");
  assert.match(trace.parentVisible, /no permanent label/);
});

test("approved water break is not treated as failure", () => {
  const trace = traces.traces.find((x) => x.id === "student-water-break");
  assert.equal(trace.finalState, "active");
  assert.ok(!JSON.stringify(trace).toLowerCase().includes("failure"));
});

test("opaque IDs reject human-readable permanent labels", () => {
  assert.equal(isOpaqueId("attention-problem-child"), false);
  assert.equal(isOpaqueId("A7mQ2xZ9pL4vN8kR"), true);
});

test("timezone trace requires learner-local date and household IANA timezone", () => {
  const trace = traces.traces.find((x) => x.id === "same-day-review-recommendation");
  assert.match(trace.finalState, /learner-local date/);
  assert.match(trace.finalState, /IANA timezone/);
});
