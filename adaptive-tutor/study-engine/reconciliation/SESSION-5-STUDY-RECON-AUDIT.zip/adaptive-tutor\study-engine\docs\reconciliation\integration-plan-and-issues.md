# Integration Plan, Merge Order, and Issues

This is an audit plan, not a production merge.

## Merge order after blockers clear

1. Re-receive all five source ZIPs and verify archive hashes, raw paths, manifests, ownership and collisions.
2. Freeze Session 1 schema registry, canonical IDs, enums, events, validation result, privacy projections and append-only persistence seam.
3. Add the Study-to–Tutor Core adapter without changing Tutor Core instructional authority.
4. Map Session 2 pacing outputs to the five canonical recommendation states.
5. Map Session 3 intents/presentation to canonical session, segment, timer, break and resume contracts.
6. Map Session 4 queue/calendar/parent/Romeo sidecars to canonical events and privacy projections.
7. Run compatibility, replay/idempotency, privacy, timezone/DST, browser accessibility and end-to-end flow tests.
8. Obtain control-room approval before any final assembly or production merge.

## Blocking issues

- **BLOCKER:** Session 1–4 ZIPs are missing; checksum, ownership, collision and exact diff work cannot run.
- **BLOCKER:** Tutor Core expected archive hash was not supplied, so authenticity cannot be compared.
- **BLOCKER:** Tutor Core retains and exports raw learner responses through its transcript snapshot.
- **BLOCKER:** Tutor Core PII redaction is materially incomplete.
- **BLOCKER:** Safety categories imply self-harm/abuse handling that runtime rules do not implement.
- **BLOCKER:** Exact refresh resume contradicts Core v0.2 behavior; refresh resets and snapshots cannot restore all mutable state.

## Required before final assembly

- Adult-private authorization and learner/parent/adult projections.
- Unsupported-version quarantine and privacy-safe validation errors.
- Canonical enum/event/ID maps from verified Session 1.
- Idempotent append-only events, replay protection and a versioned complete checkpoint.
- Parent precedence and conflict tests against actual Session 1/4 contracts.
- Same-day local-window, timezone/DST, queue/calendar and Romeo integration tests.
- Core referential, max-attempt, hint, independent-evidence and context invariants.

## Safe adapters

- Core slug/content IDs to canonical opaque persistence IDs.
- Core subject, assessment kind, source, purpose, confidence and instructional phase to verified canonical values.
- Tutor outcome to canonical derived evidence without raw answer/transcript.
- Session 2 pacing, Session 3 UI intents and Session 4 sidecars to Session 1 envelopes.

## Documentation only

- Core `dist/` and generated schemas are declared build artifacts.
- Distinguish instructional confidence from learner self-confidence.
- Distinguish Tutor phase `advance` from canonical mastery.

## Deferred production concerns

Database, authentication, storage, deployment, production calendar/dashboard behavior, psychometric calibration, localization and media-provider integration remain out of scope.
