# Verified Artifact Inventory and Ownership Report

Audit date: 2026-07-29 (America/New_York)

| Artifact | Expected SHA-256 | Calculated SHA-256 | Result |
|---|---|---|---|
| CARD-1-STUDY-CONTRACTS.zip | `79BA0F39688DB42197947915AA421BCA540AD060C072E898E86619F0A66B6F41` | — | Missing; not tested |
| Study-Engine ZIP | `979EEAC55DCDE6F47F684B0D6A9C7793FCB53E76F693D07E11A83B3FD9FFB770` | — | Missing; not tested |
| Study-UX ZIP | `9E3735FD09C2D19A991C3EB9FAE936204824F0A30C1EDDDAF1AC8A050314CD11` | — | Missing; not tested |
| Study-Integrations ZIP | `F4AB726446DA4129E3548919D91E56B85C93FF31BE63DEA692B0BA7926C39C1B` | — | Missing; not tested |
| Manuel Academy Adaptive Tutor Core v0.2 | Not supplied | `38205667D56CB4FCC5A8360F1F94098B5FA1D35AE71D22334AA1BC8D43ECC276` | Internally intact; authenticity comparison unavailable |

Tutor Core archive size is 296,306 bytes. Raw ZIP inspection, without extracting or normalizing paths, found 282 entries: 250 files and 32 directories under one package root. It has no exact or case-fold duplicate paths, traversal, absolute paths, backslashes, NULs, drive prefixes, or symlinks.

The embedded manifest identifies `@manuel-academy/adaptive-tutor-core@0.2.0`, declares 248 files and 1,133,026 bytes, and uses SHA-256. All 248 declared file sizes and hashes passed. The only unlisted files are the manifest itself and `docs/file-inventory.md`, both documented exclusions. Generated content comprises 164 `dist/` files plus two generated reports; all are declared.

The available archive remains within its Tutor Core root. Cross-package collisions and Sessions 1–4 ownership boundaries cannot be tested because those archives are unavailable. Session 5 authored files are confined to:

- `adaptive-tutor/study-engine/reconciliation/**`
- `adaptive-tutor/study-engine/docs/reconciliation/**`
- `adaptive-tutor/study-engine/tests/reconciliation/**`

No frozen package was modified or extracted into the repository.
