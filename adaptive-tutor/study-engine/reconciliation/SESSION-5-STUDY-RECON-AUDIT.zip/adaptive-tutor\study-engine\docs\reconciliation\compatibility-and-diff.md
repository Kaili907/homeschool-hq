# Contract Diff and Tutor Core Compatibility

## Evidence limitation

Session 1 canonical contracts and Sessions 2–4 adapters were not supplied. Exact field-, enum-, event-, and version-level comparisons are therefore blocked and are not reconstructed from summaries. The matrix below records Tutor Core facts and the reconciliation work that becomes mandatory when the packages arrive.

## Field-level matrix

| Concept | Tutor Core v0.2 evidence | Canonical requirement | Decision/classification |
|---|---|---|---|
| ID | `StableId`: lowercase hyphen slug, 3–120 | Stable opaque persistence IDs | Explicit ID map; **REQUIRED BEFORE FINAL ASSEMBLY** |
| Grade | `{min,max,label}`; no `min <= max` invariant | Grade band enum + grade metadata | Adapter and Core invariant request |
| Subject | `math`, `english`, `science`, `social-studies`, `general` | Canonical subject IDs | **SAFE ADAPTER**, values blocked |
| Task type | `multiple-choice`, `short-answer`, `sequencing` | Canonical task-type IDs | **SAFE ADAPTER**, values blocked |
| Evidence | source, purpose, outcome, score | Canonical StudyEvidence | Derived-only adapter; exclude raw input |
| Validation | `{ok,value}` or `{ok,issues[{path,message,value}]}` | Registry/version/quarantine and redacted errors | Wrapper required; omit issue `value` |
| Session | Instructional phase only | Study state, segment, resume and timers | Study orchestrator owns; no parallel state |
| Event | None | Name, opaque ID, semver, causation/idempotency | Required adapter |
| Time | UTC `Z` timestamp | UTC + learner-local civil time + household IANA zone | Required scheduling adapter |
| Persistence | In-memory snapshot; guide says persist nothing | Append-only event seam/checkpoint | Study owns; snapshot is noncanonical |
| Adult review | One review object; no authorization class | Adult-private authorization/projections | Required projection wrapper |
| Version | Program semver syntax | Supported-version routing/quarantine | Required wrapper |

## Enum mapping table

Exact Session 1 targets are unavailable. The following source enums must each map to one verified canonical value or be rejected; no source enum may become a second canonical enum.

| Core concept | Core values |
|---|---|
| Subject | `math`, `english`, `science`, `social-studies`, `general` |
| Evidence source | `diagnostic`, `guided-practice`, `independent-attempt`, `reassessment`, `teacher-observation` |
| Assessment purpose | `diagnostic`, `guided-practice`, `independent-mastery`, `reassessment` |
| Response outcome | `correct`, `partial`, `incorrect`, `unscored` |
| Tutor phase | `assessment`, `identify-missing-concept`, `teach-visually`, `guided-practice`, `independent-attempt`, `reassess`, `advance`, `reteach`, `escalated` |
| Confidence band | `very-low`, `low`, `developing`, `strong`, `insufficient-evidence` |

Instructional confidence is not learner self-confidence. `advance` is a Tutor phase, not a Study mastery outcome. Evidence source and assessment purpose overlap but are not interchangeable.

## Event mapping table

Tutor Core emits no canonical Study events. These proposed names are reserved reconciliation targets, not verified Session 1 declarations:

| Instructional occurrence | Proposed Study event | Authority |
|---|---|---|
| Core session starts | `study_session.started` | Session 1 |
| Core evaluates attempt | `assessment.evaluated` with derived evidence only | Tutor Core outcome, Session 1 envelope |
| Core requests reteach | `reteaching.recommended` | Tutor Core |
| Core reaches advance | `mastery_evidence.recorded` | Tutor Core evidence; canonical outcome still Session 1 |
| Core escalates | `adult_review.requested` | Tutor Core reason; Session 1 privacy/event |

## Tutor Core compatibility matrix

| Area | Result | Finding |
|---|---|---|
| Runtime schemas | Partial | Strict instructional validation exists; no Study registry, safe unknown handling or quarantine. |
| Assessment | Partial | Bounded demo evaluation; max attempts, referential option checks and broader rubric behavior are not enforced. |
| Mastery | Compatible through adapter | Multi-evidence, multi-context and uncertainty thresholds are positive; context currently uses item ID. |
| Misconceptions/prerequisites | Partial | Probabilistic, non-diagnostic model is positive; projection and referential invariants need strengthening. |
| Visual/spoken/accessibility | Partial | ARIA labels, fallback text, captions/transcript exist; no binding to no-audio or accommodation controls. |
| Guided/independent practice | Partial | Hint/independence concepts exist; runtime invariants and explicit context are incomplete. |
| Safety | Incompatible for production | Contract categories include self-harm and abuse/neglect, but runtime rules do not implement them. |
| Privacy | Incompatible at Study boundary | Snapshot exposes transcript/raw learner response; redaction is narrow. |
| Pause/break/resume | Missing | Refresh intentionally resets; no hydrate API and snapshot omits mutable attempt/score state. |
| Adult evidence | Partial | Useful aggregates exist; no adult-private authorization or projection schema. |

## Consolidated Core change requests

1. **BLOCKER:** Implement and test actual immediate-danger/self-harm and abuse/neglect routing, or stop representing those categories as implemented behavior.
2. **BLOCKER:** Remove raw learner input/transcript from exportable snapshots and create an explicitly redacted, retention-aware projection.
3. **BLOCKER:** Expand PII controls beyond email/phone/basic US address patterns; never expose `matchedText` or validation `value`.
4. **REQUIRED BEFORE FINAL ASSEMBLY:** Add a versioned, complete hydrate/checkpoint contract if exact resume is expected; include attempts, score buckets, revision and snapshot version.
5. **REQUIRED BEFORE FINAL ASSEMBLY:** Validate grade range, option references, unique/referential skill IDs, purpose/phase coherence, hint reveal rules, and max attempts.
6. **REQUIRED BEFORE FINAL ASSEMBLY:** Add explicit instructional context ID rather than treating item ID as a distinct context.
7. **SAFE ADAPTER:** Keep Study event/version/persistence/parent control concerns outside Core behind a canonical adapter.

## Adapter retirement plan

Inventory every provisional Session 2–4 type only after its verified ZIP is present. For each, map fields to Session 1, add a round-trip fixture, migrate callers, forbid new imports, and delete the provisional definition only during a later authorized production merge. Conflicting enums/events must route through one temporary adapter and may not survive as parallel authorities. No retirement is approved by this audit.
