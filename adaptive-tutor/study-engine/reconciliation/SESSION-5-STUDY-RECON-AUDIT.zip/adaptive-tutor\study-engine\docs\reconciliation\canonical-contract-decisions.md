# Canonical Contract Decision Record

Status: **blocked pending verified Sessions 1–4 packages**. The decisions below are reconciliation directives, not claims about missing source fields and not production approval.

| # | Topic | Decision | Status |
|---:|---|---|---|
| 1 | Package identity | Audit package is `@manuel-academy/study-recon-audit@0.1.0`; source package IDs/versions remain frozen. | Decided for audit only |
| 2 | Stable identifiers | Study persistence IDs must be opaque, stable, domain-scoped strings. Tutor Core slug `StableId` values cross only through explicit mapping. | Required |
| 3 | Grade | Canonical contract must separate grade-band enum from optional grade-level metadata. Core `{min,max,label}` is instructional metadata and must validate `min <= max`. | Pending S1 values |
| 4–6 | Subject/skill/task IDs | Use canonical Session 1 IDs. Map Core subject labels, skill slugs, and assessment kinds; never promote labels to persistence IDs. | Blocked |
| 7 | Session state | One Session 1 state vocabulary. Core phases remain instructional substates, not parallel session states. | Blocked for exact enum |
| 8–10 | Events/version | Namespaced event names, opaque unique event IDs, semver envelope; unsupported major versions quarantine. | Required |
| 11–12 | Segment/resume | Opaque segment ID; resume point contains session/segment ID, position, timer snapshot, last event ID, revision and saved-at instant. | Required |
| 13–16 | Timer/break/interruption | Session 1 owns enums; UX controls presentation. Approved breaks and technical interruptions never count as learner failure. | Exact mapping blocked |
| 17–26 | Evidence | Completion, accuracy, independence, confidence, effort, frustration, hint use, intervention and redirection remain distinct nullable measures with provenance. Missing data is not zero. Raw responses are excluded. | Required |
| 27 | Prerequisites | Tutor Core decides instructional prerequisite outcome; Study adapter records canonical evidence/event. | Required |
| 28 | Recommendation | Exactly `increase`, `maintain`, `decrease`, `insufficient_data`, `manual_review`. Unknown values reject/quarantine; no duplicate enum. | Decided |
| 29–30 | Overrides | Overrides include actor, scope, value, reason code, created-at, expires-at, source event and revision. Precedence is safety → required accommodation → parent hard maximum → parent explicit manual override → engine → grade default. | Approved with conflict rules below |
| 31–32 | Accessibility/accommodation | Accessibility preferences affect presentation. Required accommodations constrain behavior and outrank parent/engine preferences. Do not expose diagnoses. | Required |
| 33–36 | Review/time | Review interval is duration plus provenance; same-day retry is a learner-local civil-date/window plus household IANA timezone and resolved instants. | Required |
| 37–39 | Integrations | Calendar/review/Romeo mappings are sidecar proposals. Preserve opaque external references; do not copy names/emails. | Exact mapping blocked |
| 40–42 | Privacy | Adult-private data requires authorization and separate projection. Exclude PII, raw answers and raw transcripts from Study events/evidence. | Required |
| 43–44 | Validation | Registry key is schema ID + semver. Result is `{valid,schemaId,schemaVersion,errors,unsupportedVersion,quarantineRequired}` with redacted errors. | Required |
| 45–48 | Persistence/version | Persistence seam is append-only, idempotent and optimistic-concurrency protected. Sidecar hooks propose changes. Unsupported versions are isolated in quarantine. | Required |
| 49 | Core changes | Consolidated separately; Study audit does not edit Core. | Recorded |
| 50 | Test dependencies | Reconciliation probes use Node built-ins only and are browser-independent. Production/browser suites remain unassessed. | Audit decided |

## Parent precedence and conflicts

The proposed precedence is approved. A lower layer cannot weaken a higher layer.

- Minimum duration is a planning floor, never authority to violate safety, an accommodation maximum, or a parent hard maximum. An impossible floor/ceiling combination becomes `manual_review`.
- Maximum duration is the minimum of all applicable higher-authority maxima.
- Required breaks are additive constraints. A parent may request more breaks, not remove required ones.
- Break length must satisfy safety/accommodation minima and maxima. Empty intersection becomes `manual_review`.
- Hidden timer, reduced motion, and no-audio are presentation/accessibility constraints and do not change evidence semantics. No-audio requires text/caption fallback.
- Adult review flags are preserved until an authorized adult resolves them; automatic recommendation changes do not clear them.
- Parent rejection records a decision event and blocks that recommendation revision. New evidence may create a new recommendation, not silently revive the rejected one.
- Conflicting settings choose the higher-precedence compatible value; irreconcilable constraints stop automatic application and emit a redacted manual-review reason.
