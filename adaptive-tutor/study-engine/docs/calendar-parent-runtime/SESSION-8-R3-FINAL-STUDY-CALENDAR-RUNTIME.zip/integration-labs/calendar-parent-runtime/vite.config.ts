import { defineConfig } from "vite";

export default defineConfig({
  root: ".",
  base: "./",
  publicDir: false,
  build: {
    outDir: "dist",
    emptyOutDir: true,
    sourcemap: true,
  },
  server: {
    host: "127.0.0.1",
    port: 4188,
    strictPort: true,
  },
  preview: {
    host: "127.0.0.1",
    port: 4189,
    strictPort: true,
  },
});
