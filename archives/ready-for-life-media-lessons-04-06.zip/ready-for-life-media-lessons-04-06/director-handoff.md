# Director Handoff — RFL-M2 Lessons 04–06

## Package decision

**Status:** Specifications, narration, captions, transcripts, and manifests complete. Visual binaries remain blocked.

## Review first

1. Confirm the written Character Bible v1.1 is the final visual authority for Jordan, Eli, Sofia, and Ms. Rivera.
2. Supply or mount individual canonical reference images for each of those characters that match the written bible exactly.
3. Listen to the three provisional Maya narration tracks and either approve the voice or replace only the MP3/VTT timing pair while preserving transcript copy.

## Generate stills

Use the `production-specs/openai-images.json` file inside each lesson with OpenAI Images. Produce:

- `04-sorting-clothing/cover.webp`
- `04-sorting-clothing/thumbnail.webp`
- `05-washer-and-dryer-safety/cover.webp`
- `05-washer-and-dryer-safety/thumbnail.webp`
- `06-fold-hang-and-put-away/cover.webp`
- `06-fold-hang-and-put-away/thumbnail.webp`

Approve each cover before deriving its thumbnail. Reject any identity drift, wardrobe drift, extra person, malformed hand, added object, generated text, logo, or unsafe scene.

## Generate video

Use `production-specs/kling-3-omni.json`. Generate one clip at a time in sequence. Do not batch past an unapproved continuity gate.

For every Lesson 05 clip, Ms. Rivera must be clearly visible and stationary. She may naturally blink, but may not point, gesture, carry, touch, speak, or perform a second task.

Reject any clip showing a child climbing into an appliance, reaching deeply into it, interacting with plugs/outlets/mechanisms, treating detergent pods as toys, mixing chemicals, or implying that supervision is a failure of independence.

## Finalize binaries

- Still targets: WebP, 16:9; cover 1920×1080; thumbnail 640×360.
- Video targets: MP4/H.264, 1920×1080, 16:9, five seconds unless the approved action requires a slightly shorter natural finish; no embedded speech, music, narration, captions, logo, or watermark.
- Place files only at the stable paths listed in each manifest.
- Update visual asset statuses from `blocked` to `produced` and add duration, resolution, codec, byte size, and SHA-256.

## Final validation gate

Rerun `tools/validate_media_package.py`. Release only when every current `BLOCKED` visual check becomes `PASS`, with no `FAIL` results.
