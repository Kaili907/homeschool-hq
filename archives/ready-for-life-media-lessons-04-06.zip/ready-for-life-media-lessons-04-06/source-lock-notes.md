# Source Lock and Reconciliation Notes

## Authoritative written sources

1. Ready for Life — Master Curriculum v1
2. Ready for Life — Synthetic Character Bible v1.1
3. Ready for Life — Lesson Cast Map v1.1
4. Ready for Life — Media Production Bible v1, used for stable media IDs, paths, physical actions, main objects, captions, and shot sequence

## Cast application

- Lesson 04 active learner: Jordan; narrator: Maya; no visible guardian required.
- Lesson 05 active learner: Eli; visible guardian: Ms. Rivera; narrator: Maya.
- Lesson 06 active learner: Sofia; narrator: Maya; no visible guardian required.

## Reconciliation performed without rewriting lessons

The older media-production storyboard names Maya in its shot prompts. The approved later cast map assigns Jordan, Eli, and Sofia to Lessons 04–06. This package changes only the depicted learner identity and required stationary guardian context. It preserves all approved lesson IDs, media IDs, ordered shot actions, main objects, narration copy, caption copy, and lowercase ASCII paths.

The old Lesson 05 storyboard sometimes described an adult hand pointing. The later cast-map guardian rule is stricter: Ms. Rivera must be fully visible and physically still. The production specifications therefore remove pointing and require her to stand stationary. This is a safety/continuity reconciliation, not a lesson rewrite.

## Reference conflict

Composite character-reference images found in the project depict wardrobe and appearance details that conflict with the newer written Character Bible v1.1. The written v1.1 bible is treated as authoritative. No visual binary was generated from conflicting references.
