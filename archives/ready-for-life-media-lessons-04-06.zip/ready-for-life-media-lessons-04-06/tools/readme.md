Run `python3 tools/validate_media_package.py` from any directory. It writes `validation-results.json` and `validation-report.md` at the package root.
