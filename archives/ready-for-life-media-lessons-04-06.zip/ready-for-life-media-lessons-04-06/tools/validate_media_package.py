#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, re, subprocess, sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
results = []

def add(check, status, details):
    results.append({'check': check, 'status': status, 'details': details})

def load_json(path):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as e:
        add(f'json:{path.relative_to(root)}', 'FAIL', str(e)); return None

batch = load_json(root/'batch-media-manifest.json')
blocked = load_json(root/'blocked-assets.json')
if batch:
    add('exactly-three-lessons', 'PASS' if len(batch['lessons'])==3 else 'FAIL', str(len(batch['lessons'])))
    add('ordered-lessons-04-06', 'PASS' if [x['order'] for x in batch['lessons']]==['04','05','06'] else 'FAIL', str([x['order'] for x in batch['lessons']]))

ascii_bad=[]
for p in root.rglob('*'):
    rel=str(p.relative_to(root)).replace('\\','/')
    if any(ord(c)>127 for c in rel) or rel.lower()!=rel:
        ascii_bad.append(rel)
add('lowercase-ascii-filenames', 'PASS' if not ascii_bad else 'FAIL', ascii_bad or 'all paths lowercase ASCII')

vtt_bad=[]
for p in root.rglob('*.vtt'):
    txt=p.read_text(encoding='utf-8')
    if not txt.startswith('WEBVTT') or '-->' not in txt:
        vtt_bad.append(str(p.relative_to(root)))
add('webvtt-basic-validity', 'PASS' if not vtt_bad else 'FAIL', vtt_bad or f'{len(list(root.rglob("*.vtt")))} VTT files parsed')

mp3_bad=[]
for p in root.rglob('*.mp3'):
    try:
        data=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_name,sample_rate,channels','-of','json',str(p)],text=True))
        s=data['streams'][0]
        if s.get('codec_name')!='mp3' or s.get('sample_rate')!='48000' or s.get('channels')!=1:
            mp3_bad.append({'path':str(p.relative_to(root)),'stream':s})
    except Exception as e: mp3_bad.append({'path':str(p.relative_to(root)),'error':str(e)})
add('narration-audio-technical', 'PASS' if not mp3_bad else 'FAIL', mp3_bad or '3 MP3 files: MP3, 48 kHz, mono')

manifest_bad=[]; clip_count=0; guardian_bad=[]; cast={}
for p in root.glob('*/media-manifest.json'):
    m=load_json(p)
    if not m: continue
    cast[m['order']]=m['cast']
    clips=m['assets']['clips']; clip_count += len(clips)
    for c in clips:
        if c.get('actionCount')!=1 or c.get('mainObjectCount')!=1: manifest_bad.append(c['mediaId'])
        if m['order']=='05' and not (c.get('guardianVisibility')=='guardian-required' and c.get('guardianMotion')=='stationary' and c.get('visibleGuardian')=='ms-rivera'):
            guardian_bad.append(c['mediaId'])
add('clip-count-12', 'PASS' if clip_count==12 else 'FAIL', str(clip_count))
add('one-action-one-main-object', 'PASS' if not manifest_bad else 'FAIL', manifest_bad or 'all 12 clips')
add('cast-map', 'PASS' if cast.get('04',{}).get('primaryLearner')=='jordan' and cast.get('05',{}).get('primaryLearner')=='eli' and cast.get('06',{}).get('primaryLearner')=='sofia' else 'FAIL', cast)
add('lesson-05-guardian-visible-stationary', 'PASS' if not guardian_bad else 'FAIL', guardian_bad or 'all four Lesson 05 clips')

prohibited=[]
for p in root.rglob('*.json'):
    txt=p.read_text(encoding='utf-8').lower()
    for phrase in ['adult hand points','detergent pods as toys','child climbs into']:
        if phrase in txt: prohibited.append({'path':str(p.relative_to(root)),'phrase':phrase})
add('prohibited-prompt-patterns', 'PASS' if not prohibited else 'FAIL', prohibited or 'none found')

blocked_count=blocked.get('blockedCount',0) if blocked else 0
add('visual-binary-presence', 'BLOCKED' if blocked_count==18 else 'FAIL', f'{blocked_count} explicitly blocked visual assets; no placeholders accepted')
add('character-continuity-visual', 'BLOCKED', 'Requires generated stills/videos and canonical individual references')
add('appliance-safety-visual', 'BLOCKED', 'Prompt/spec validation passed; binary frame review not possible')
add('guardian-visibility-visual', 'BLOCKED', 'Metadata/spec validation passed; binary frame review not possible')
add('resolution-aspect-ratio-visual', 'BLOCKED', 'Targets are locked in specs; binaries absent')
add('unintended-people-objects-hands-text-logos', 'BLOCKED', 'Requires frame-by-frame binary review')

fails=[r for r in results if r['status']=='FAIL']
blocks=[r for r in results if r['status']=='BLOCKED']
overall='FAIL' if fails else ('SPECIFICATION_COMPLETE_WITH_BLOCKED_VISUAL_BINARIES' if blocks else 'PASS')
out={'overall':overall,'results':results,'failCount':len(fails),'blockedCheckCount':len(blocks)}
(root/'validation-results.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
lines=['# RFL-M2 Validation Report — Lessons 04–06','',f'**Overall result:** {overall}','',f'- Failed checks: {len(fails)}',f'- Blocked visual checks: {len(blocks)}','', '| Check | Result | Details |','|---|---|---|']
for r in results:
    details=json.dumps(r['details'],ensure_ascii=False) if not isinstance(r['details'],str) else r['details']
    details=details.replace('|','\\|').replace('\n',' ')
    lines.append(f"| `{r['check']}` | **{r['status']}** | {details} |")
lines += ['', '## Interpretation', '', 'All package structure, narration, caption, transcript, cast-map, guardian-metadata, action-count, object-count, path, and prompt-safety checks pass. Visual-only checks remain blocked because the six WebP and twelve MP4 binaries were not truthfully available to package.', '', '## Boundary confirmation', '', '- No GitHub, Supabase, Netlify, Lovable, database, storage, identity, authentication, or progress-sync change was made.']
(root/'validation-report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps(out,indent=2))
sys.exit(1 if fails else 0)
