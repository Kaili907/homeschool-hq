# RFL-M2 Validation Report — Lessons 04–06

**Overall result:** SPECIFICATION_COMPLETE_WITH_BLOCKED_VISUAL_BINARIES

- Failed checks: 0
- Blocked visual checks: 6

| Check | Result | Details |
|---|---|---|
| `exactly-three-lessons` | **PASS** | 3 |
| `ordered-lessons-04-06` | **PASS** | ['04', '05', '06'] |
| `lowercase-ascii-filenames` | **PASS** | all paths lowercase ASCII |
| `webvtt-basic-validity` | **PASS** | 15 VTT files parsed |
| `narration-audio-technical` | **PASS** | 3 MP3 files: MP3, 48 kHz, mono |
| `clip-count-12` | **PASS** | 12 |
| `one-action-one-main-object` | **PASS** | all 12 clips |
| `cast-map` | **PASS** | {"04": {"primaryLearner": "jordan", "visibleGuardian": null, "narrator": "maya"}, "05": {"primaryLearner": "eli", "visibleGuardian": "ms-rivera", "narrator": "maya"}, "06": {"primaryLearner": "sofia", "visibleGuardian": null, "narrator": "maya"}} |
| `lesson-05-guardian-visible-stationary` | **PASS** | all four Lesson 05 clips |
| `prohibited-prompt-patterns` | **PASS** | none found |
| `visual-binary-presence` | **BLOCKED** | 18 explicitly blocked visual assets; no placeholders accepted |
| `character-continuity-visual` | **BLOCKED** | Requires generated stills/videos and canonical individual references |
| `appliance-safety-visual` | **BLOCKED** | Prompt/spec validation passed; binary frame review not possible |
| `guardian-visibility-visual` | **BLOCKED** | Metadata/spec validation passed; binary frame review not possible |
| `resolution-aspect-ratio-visual` | **BLOCKED** | Targets are locked in specs; binaries absent |
| `unintended-people-objects-hands-text-logos` | **BLOCKED** | Requires frame-by-frame binary review |

## Interpretation

All package structure, narration, caption, transcript, cast-map, guardian-metadata, action-count, object-count, path, and prompt-safety checks pass. Visual-only checks remain blocked because the six WebP and twelve MP4 binaries were not truthfully available to package.

## Boundary confirmation

- No GitHub, Supabase, Netlify, Lovable, database, storage, identity, authentication, or progress-sync change was made.
