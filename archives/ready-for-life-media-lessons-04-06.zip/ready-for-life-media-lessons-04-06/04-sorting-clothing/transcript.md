# Ready for Life — Lesson 04 Narration Transcript

**Lesson ID:** `ready-for-life-v1-lesson-04-sorting-clothing`  
**Title:** Sorting Clothing  
**Narrator:** Maya  
**Language:** English (`en`)  
**Core principle:** Finish the loop.

## Transcript

Sorting clothing protects items and prepares the next laundry step. Check every pocket before choosing a category. Do not reach blindly into an unknown pocket. Ask an adult to handle sharp items, batteries, electronics, medication, or anything unknown. Notice the care label. You do not need to memorize every symbol. Follow your household system for lights, darks, towels, and special-care items. When you are unsure, place the item in ask-first instead of guessing. Return pocket contents, move the baskets, clear the surface, and finish the loop.

## Production note

Narration is delivered separately from visual media. No learner or guardian lip-sync is permitted.
