# Ready for Life — Lesson 06 Narration Transcript

**Lesson ID:** `ready-for-life-v1-lesson-06-fold-hang-and-put-away`  
**Title:** Fold, Hang, and Put Away  
**Narrator:** Maya  
**Language:** English (`en`)  
**Core principle:** Finish the loop.

## Transcript

Dry clothing is not the end of the laundry job. Each item still needs to reach its home. Choose whether an approved item should be folded, hung, placed flat, or set aside to ask first. A useful fold helps an item fit and stay easy to find. It does not need perfect edges. Group items by destination so you can put away one group at a time. Ask for help with high storage, stuck drawers, hot tools, or unfamiliar fabrics. Check the basket and floor so no clean clothing remains behind. Return the empty basket to its home. That finishes the laundry loop.

## Production note

Narration is delivered separately from visual media. No learner or guardian lip-sync is permitted.
