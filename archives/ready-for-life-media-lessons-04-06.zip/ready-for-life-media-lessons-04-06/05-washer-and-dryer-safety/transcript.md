# Ready for Life — Lesson 05 Narration Transcript

**Lesson ID:** `ready-for-life-v1-lesson-05-washer-and-dryer-safety`  
**Title:** Washer and Dryer Safety  
**Narrator:** Maya  
**Language:** English (`en`)  
**Core principle:** Finish the loop.

## Transcript

Washers and dryers are powerful machines. A guardian stays present and responsible. Never climb into, sit in, or hide in an appliance. Never mix cleaning products. Keep hands and the floor dry. Use only the household-approved product and amount. Load only approved clothing and do not pack the machine tightly. Ask the guardian to confirm the machine setting before the cycle starts. For leaks, sparks, smoke, burning smells, damaged cords, unusual movement, or errors: stop, step back, and get an adult. Store the product, return the basket, check the floor, and finish the loop.

## Production note

Narration is delivered separately from visual media. No learner or guardian lip-sync is permitted.
