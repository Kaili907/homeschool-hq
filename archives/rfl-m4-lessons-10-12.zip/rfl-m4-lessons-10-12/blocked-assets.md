# Blocked Assets — Lessons 10–12

**Blocked binary total:** 22

- Covers: 3
- Thumbnails: 3
- Kling 3 Omni clips: 16

No zero-byte or fabricated `.webp` or `.mp4` file was created.

## Why they are blocked

The connected OpenArt account and Manuel Academy Media Lab project are available, and Kling 3 Omni is listed. However, the project exposes no uploaded reference assets in this run. The approved cast is reference-locked; text-only generation would risk redesigning Maya, Jordan, Sofia, Eli, Niko, or Ms. Rivera.

OpenAI Images likewise does not have the approved visual reference binaries attached in this conversation. Covers and thumbnails therefore remain blocked rather than being regenerated from descriptions alone.

The connected Kling action is asynchronous and does not provide a packageable MP4 binary during this single production run. No generation was submitted because the required element references were absent.

**OpenArt credits spent by this run:** 0

## Expected blocked paths

- `lessons/10-hunger-boredom-and-body-signals/cover.webp` — rfl-v1-l10-cover
- `lessons/10-hunger-boredom-and-body-signals/thumbnail.webp` — rfl-v1-l10-thumbnail
- `lessons/10-hunger-boredom-and-body-signals/clips/01-read-signal-card.mp4` — rfl-v1-l10-clip-01-read-signal-card
- `lessons/10-hunger-boredom-and-body-signals/clips/02-drink-water.mp4` — rfl-v1-l10-clip-02-drink-water
- `lessons/10-hunger-boredom-and-body-signals/clips/03-choose-snack.mp4` — rfl-v1-l10-clip-03-choose-snack
- `lessons/10-hunger-boredom-and-body-signals/clips/04-choose-rest-card.mp4` — rfl-v1-l10-clip-04-choose-rest-card
- `lessons/11-building-a-fueling-meal/cover.webp` — rfl-v1-l11-cover
- `lessons/11-building-a-fueling-meal/thumbnail.webp` — rfl-v1-l11-thumbnail
- `lessons/11-building-a-fueling-meal/clips/01-add-protein.mp4` — rfl-v1-l11-clip-01-add-protein
- `lessons/11-building-a-fueling-meal/clips/02-add-carbohydrate.mp4` — rfl-v1-l11-clip-02-add-carbohydrate
- `lessons/11-building-a-fueling-meal/clips/03-add-produce.mp4` — rfl-v1-l11-clip-03-add-produce
- `lessons/11-building-a-fueling-meal/clips/04-add-water.mp4` — rfl-v1-l11-clip-04-add-water
- `lessons/12-plan-cook-serve-and-clean/cover.webp` — rfl-v1-l12-cover
- `lessons/12-plan-cook-serve-and-clean/thumbnail.webp` — rfl-v1-l12-thumbnail
- `lessons/12-plan-cook-serve-and-clean/clips/01-write-meal-plan.mp4` — rfl-v1-l12-clip-01-write-meal-plan
- `lessons/12-plan-cook-serve-and-clean/clips/02-check-ingredient-list.mp4` — rfl-v1-l12-clip-02-check-ingredient-list
- `lessons/12-plan-cook-serve-and-clean/clips/03-stir-bowl.mp4` — rfl-v1-l12-clip-03-stir-bowl
- `lessons/12-plan-cook-serve-and-clean/clips/04-place-serving-bowl.mp4` — rfl-v1-l12-clip-04-place-serving-bowl
- `lessons/12-plan-cook-serve-and-clean/clips/05-store-leftovers.mp4` — rfl-v1-l12-clip-05-store-leftovers
- `lessons/12-plan-cook-serve-and-clean/clips/06-wipe-counter.mp4` — rfl-v1-l12-clip-06-wipe-counter
- `lessons/12-plan-cook-serve-and-clean/clips/07-return-spatula.mp4` — rfl-v1-l12-clip-07-return-spatula
- `lessons/12-plan-cook-serve-and-clean/clips/08-complete-reflection.mp4` — rfl-v1-l12-clip-08-complete-reflection
