# RFL-M4 Validation Report — Lessons 10–12

**Overall result:** PARTIAL PASS — all nonvisual deliverables and production specifications pass; visual binaries and visual QC remain blocked.

| Check | Result | Details |
|---|---|---|
| authorized-scope-only | PASS | Contains only Lessons 10–12. |
| stable-ids-and-paths | PASS | Approved lesson slugs, media IDs, relative paths, zero-padding, and lowercase ASCII filenames preserved. |
| finish-the-loop | PASS | Present in narration/manifests; Lesson 12 covers plan, prepare, serve, store, clean, return, and reflect. |
| cast-map-v1.1 | PASS | Lesson 10 Maya; Lesson 11 Niko; Lesson 12 approved eight-clip rotation. |
| one-active-learner | PASS | Every clip spec names exactly one active learner. Ms. Rivera is explicitly stationary and non-active. |
| one-action-one-object | PASS | All 16 clip specs declare actionCount=1 and mainObjectCount=1. |
| guardian-visibility | PASS (spec) | All Lesson 11 and 12 clips require visible, physically still Ms. Rivera. Actual-frame validation blocked. |
| no-lip-sync | PASS (spec) | Audio is separate; all clips prohibit speech animation and lip-sync. Actual-frame validation blocked. |
| nutrition-framing | PASS | Variety, adequacy, energy, growth, recovery, hydration, culture, access, allergies, and sensory needs are supported. No targets or body scoring. |
| hunger-framing | PASS | Hunger is treated neutrally; food is not delayed, denied, earned, or moralized. |
| reflection-privacy | PASS | Reflection is private/minimally disclosive and requires no child photograph. |
| food-safety | PASS (spec) | Guardian owns allergies, heat, tools, appliances, raw food, temperatures, service approval, and storage. Actual-frame validation blocked. |
| narration-exactness | PASS | Text source exactly matches the approved curriculum scripts for Lessons 10–12. |
| narration-audio-format | PASS | Three valid MP3 files generated; mono 44.1 kHz. Creative voice-lock review remains pending. |
| webvtt-basic-validity | PASS | 19 WebVTT files have headers, monotonic cues, valid timestamps, and nonempty text. |
| json-parse | PASS | All manifests, production specs, and blocked-asset files parse. |
| unintended-people-hands-objects-text-logos | BLOCKED | Rejection criteria are present, but no visual binary exists to inspect. |
| character-identity-consistency | BLOCKED | No approved visual references were available to generate or compare binaries. |
| kling-motion-and-object-continuity | BLOCKED | No MP4 binary exists to review. |
| github-supabase-netlify-lovable-boundary | PASS | No prohibited system was modified. |

## Blocked visual validation

Visual checks must be rerun after the six WebP and sixteen MP4 binaries are inserted at their stable expected paths. Do not convert a blocked check into PASS from prompt review alone.

## Generated counts

- Narration MP3: 3
- Narration WebVTT: 3
- Clip WebVTT: 16
- Transcripts: 3
- Still specifications: 6
- Kling specifications: 16
- Per-lesson manifests: 3
- Combined manifest: 1
- Blocked binaries: 22
