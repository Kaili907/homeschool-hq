# Lesson 10 — Hunger, Boredom, and Body Signals — Narration Transcript

- **Narrator:** Maya
- **Language:** English (`en`)
- **Core principle:** Finish the loop.
- **Privacy:** Neutral and minimally disclosive.
- **Audio:** `audio/narration.en.mp3`
- **Captions:** `captions/narration.en.vtt`

## Approved narration

Bodies send many kinds of information. A body signal is not a grade and there is no perfect answer. Ask: Am I hungry, thirsty, tired, bored, upset, or stressed? More than one signal can be true. You never have to prove hunger before eating. Food is not a reward that must be earned. Choose care such as food, water, rest, movement, an activity, quiet, or connection. This lesson does not use calories, dieting, weight cutting, weigh-ins, body-size scoring, or food restriction. Keep your reflection private. You may share only what is needed for support. Pause, notice without shame, choose care, and check again later only when useful.

## Clip narration

- `01-read-signal-card.mp4` — Pause and notice. More than one signal can be true.
- `02-drink-water.mp4` — Water can be one caring response when thirst is present.
- `03-choose-snack.mp4` — Food is a caring response. You do not have to prove hunger or earn it.
- `04-choose-rest-card.mp4` — Rest, movement, activity, or connection may also support what you notice.

## Accessibility and privacy note

The lesson remains usable without media. No identifiable child photograph or personal body disclosure is required.
