# Lesson 12 — Plan, Cook, Serve, and Clean — Narration Transcript

- **Narrator:** Maya
- **Language:** English (`en`)
- **Core principle:** Finish the loop.
- **Privacy:** Neutral and minimally disclosive.
- **Audio:** `audio/narration.en.mp3`
- **Captions:** `captions/narration.en.vtt`

## Approved narration

The final project is one complete family-meal loop. A simple familiar meal is enough. Choose the meal, check ingredients and safety needs, make a list, and gather the planned tools. Mark every action learner-safe, shared, or guardian-only before preparation begins. Prepare in order. The guardian remains responsible for allergies, heat, sharp tools, appliances, raw foods, and temperatures. Serve or portion the meal after the guardian confirms it is ready. Store leftovers promptly according to the approved household plan. Clean dishes and approved surfaces. Return food, tools, cloths, and planning materials. Complete a minimal private reflection. Safe sequence and loop completion show mastery.

## Clip narration

- `01-write-meal-plan.mp4` — Begin by choosing the meal and writing the plan.
- `02-check-ingredient-list.mp4` — Check ingredients, safety needs, and what must be gathered.
- `03-stir-bowl.mp4` — Complete one approved preparation action at a time.
- `04-place-serving-bowl.mp4` — Serve only after the guardian confirms the food is ready.
- `05-store-leftovers.mp4` — Store leftovers promptly according to the approved plan.
- `06-wipe-counter.mp4` — Reset dishes and approved surfaces.
- `07-return-spatula.mp4` — Return every tool and material to its home.
- `08-complete-reflection.mp4` — Reflect briefly, protect privacy, and finish the loop.

## Accessibility and privacy note

The lesson remains usable without media. No identifiable child photograph or personal body disclosure is required.
