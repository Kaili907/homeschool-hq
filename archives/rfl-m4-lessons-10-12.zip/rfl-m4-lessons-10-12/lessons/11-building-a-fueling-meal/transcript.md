# Lesson 11 — Building a Fueling Meal — Narration Transcript

- **Narrator:** Maya
- **Language:** English (`en`)
- **Core principle:** Finish the loop.
- **Privacy:** Neutral and minimally disclosive.
- **Audio:** `audio/narration.en.mp3`
- **Captions:** `captions/narration.en.vtt`

## Approved narration

Meals can support learning, play, growth, and recovery. This lesson does not count calories or judge body size. Protein supports growth, repair, and many body jobs. Energy-giving carbohydrates support the brain and movement. Fruit or vegetables add variety and nutrients. Fat may support energy, growth, and satisfaction. Water supports hydration. One food may contribute to more than one meal part. Use choices that fit allergies, culture, sensory needs, cost, access, and family routines. Serve or store the meal, return the food and tools, reset the kitchen, and finish the loop.

## Clip narration

- `01-add-protein.mp4` — Protein supports growth, repair, and many body jobs.
- `02-add-carbohydrate.mp4` — Energy-giving carbohydrates support the brain and movement.
- `03-add-produce.mp4` — Fruit or vegetables add variety and nutrients.
- `04-add-water.mp4` — Water supports hydration.

## Accessibility and privacy note

The lesson remains usable without media. No identifiable child photograph or personal body disclosure is required.
