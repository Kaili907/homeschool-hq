# Director Handoff — RFL-M4 Lessons 10–12

## Package status

The content, audio, captions, transcripts, manifests, production prompts, and validation framework are ready. The six still images and sixteen Kling clips are explicitly blocked and absent.

## Required next production actions

1. Make the approved visual reference binaries available for Maya, Jordan, Sofia, Eli, Niko, and Ms. Rivera. Use the locked approved sheets; do not regenerate the cast from descriptions.
2. Generate each `cover.webp` with OpenAI Images using the matching `specs/stills/cover.json` prompt and the appropriate character references.
3. Produce each `thumbnail.webp` as a reference-based crop of the approved cover using `specs/stills/thumbnail.json`.
4. Upload the approved reference images to the Manuel Academy Media Lab project.
5. Generate each MP4 with Kling 3 Omni in `element2video` mode using the matching `specs/clips/*.json` file. Keep narration and captions separate. Do not enable native dialogue or lip-sync.
6. Place the approved binaries at the exact expected paths. Do not rename lesson folders, clips, captions, covers, thumbnails, or IDs.
7. Run `python tools/validate-package.py .` from the package root.
8. Conduct human frame-by-frame visual QC for face/wardrobe consistency, hands, anatomy, one-action/one-object compliance, stationary Ms. Rivera, food safety, object continuity, unintended people or objects, text, watermarks, brands, and logos.
9. Review the generated narration voice. Replace only the MP3 if a better approved Maya voice becomes available; preserve the exact transcript and retime `captions/narration.en.vtt` if duration changes.

## Lesson 12 completion gate

Do not approve Lesson 12 unless the final sequence visibly demonstrates all of the following: planning, ingredient/safety checking, preparation, serving, leftover storage, surface cleanup, tool return, and minimally disclosive reflection.

## Final approval statement

A director may mark this batch fully complete only after all 22 blocked binaries exist, all visual checks pass, and the combined manifest statuses are updated from `blocked` to `approved`.
