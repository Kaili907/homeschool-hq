#!/usr/bin/env python3
from __future__ import annotations
import json, re, subprocess, sys
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
errors = []
blocked = []

for p in root.rglob('*'):
    if p.is_file():
        rel = p.relative_to(root).as_posix()
        if not re.fullmatch(r'[a-z0-9._/-]+', rel):
            errors.append(f'non-lowercase-ascii path: {rel}')
        if p.suffix == '.json':
            try: json.loads(p.read_text(encoding='utf-8'))
            except Exception as e: errors.append(f'json parse: {rel}: {e}')
        if p.suffix == '.vtt':
            text = p.read_text(encoding='utf-8')
            if not text.startswith('WEBVTT'):
                errors.append(f'vtt header: {rel}')
            if '-->' not in text:
                errors.append(f'vtt cue missing: {rel}')

manifest_path = root / 'media-manifest.lessons-10-12.json'
if not manifest_path.exists():
    errors.append('combined manifest missing')
else:
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    for lesson in manifest.get('lessons', []):
        base = root / 'lessons' / lesson['slug']
        media = lesson['media']
        for key in ('cover', 'thumbnail'):
            item = media[key]
            target = base / item['expectedPath']
            if item['status'] == 'blocked' and not target.exists():
                blocked.append(target.relative_to(root).as_posix())
            elif not target.exists():
                errors.append(f'missing: {target.relative_to(root)}')
        for clip in media['clips']:
            target = base / clip['expectedPath']
            if clip['actionCount'] != 1 or clip['mainObjectCount'] != 1:
                errors.append(f'action/object count: {clip["mediaId"]}')
            if clip['visibleGuardian'] == 'ms-rivera' and 'physically still' not in clip['guardianBehavior']:
                errors.append(f'guardian behavior: {clip["mediaId"]}')
            if clip['status'] == 'blocked' and not target.exists():
                blocked.append(target.relative_to(root).as_posix())
            elif not target.exists():
                errors.append(f'missing: {target.relative_to(root)}')
        for rel in (media['narration']['path'], media['narration']['captionPath'], media['narration']['transcriptPath']):
            if not (base / rel).exists(): errors.append(f'missing generated file: {(base/rel).relative_to(root)}')

for mp3 in root.rglob('*.mp3'):
    try:
        subprocess.run(['ffprobe','-v','error',str(mp3)], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        errors.append(f'invalid audio: {mp3.relative_to(root)}')

print(f'errors={len(errors)} blocked={len(blocked)}')
for x in errors: print('ERROR', x)
for x in blocked: print('BLOCKED', x)
sys.exit(1 if errors else 0)
