# 07 — The Kitchen Reset — Narration Transcript

**Media ID:** `rfl-v1-l07-narration-en`  
**Narrator:** Maya  
**Language:** English (`en-US`)  
**Text status:** Approved and unchanged  
**Audio status:** Blocked pending approved Maya narration voice/TTS access  
**Caption timing:** Estimated; final audio conform required

## Approved narration

A snack or meal is not finished until the kitchen is ready for the next person. Ask a guardian where leftovers belong. Do not guess about food storage. Carry one cool, unbroken, approved dish at a time. Use the household rule to scrape, save, or discard remaining food. Place the dish in the approved location and wipe one approved preparation surface. Never handle hot pans, sharp tools, broken dishes, raw-food messes, or cleaning chemicals alone. Return food, tools, cloths, and supplies. Check the floor and finish the loop.

## Clip captions

- `01-scrape-plate.mp4`: Follow your household rule for leftovers and scraps.
- `02-load-same-plate.mp4`: Load one safe dish at a time.
- `03-wipe-counter.mp4`: Wipe only the approved food-preparation surface.
- `04-close-dishwasher.mp4`: Return the tools, close the appliance as directed, and review the space.
