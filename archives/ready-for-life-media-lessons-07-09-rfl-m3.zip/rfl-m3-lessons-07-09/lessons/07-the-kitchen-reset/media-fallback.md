# Missing-media fallback — 07 The Kitchen Reset

Follow the seven-step kitchen reset checklist with a guardian visible: store food, clear one safe dish, handle leftovers, load, wipe, return supplies, and review.

The lesson remains fully usable when images, video, or audio are unavailable.
