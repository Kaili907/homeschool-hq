# 08 — Food and Kitchen Safety — Narration Transcript

**Media ID:** `rfl-v1-l08-narration-en`  
**Narrator:** Maya  
**Language:** English (`en-US`)  
**Text status:** Approved and unchanged  
**Audio status:** Blocked pending approved Maya narration voice/TTS access  
**Caption timing:** Estimated; final audio conform required

## Approved narration

Food-safety habits protect everyone who eats. Use repeatable actions and ask when you are unsure. Clean means wash hands and use clean surfaces and tools. Scrub hands with soap for at least twenty seconds. Separate means keep raw animal foods and their juices away from ready-to-eat food. Cook means using the correct adult-approved method and temperature for foods that require cooking. Chill means returning foods that need refrigeration promptly. Stop for allergy questions, damaged packages, unknown ingredients, raw-food contact, heat, or sharp tools. Store the food, reset the dish, tools, and surface, and finish the safety loop.

## Clip captions

- `01-wash-hands.mp4`: Wash with soap and scrub all hand surfaces for at least twenty seconds.
- `02-place-apple-clean-board.mp4`: Use a clean surface and keep ready-to-eat food separate.
- `03-return-yogurt.mp4`: Return foods that need refrigeration promptly.
- `04-show-ask-card.mp4`: Stop and ask before using heat, sharp tools, or unfamiliar ingredients.
