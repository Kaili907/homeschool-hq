# Missing-media fallback — 08 Food and Kitchen Safety

Read the clean, separate, cook, and chill safety card. Wash hands for at least 20 seconds, prepare only a guardian-approved cold snack, return cold foods, and reset the area.

The lesson remains fully usable when images, video, or audio are unavailable.
