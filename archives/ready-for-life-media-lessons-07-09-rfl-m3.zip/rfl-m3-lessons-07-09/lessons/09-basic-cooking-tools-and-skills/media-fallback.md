# Missing-media fallback — 09 Basic Cooking Tools and Skills

Read the recipe first, gather approved tools, complete one step at a time, serve or store the food, and reset every tool, ingredient, and surface.

The lesson remains fully usable when images, video, or audio are unavailable.
