# 09 — Basic Cooking Tools and Skills — Narration Transcript

**Media ID:** `rfl-v1-l09-narration-en`  
**Narrator:** Maya  
**Language:** English (`en-US`)  
**Text status:** Approved and unchanged  
**Audio status:** Blocked pending approved Maya narration voice/TTS access  
**Caption timing:** Estimated; final audio conform required

## Approved narration

Good cooks read the full recipe before gathering tools or opening ingredients. Check ingredients, allergy needs, and every step that requires a guardian. Gather only the measuring tools, bowl, spoon, spatula, or approved spreader the recipe needs. Follow the recipe in order. Perform one clear action with one main object at a time. Keep bowls stable and handles dry. Stop for sharp tools, heat, electricity, raw foods, or unclear directions. Serve the food or store it according to the guardian-approved plan. Close ingredients, clean tools, wipe the approved surface, return the recipe, and finish the loop.

## Clip captions

- `01-measure-ingredient.mp4`: Measure one ingredient using the tool named in the recipe.
- `02-stir-bowl.mp4`: Keep the bowl stable and perform one recipe action at a time.
- `03-spread-soft-food.mp4`: Use only the tool approved by your guardian.
- `04-rinse-spatula.mp4`: Cleaning and returning the tool is part of the recipe.
