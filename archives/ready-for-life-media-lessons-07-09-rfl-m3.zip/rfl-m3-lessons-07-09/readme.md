# Ready for Life Media — RFL-M3 — Lessons 07–09

This package contains the complete production-ready media specification and all non-binary deliverables for:

- `07-the-kitchen-reset` — Niko; Ms. Rivera visible and stationary; Maya narrates
- `08-food-and-kitchen-safety` — Maya; Ms. Rivera visible and stationary; Maya narrates
- `09-basic-cooking-tools-and-skills` — Eli; Ms. Rivera visible and stationary; Maya narrates

## Status

**Production-ready specification: PASS**  
**Final image/video/audio binaries: BLOCKED**

The approved Niko, Eli, Maya, and Ms. Rivera visual reference binaries are not available as active OpenArt inputs, and the approved Maya narration voice/TTS asset is not accessible. The connected OpenArt generation workflow is asynchronous and cannot return new downloadable binaries within this package-building session. No inconsistent text-only character generations, old Maya-only clips, fake files, or generic narration voice were substituted.

## Included

- Stable media IDs and target paths
- Approved narration transcripts, unchanged
- Valid narration and clip-specific WebVTT captions
- OpenAI GPT Image 2 cover, thumbnail, and reference-frame requests
- Kling 3 Omni image-to-video requests
- Per-lesson and batch manifests
- Missing-media fallbacks
- Binary blocker sidecars
- Asset inventory, production report, validation report, Director handoff
- Re-runnable package validator

## Stable target root

`public/curriculum/ready-for-life/v1/lessons/<lesson-slug>/`

The ZIP uses lesson-relative paths so the Director can stage the package outside GitHub and later place approved assets at the intended public media root.
