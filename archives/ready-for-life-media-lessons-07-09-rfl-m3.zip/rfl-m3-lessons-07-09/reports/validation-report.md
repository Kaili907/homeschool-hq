# RFL-M3 Validation Report

**Specification result:** PASS  
**Automated checks passed:** 54  
**Automated failures:** 0  
**Final binary gate:** BLOCKED — 21 planned binaries pending

## Passed gates

- Correct lesson folders, orders, stable IDs, and lowercase ASCII paths
- v1.1 cast map: Niko / Maya / Eli; Ms. Rivera stationary; Maya narrator
- Exactly four clips per lesson
- One active learner, one physical action, and one main object per clip
- Guardian required in all 12 clips
- Valid JSON and basic WebVTT syntax
- Approved narration text and clip captions preserved
- Handwashing final-duration target set to at least 20 seconds
- Visual prompts avoid affirmative display of knives, heat, raw-food cross-contact, hazardous cleaners, plugs, outlets, exposed mechanisms, logos, or unrelated people
- No fake zero-byte `.webp`, `.mp4`, or `.mp3` target files
- No platform or infrastructure changes

## Blocked visual/audio gates

These checks require actual binaries and therefore are not claimed as passed:

- Character face, age, wardrobe, and proportion consistency
- Guardian visibility and physical stillness in rendered frames
- Hand anatomy and unintended extra hands/fingers
- Object continuity, duplicate/disappearing objects, and sequence continuity
- Raw-food contamination and hazard review in rendered imagery
- Unintended text, logo, watermark, or packaging review
- H.264/MP4 codec, resolution, frame rate, and duration
- Narration voice lock, waveform quality, loudness, pronunciation, and VTT/audio synchronization

## Overall disposition

**PRODUCTION-READY SPECIFICATION PASS; FINAL MEDIA RELEASE BLOCKED UNTIL 21 BINARIES ARE GENERATED AND PASS BINARY QA.**
