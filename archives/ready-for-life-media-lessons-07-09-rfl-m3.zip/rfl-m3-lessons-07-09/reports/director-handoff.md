# RFL-M3 Director Handoff

## Delivery state

The package is ready for controlled binary production. Do not integrate it into GitHub or the Academy app until the separate platform sequence authorizes curriculum integration.

## Locked cast

| Lesson | Active learner | Visible guardian | Narrator |
|---|---|---|---|
| 07 | Niko | Ms. Rivera, stationary | Maya |
| 08 | Maya | Ms. Rivera, stationary | Maya |
| 09 | Eli | Ms. Rivera, stationary | Maya |

## Required production order

1. Make the approved Niko, Maya, Eli, and Ms. Rivera reference assets available to the `Manuel Academy Media Lab` project.
2. Generate one cover at a time with the included OpenAI GPT Image 2 requests.
3. Review identity, age, wardrobe, anatomy, guardian visibility/stillness, one action, one object, safety, logos, and text before generating the thumbnail.
4. Generate each safety-locked reference frame with OpenAI GPT Image 2.
5. Generate Kling 3 Omni clips in small reviewable batches using the approved reference frame as the literal start frame. Keep sound disabled.
6. Generate narration with the approved Maya voice, normalize audio, and conform the provided narration VTT timings without changing words.
7. Replace each `.blocked.json` sidecar only after the corresponding binary passes the binary validation gate.
8. Run `python scripts/validate_package.py --require-binaries` and record SHA-256 hashes.

## Immediate rejection conditions

Reject any asset with identity drift, child/adult age drift, wardrobe drift, moving guardian, additional active person, extra action, extra main object, malformed hands, unsafe tool handling, raw-food cross-contact, visible unsupervised hazard, new/disappearing object, lip-sync, logo, watermark, unintended text, or sequence error.

## Lesson-specific gate

- Lesson 07: use Niko, not the old Maya kitchen test. The same plain plate design must carry from clip 01 to clip 02.
- Lesson 08: handwashing must visibly cover all hand surfaces and total at least 20 seconds in the final MP4. The ask card text, when visible, must be exactly `STOP AND ASK`.
- Lesson 09: the spreader must be rounded and visibly blunt. All scenes remain no-heat and no-appliance.

## Blocked dependencies

- Approved character reference binaries in OpenArt
- Approved Maya narration voice/TTS access
- Synchronous retrieval of completed OpenArt outputs for packaging

No credits were consumed by this package build.
