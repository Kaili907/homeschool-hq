#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re, sys
from pathlib import Path

def parse_vtt(path: Path):
    lines=path.read_text(encoding='utf-8').splitlines()
    assert lines and lines[0].strip()=='WEBVTT', f'{path}: missing WEBVTT header'
    stamps=[]
    for line in lines:
        if ' --> ' in line:
            a,b=line.split(' --> ',1); stamps.append((a.strip(),b.strip()))
    assert stamps, f'{path}: no cues'

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--require-binaries',action='store_true'); args=ap.parse_args()
    root=Path(__file__).resolve().parents[1]
    failures=[]; passes=[]; blocked=[]
    def check(name, cond, detail=''):
        (passes if cond else failures).append({'check':name,'detail':detail})
    # JSON and VTT
    for p in root.rglob('*.json'):
        try: json.loads(p.read_text(encoding='utf-8'))
        except Exception as e: failures.append({'check':'json-parse','detail':f'{p.relative_to(root)}: {e}'})
    for p in root.rglob('*.vtt'):
        try: parse_vtt(p)
        except Exception as e: failures.append({'check':'webvtt','detail':str(e)})
    check('exact-lesson-folders', sorted(p.name for p in (root/'lessons').iterdir() if p.is_dir())==['07-the-kitchen-reset','08-food-and-kitchen-safety','09-basic-cooking-tools-and-skills'])
    # Lowercase ASCII filenames
    bad=[]
    for p in root.rglob('*'):
        rel=p.relative_to(root).as_posix()
        if not re.fullmatch(r'[a-z0-9._/\-]+',rel): bad.append(rel)
    check('lowercase-ascii-paths',not bad,', '.join(bad))
    expected={'07':'niko','08':'maya','09':'eli'}
    for order,primary in expected.items():
        mp=next((root/'lessons').glob(f'{order}-*/manifest.json'))
        m=json.loads(mp.read_text())
        check(f'l{order}-primary-cast',m['cast']['primaryLearner']==primary)
        check(f'l{order}-guardian',m['cast']['visibleGuardian']=='ms-rivera')
        check(f'l{order}-narrator',m['cast']['narrator']=='maya')
        check(f'l{order}-four-clips',len(m['clips'])==4)
        for c in m['clips']:
            check(c['id']+'-one-action',c['actionCount']==1)
            check(c['id']+'-one-object',c['mainObjectCount']==1)
            check(c['id']+'-guardian-required',c['guardianVisibility']=='guardian-required')
    # Blocker and binary gate
    b=json.loads((root/'blocked-assets.json').read_text())
    check('blocked-count-21',b['count']==21,str(b['count']))
    targets=[root/i['path'] for i in b['items']]
    missing=[p for p in targets if not p.exists()]
    if args.require_binaries:
        check('all-final-binaries-present',not missing,', '.join(str(p.relative_to(root)) for p in missing))
    else:
        blocked.append({'check':'final-binaries','detail':f'{len(missing)} planned binaries pending'})
    check('no-fake-zero-byte-binaries',all(not p.exists() or p.stat().st_size>0 for p in targets))
    # Safety prompt scan: positive visual prompts only
    banned=['stovetop','oven','hot cookware','boiling water','hazardous cleaner','plug,','outlet','raw animal food appears']
    violations=[]
    for p in root.rglob('production/openai-images/*.json'):
        d=json.loads(p.read_text()); prompt=d.get('openartRequest',{}).get('params',{}).get('prompt','').lower()
        # Requirements may say "no x"; only flag plainly unsafe affirmative phrases.
        for phrase in ['child holds a knife','child uses a stove','child touches a plug','raw chicken beside fruit']:
            if phrase in prompt: violations.append(f'{p.relative_to(root)}:{phrase}')
    check('visual-prompts-no-affirmative-hazards',not violations,', '.join(violations))
    wash=json.loads((root/'lessons/08-food-and-kitchen-safety/manifest.json').read_text())['clips'][0]
    check('handwashing-final-duration-20s',wash['durationTargetSeconds']>=20,str(wash['durationTargetSeconds']))
    result='PASS' if not failures else 'FAIL'
    print(json.dumps({'result':result,'passes':len(passes),'failures':failures,'blocked':blocked},indent=2))
    return 0 if not failures else 1
if __name__=='__main__': raise SystemExit(main())
