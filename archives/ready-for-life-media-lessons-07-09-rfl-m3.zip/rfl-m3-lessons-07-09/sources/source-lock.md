# Source lock

The package was built from the approved Manuel Academy Ready for Life materials:

- Ready for Life Master Curriculum
- Ready for Life Media Production Bible v1
- Synthetic Character Bible v1.1
- Lesson Cast Map v1.1

## Preserved without rewrite

- Lesson IDs, orders, slugs, media IDs, and lowercase ASCII target filenames
- Four-clip sequence per lesson
- Physical actions and main objects
- Approved narration scripts
- Clip captions and missing-media fallback meaning

## Media-only v1.1 cast application

- Lesson 07 visual learner: Niko
- Lesson 08 visual learner: Maya
- Lesson 09 visual learner: Eli
- Lessons 07–09 guardian: Ms. Rivera, fully visible and physically still
- Narrator: Maya

The older Maya-only storyboard character labels were superseded only where the authoritative v1.1 cast map assigns a different visual learner. No curriculum lesson body was rewritten.
