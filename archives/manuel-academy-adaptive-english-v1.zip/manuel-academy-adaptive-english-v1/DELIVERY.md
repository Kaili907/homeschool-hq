# TUTOR-ENGLISH delivery

The owned package is located at:

`adaptive-tutor/subjects/english/**`

Run validation from that directory with `npm run check`. Open `demo/index.html` for the standalone browser demonstration.

This delivery was produced outside GitHub and contains no service, database, authentication, storage, identity, synchronization, Ready for Life, math, or shared-core changes.
