import type { EnglishSequenceId, EnglishSkillId } from './types'

export interface EnglishSequenceRegistryEntry {
  sequenceId: EnglishSequenceId
  lessonId: string
  skillId: EnglishSkillId
  order: 1 | 2 | 3 | 4
  title: string
  jsonPath: string
  markdownPath: string
}

export const ENGLISH_SEQUENCE_REGISTRY: readonly EnglishSequenceRegistryEntry[] = [
  { sequenceId: 'ela-04-06-seq-01-multisyllable-decoding', lessonId: 'ela-04-06-l01-decode-multisyllable-words', skillId: 'ela.word.decoding.multisyllable', order: 1, title: "Decode Unfamiliar Multisyllable Words", jsonPath: 'data/sequences/ela-04-06-seq-01-multisyllable-decoding.json', markdownPath: 'sequences/ela-04-06-seq-01-multisyllable-decoding.md' },
  { sequenceId: 'ela-04-06-seq-02-sentence-completeness', lessonId: 'ela-04-06-l02-complete-sentences', skillId: 'ela.language.sentence.complete', order: 2, title: "Build Complete Sentences", jsonPath: 'data/sequences/ela-04-06-seq-02-sentence-completeness.json', markdownPath: 'sequences/ela-04-06-seq-02-sentence-completeness.md' },
  { sequenceId: 'ela-04-06-seq-03-main-idea-details', lessonId: 'ela-04-06-l03-main-idea-supporting-details', skillId: 'ela.reading.main-idea.details', order: 3, title: "Find the Main Idea and Supporting Details", jsonPath: 'data/sequences/ela-04-06-seq-03-main-idea-details.json', markdownPath: 'sequences/ela-04-06-seq-03-main-idea-details.md' },
  { sequenceId: 'ela-04-06-seq-04-paragraph-revision', lessonId: 'ela-04-06-l04-organize-revise-paragraph', skillId: 'ela.writing.paragraph.organize-revise', order: 4, title: "Organize and Revise a Clear Paragraph", jsonPath: 'data/sequences/ela-04-06-seq-04-paragraph-revision.json', markdownPath: 'sequences/ela-04-06-seq-04-paragraph-revision.md' },
] as const
