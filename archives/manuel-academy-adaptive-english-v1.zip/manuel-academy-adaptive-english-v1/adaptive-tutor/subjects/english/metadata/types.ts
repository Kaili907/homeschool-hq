export type EnglishSequenceId =
  | 'ela-04-06-seq-01-multisyllable-decoding'
  | 'ela-04-06-seq-02-sentence-completeness'
  | 'ela-04-06-seq-03-main-idea-details'
  | 'ela-04-06-seq-04-paragraph-revision'

export type EnglishSkillId =
  | 'ela.word.decoding.multisyllable'
  | 'ela.language.sentence.complete'
  | 'ela.reading.main-idea.details'
  | 'ela.writing.paragraph.organize-revise'

export interface GradeBand {
  min: number
  max: number
  label: string
  extensible: boolean
}

export interface Prerequisite {
  skillId: string
  title: string
  evidence: string
}

export interface AssessmentItem {
  id: string
  type?: 'multiple-choice' | 'constructed'
  prompt: string
  choices?: string[]
  answer?: string
  accepted?: string[]
  evidenceTags?: string[]
}

export interface MisconceptionPattern {
  id: string
  label: string
  pattern: string
  evidenceToDistinguish: string[]
  responsePlan: string
}

export interface ExplanationMode {
  title: string
  [key: string]: string | string[]
}

export interface EnglishSequenceMetadata {
  schemaVersion: '1.0.0'
  subject: 'english'
  sequenceId: EnglishSequenceId
  lessonId: string
  skillId: EnglishSkillId
  order: 1 | 2 | 3 | 4
  title: string
  summary: string
  gradeBand: GradeBand
  estimatedMinutes: Record<string, number>
  prerequisites: Prerequisite[]
  objectives: string[]
  learnerPromises: string[]
  diagnostic: {
    purpose: string
    directions: string
    items: AssessmentItem[]
    passage?: unknown
    draft?: unknown
  }
  misconceptions: MisconceptionPattern[]
  visualExplanationPlan: {
    model: string[]
    commandsFile: string
    accessibilityText: string
  }
  spokenExplanation: {
    scriptFile: string
    captionsFile: string
    transcriptFile: string
    text: string
  }
  modes: {
    showMe: ExplanationMode
    talkMeThroughIt: ExplanationMode
    letsDoOneTogether: ExplanationMode
    differentExample: ExplanationMode
  }
  guidedPractice: Array<Record<string, unknown> & { id: string; prompt: string; answer: string; reasoning: string }>
  independentMasteryCheck: {
    policy: string
    items: Array<{ id: string; prompt: string; answer: string }>
    readinessRules: string[]
    [key: string]: unknown
  }
  branches: {
    reteaching: Record<string, unknown>
    prerequisiteRemediation: Record<string, unknown>
  }
  parentTeacherReviewNote: string
  noMediaFallback: string
  answerKey: Array<{ itemId: string; source: string; answer: string | string[]; reasoning: string }>
  sourceRights: { passages: string; licenseNote: string }
}

export interface EnglishPackageManifest {
  packageId: 'manuel-academy-adaptive-english-v1'
  version: '1.0.0'
  subject: 'english'
  gradeBand: GradeBand
  sequenceOrder: EnglishSequenceId[]
  coreAdapter: 'provisional-v1'
  contentRoot: 'adaptive-tutor/subjects/english'
}
