import type { EnglishPackageManifest } from './types'

export const ENGLISH_PACKAGE_MANIFEST: EnglishPackageManifest = {
  packageId: 'manuel-academy-adaptive-english-v1',
  version: '1.0.0',
  subject: 'english',
  gradeBand: { min: 4, max: 6, label: 'Grades 4–6', extensible: true },
  sequenceOrder: [
    'ela-04-06-seq-01-multisyllable-decoding',
    'ela-04-06-seq-02-sentence-completeness',
    'ela-04-06-seq-03-main-idea-details',
    'ela-04-06-seq-04-paragraph-revision',
  ],
  coreAdapter: 'provisional-v1',
  contentRoot: 'adaptive-tutor/subjects/english',
}
