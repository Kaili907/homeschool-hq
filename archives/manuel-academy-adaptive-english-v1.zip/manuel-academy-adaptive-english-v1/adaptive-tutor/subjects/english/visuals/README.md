# Visual-board command contract

These files are declarative, provisional commands for a future shared visual-board renderer. They do not require generated images, a camera, or identifiable child media.

Supported provisional operations include `clear`, `placeText`, `placeTile`, `placeBox`, `highlightSpan`, `replaceText`, `drawSweep`, `connect`, `connectMany`, `sequenceCards`, `moveCard`, `placeZone`, `showBeforeAfter`, and `announce`.

Every scene must provide meaningful text through `announce` or through the sequence-level accessibility description. Unknown operations should render as a readable text step rather than fail the lesson.
