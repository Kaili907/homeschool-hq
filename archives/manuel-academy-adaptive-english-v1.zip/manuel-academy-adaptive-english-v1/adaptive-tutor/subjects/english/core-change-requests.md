# English subject — core change requests

No shared core files were modified. These requests describe capabilities needed for first-class integration.

## CR-001 — Native grade-band and grade 5 support

**Current gap:** The current Academy `Grade` union includes grades 4 and 6 but not grade 5.

**Requested contract:** Accept an extensible grade-band object and the learner's actual numeric grade. Vocabulary level may be independently configured.

**Provisional behavior:** Grade 5 uses the legacy grade-4 vocabulary setting only at the adapter boundary. The actual grade remains explicit in content metadata and the problem context. This mapping must not affect mastery.

## CR-002 — Learner-neutral answer field and prompt language

**Current gap:** The live tutor context uses `herAnswer` and the current prompt assumes a female learner.

**Requested contract:** Use `studentAnswer` or `learnerAnswer`, with learner-neutral prompt language.

**Provisional behavior:** The adapter copies neutral `studentAnswer` into `herAnswer` only at the legacy boundary. English content remains neutral.

## CR-003 — First-class adaptive explanation modes

**Requested contract:** Core should understand stable mode IDs: `show-me`, `talk-me-through-it`, `together`, and `different-example`, track which explanation has already been attempted, and require a different explanation after failure.

**Provisional behavior:** Mode content and transition helpers live in this subject package.

## CR-004 — Evidence-based misconception routing

**Requested contract:** Store observations and evidence tags separately from diagnostic labels; allow a route to be selected only after enough distinguishing evidence exists. Never expose a medical diagnosis field.

**Provisional behavior:** JSON fixtures describe observations, expected misconception patterns, and explicit non-diagnostic boundaries.

## CR-005 — Multi-occasion mastery evidence

**Requested contract:** Mastery confirmation must support multiple sets or occasions and should distinguish `ready-for-review` from `mastered`.

**Provisional behavior:** English metadata requires at least two successful sessions plus the latest readiness rules.

## CR-006 — Visual-board renderer with accessible fallback

**Requested contract:** Render declarative visual commands, announce meaningful changes, and degrade unknown commands to readable text. Camera input and child photographs must never be required.

**Provisional behavior:** The package ships visual-board JSON and no-media text alternatives.

## CR-007 — Writing-assistance boundary

**Requested contract:** A writing task should expose whether work is graded. When graded, the tutor may teach, question, model on a different example, and provide criteria, but must not return a replacement final draft.

**Provisional behavior:** All writing practice is original and ungraded; the paragraph sequence repeatedly returns the final revision to the learner.
