import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const readJson = (p) => JSON.parse(fs.readFileSync(path.join(root, p), 'utf8'));
const manifest = readJson('data/package.manifest.json');
const sequences = manifest.sequenceOrder.map((id) => readJson(`data/sequences/${id}.json`));
const checks = [];
const check = (name, ok, details='') => checks.push({ name, result: ok ? 'PASS' : 'FAIL', details });

check('exactly-four-sequences', sequences.length === 4, `Found ${sequences.length}`);
check('ordered-sequences', sequences.every((s, i) => s.order === i + 1), sequences.map(s => s.order).join(', '));
check('stable-unique-ids', new Set(sequences.map(s => s.sequenceId)).size === 4 && sequences.every(s => /^ela-04-06-seq-0[1-4]-[a-z0-9-]+$/.test(s.sequenceId)));
check('grade-band-4-6', sequences.every(s => s.gradeBand.min === 4 && s.gradeBand.max === 6 && s.gradeBand.extensible === true));
check('all-required-modes', sequences.every(s => ['showMe','talkMeThroughIt','letsDoOneTogether','differentExample'].every(k => s.modes[k])));
check('diagnostic-depth', sequences.every(s => s.diagnostic.items.length >= 5));
check('misconception-evidence', sequences.every(s => s.misconceptions.length >= 5 && s.misconceptions.every(m => m.evidenceToDistinguish.length >= 2)));
check('guided-practice-depth', sequences.every(s => s.guidedPractice.length >= 4));
check('mastery-depth', sequences.every(s => s.independentMasteryCheck.items.length >= 6));
check('multi-occasion-mastery', sequences.every(s => /two|more than one|multiple/i.test(s.independentMasteryCheck.policy) && s.independentMasteryCheck.readinessRules.some(r => /two|occasion/i.test(r))));
check('final-revision-owned-by-learner', /learner.*final revision|final revision.*learner/i.test(JSON.stringify(sequences[3])));
check('no-camera-fallback', sequences.every(s => /no camera|camera.*not|required/i.test(s.noMediaFallback) || /No camera/i.test(s.noMediaFallback)));
check('original-rights', sequences.every(s => /original/i.test(s.sourceRights.passages)));
check('answer-key-coverage', sequences.every(s => {
  const ids = [...s.diagnostic.items, ...s.guidedPractice, ...s.independentMasteryCheck.items].map(i => i.id);
  const key = new Set(s.answerKey.map(a => a.itemId));
  return ids.every(id => key.has(id));
}));
check('visual-board-files', sequences.every(s => fs.existsSync(path.join(root, s.visualExplanationPlan.commandsFile))));
check('narration-files', sequences.every(s => [s.spokenExplanation.scriptFile,s.spokenExplanation.captionsFile,s.spokenExplanation.transcriptFile].every(p => fs.existsSync(path.join(root,p)))));
check('webvtt-basic', sequences.every(s => fs.readFileSync(path.join(root,s.spokenExplanation.captionsFile),'utf8').startsWith('WEBVTT')));
check('demo-offline', fs.existsSync(path.join(root,'demo/index.html')) && !/https?:\/\//.test(fs.readFileSync(path.join(root,'demo/index.html'),'utf8')));
check('core-boundary', fs.existsSync(path.join(root,'core-change-requests.md')) && fs.existsSync(path.join(root,'adapters/provisional-core-adapter.ts')));
const prohibited = ['you are lazy','bad reader','wrong dialect','slow reader','just guess the word'];
check('no-shaming-phrases', sequences.every(s => !prohibited.some(p => JSON.stringify(s).toLowerCase().includes(p))));
check('no-medical-diagnosis', sequences.every(s => !/diagnosis\s*:\s*["']/.test(JSON.stringify(s))));

const passed = checks.filter(c => c.result === 'PASS').length;
const failed = checks.length - passed;
const inventory = {
  generatedAt: new Date().toISOString(),
  packageId: manifest.packageId,
  sequences: sequences.length,
  diagnosticItems: sequences.reduce((n,s) => n+s.diagnostic.items.length,0),
  guidedPracticeItems: sequences.reduce((n,s) => n+s.guidedPractice.length,0),
  masteryItems: sequences.reduce((n,s) => n+s.independentMasteryCheck.items.length,0),
  misconceptionPatterns: sequences.reduce((n,s) => n+s.misconceptions.length,0),
  answerKeyEntries: sequences.reduce((n,s) => n+s.answerKey.length,0),
  narrationScripts: sequences.length,
  captionFiles: sequences.length,
  transcripts: sequences.length,
  visualBoards: sequences.length,
  result: failed === 0 ? 'PASS' : 'FAIL'
};
fs.writeFileSync(path.join(root,'reports/content-inventory.json'), JSON.stringify(inventory,null,2)+'\n');
const report = [`# Adaptive English v1 — Validation Report`, '', `**Overall result:** ${failed === 0 ? 'PASS' : 'FAIL'}`, '', `- Checks: ${checks.length}`, `- Passed: ${passed}`, `- Failed: ${failed}`, `- Sequences: ${inventory.sequences}`, `- Diagnostic items: ${inventory.diagnosticItems}`, `- Guided-practice items: ${inventory.guidedPracticeItems}`, `- Independent-mastery items: ${inventory.masteryItems}`, `- Misconception patterns: ${inventory.misconceptionPatterns}`, `- Answer-key entries: ${inventory.answerKeyEntries}`, '', '## Checks', '', '| Check | Result | Details |', '|---|---|---|', ...checks.map(c => `| ${c.name} | ${c.result} | ${String(c.details||'').replaceAll('|','\\|')} |`), '', '## Boundary confirmation', '', '- No GitHub repository was modified.', '- No shared tutor core file was modified.', '- No Supabase, Netlify, Lovable, database, authentication, identity, storage, or synchronization service was contacted or modified.', '- No Ready for Life or math content was modified.', '- No camera or identifiable child photograph is required.', '- All practice passages and drafts are original.', ''];
fs.writeFileSync(path.join(root,'reports/validation-report.md'), report.join('\n'));
console.log(JSON.stringify({result: inventory.result, passed, failed, checks: checks.length, inventory}, null, 2));
if (failed) process.exit(1);
