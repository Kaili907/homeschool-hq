# Manuel Academy Adaptive English v1

A complete, standalone adaptive English language arts intervention content package for approximately grades 4–6. It is built entirely within `adaptive-tutor/subjects/english/**` and does not modify shared tutor core, GitHub, databases, authentication, storage, sync, Ready for Life, or math content.

## Completed sequences

1. `ela-04-06-seq-01-multisyllable-decoding` — decoding unfamiliar multisyllable words
2. `ela-04-06-seq-02-sentence-completeness` — sentence completeness, subjects, predicates, and punctuation
3. `ela-04-06-seq-03-main-idea-details` — main idea and supporting details
4. `ela-04-06-seq-04-paragraph-revision` — organizing and revising a clear paragraph

## Package map

- `sequences/` — complete Markdown learning sequences
- `metadata/` — typed TypeScript manifest and registry
- `data/` — structured JSON package and full sequence records
- `narration/`, `captions/`, `transcripts/` — spoken explanation assets
- `visuals/` — declarative visual-board commands and fallback contract
- `assessments/` — diagnostic, mastery, misconception, and evidence fixtures
- `adapters/` — provisional shared-core compatibility boundary
- `demo/` — standalone browser demonstration
- `tests/` and `scripts/` — automated validation
- `reports/` — generated inventory and validation report

## Run locally

```bash
npm run check
```

Open `demo/index.html` directly in a browser. It makes no network requests and stores no learner data.

## Instructional boundary

The package teaches and models skills. It does not diagnose conditions, require a camera, shame language differences, complete graded writing, or infer mastery from one successful response. All practice passages and drafts are original.
