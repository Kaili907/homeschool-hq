(() => {
  const sequences = window.ENGLISH_PACKAGE || [];
  const nav = document.getElementById('sequenceNav');
  const lesson = document.getElementById('lesson');
  let selected = 0;
  let mode = 'showMe';

  const escapeHtml = (value) => String(value).replace(/[&<>"]/g, (ch) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[ch]));
  const list = (items) => `<ol>${(items || []).map((item) => `<li>${escapeHtml(item)}</li>`).join('')}</ol>`;

  function renderNav() {
    nav.innerHTML = sequences.map((s, i) => `<button class="sequence-button" data-index="${i}" aria-current="${i === selected}"><strong>${i + 1}. ${escapeHtml(s.title)}</strong><br><span class="tags">${escapeHtml(s.skillId)}</span></button>`).join('');
    nav.querySelectorAll('button').forEach((button) => button.addEventListener('click', () => { selected = Number(button.dataset.index); mode = 'showMe'; render(); }));
  }

  function renderMode(s) {
    const m = s.modes[mode];
    const rows = Object.entries(m).filter(([key]) => key !== 'title').map(([key, value]) => {
      const label = key.replace(/([A-Z])/g, ' $1').replace(/^./, c => c.toUpperCase());
      return `<div class="card"><h3>${escapeHtml(label)}</h3>${Array.isArray(value) ? list(value) : `<p>${escapeHtml(value)}</p>`}</div>`;
    }).join('');
    return `<h2>${escapeHtml(m.title)}</h2>${rows}`;
  }

  function renderPractice(s) {
    return s.guidedPractice.slice(0, 3).map((item) => `<article class="card"><h3>${escapeHtml(item.id)}</h3>${item.passage ? `<p>${escapeHtml(item.passage)}</p>` : ''}<p><strong>Prompt:</strong> ${escapeHtml(item.prompt)}</p><button class="reveal" type="button">Reveal teaching key</button><div class="answer" hidden><p><strong>Answer:</strong> ${escapeHtml(item.answer)}</p><p><strong>Reasoning:</strong> ${escapeHtml(item.reasoning)}</p></div></article>`).join('');
  }

  function render() {
    renderNav();
    const s = sequences[selected];
    lesson.innerHTML = `<p class="eyebrow">GRADES ${s.gradeBand.min}–${s.gradeBand.max}</p><h1>${escapeHtml(s.title)}</h1><p>${escapeHtml(s.summary)}</p><p class="notice"><strong>Mastery guard:</strong> ${escapeHtml(s.masteryPolicy)}</p><div class="mode-row">${[['showMe','Show Me'],['talkMeThroughIt','Talk Me Through It'],['letsDoOneTogether',"Let's Do One Together"],['differentExample','Different Example']].map(([id,label]) => `<button class="mode-button" data-mode="${id}" aria-pressed="${mode === id}">${label}</button>`).join('')}</div><section id="modePanel">${renderMode(s)}</section><h2>Guided practice preview</h2>${renderPractice(s)}<details class="card"><summary>Parent/teacher review note</summary><p>${escapeHtml(s.parentTeacherReviewNote)}</p></details><details class="card"><summary>No-media fallback</summary><p>${escapeHtml(s.noMediaFallback)}</p></details>`;
    lesson.querySelectorAll('.mode-button').forEach((button) => button.addEventListener('click', () => { mode = button.dataset.mode; render(); }));
    lesson.querySelectorAll('.reveal').forEach((button) => button.addEventListener('click', () => { const answer = button.nextElementSibling; answer.hidden = !answer.hidden; button.textContent = answer.hidden ? 'Reveal teaching key' : 'Hide teaching key'; }));
  }

  render();
})();
