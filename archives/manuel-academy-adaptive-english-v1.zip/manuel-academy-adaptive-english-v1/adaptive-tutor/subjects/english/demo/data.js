window.ENGLISH_PACKAGE = [
  {
    "sequenceId": "ela-04-06-seq-01-multisyllable-decoding",
    "title": "Decode Unfamiliar Multisyllable Words",
    "summary": "Learners use syllable patterns, morphemes, and a check-and-adjust routine to read unfamiliar longer words without guessing from the first letters alone.",
    "skillId": "ela.word.decoding.multisyllable",
    "gradeBand": {
      "min": 4,
      "max": 6,
      "label": "Grades 4–6",
      "extensible": true
    },
    "modes": {
      "showMe": {
        "title": "Show Me",
        "example": "unpredictable",
        "steps": [
          "Highlight un-, predict, and -able.",
          "Mark pronounceable chunks: un/pre/dict/a/ble.",
          "Blend slowly, then smoothly: unpredictable.",
          "Check the sentence: 'The weather was unpredictable.' The word makes sense."
        ],
        "learnerAction": "Point to each chunk as the tutor blends it."
      },
      "talkMeThroughIt": {
        "title": "Talk Me Through It",
        "prompts": [
          "What familiar part do you see first?",
          "Where do you see vowel sounds or vowel teams?",
          "What chunk will you try first?",
          "Blend the chunks. Does that sound like a word?",
          "Does that word fit the sentence? What one chunk might you adjust?"
        ],
        "tutorConstraint": "Ask one prompt at a time and wait for the learner's attempt."
      },
      "letsDoOneTogether": {
        "title": "Let's Do One Together",
        "example": "disagreement",
        "steps": [
          "Tutor marks dis- and -ment; learner identifies agree.",
          "Tutor and learner mark dis/a/gree/ment.",
          "Learner blends the first two chunks; tutor blends the last two.",
          "Learner says the full word and checks it in: 'Their disagreement ended after they listened.'"
        ],
        "sharedResponsibility": "The tutor models only the next step; the learner completes the final blend."
      },
      "differentExample": {
        "title": "Different Example",
        "example": "carelessness",
        "whyDifferent": "This example begins with a familiar base and adds two suffixes instead of a prefix.",
        "steps": [
          "Highlight care + less + ness.",
          "Read the base care.",
          "Add less, then ness.",
          "Blend care/less/ness and check the meaning."
        ]
      }
    },
    "guidedPractice": [
      {
        "id": "dec-g1",
        "prompt": "Mark word parts and syllables in rereading.",
        "answer": "re/read/ing",
        "reasoning": "The prefix re-, base read, and suffix -ing make useful chunks."
      },
      {
        "id": "dec-g2",
        "prompt": "Choose the more useful split for important: im/por/tant or imp/o/rt/ant.",
        "answer": "im/por/tant",
        "reasoning": "Each chunk is pronounceable and preserves common sound patterns."
      },
      {
        "id": "dec-g3",
        "prompt": "Read impossible in: 'The locked gate made the shortcut impossible.' What parts help?",
        "answer": "im/poss/i/ble or im + possible",
        "reasoning": "Recognizing im- and possible supports both decoding and meaning."
      },
      {
        "id": "dec-g4",
        "prompt": "A first attempt at musician sounds wrong. What can you adjust?",
        "answer": "Try mu/si/cian and adjust the final chunk to the common /shun/ sound.",
        "reasoning": "The learner changes one chunk instead of restarting or guessing."
      },
      {
        "id": "dec-g5",
        "prompt": "Mark and read environmental.",
        "answer": "en/vi/ron/men/tal",
        "reasoning": "Five pronounceable chunks preserve all letters and can be blended in pairs."
      }
    ],
    "masteryItems": [
      {
        "id": "dec-mc1",
        "prompt": "Mark useful parts and read unhappiness.",
        "answer": "un/hap/pi/ness; un + happy + ness"
      },
      {
        "id": "dec-mc2",
        "prompt": "Choose the useful split for celebration: cel/e/bra/tion or ce/lebr/at/ion.",
        "answer": "cel/e/bra/tion"
      },
      {
        "id": "dec-mc3",
        "prompt": "Read miscommunication and name one meaningful part.",
        "answer": "mis/com/mu/ni/ca/tion; mis- or communication"
      },
      {
        "id": "dec-mc4",
        "prompt": "In 'The desert temperature changed rapidly,' decode temperature.",
        "answer": "tem/per/a/ture"
      },
      {
        "id": "dec-mc5",
        "prompt": "Explain what to do when the first pronunciation does not fit the sentence.",
        "answer": "Adjust one chunk or vowel sound, blend again, and recheck the sentence."
      },
      {
        "id": "dec-mc6",
        "prompt": "Decode biodegradable using word parts or syllables.",
        "answer": "bi/o/de/grad/a/ble; bio + degrad(e) + able is also useful"
      }
    ],
    "masteryPolicy": "This check shows readiness, not final mastery. Record results across at least two different practice sets on different occasions. Do not mark mastery from one successful item or one successful session.",
    "noMediaFallback": "Write the word in large print. Use pencil boxes around prefixes, bases, suffixes, and vowel teams. Add slashes between chunks. The learner points and blends; no audio, camera, or image is required.",
    "parentTeacherReviewNote": "Record which support changed the learner's response: chunking, affix highlighting, blending, or context checking. Avoid labels or diagnoses. A pattern across several sessions can guide instruction, but this package does not diagnose a reading condition.",
    "misconceptions": [
      {
        "id": "dec-m1",
        "label": "First-chunk guessing",
        "pattern": "The learner reads the first syllable or first few letters and substitutes a familiar word.",
        "evidenceToDistinguish": [
          "Accurate on isolated syllable chunks but inaccurate on the whole word",
          "Chooses a word that fits the beginning but not all letters"
        ],
        "responsePlan": "Cover later chunks, reveal one chunk at a time, then blend every chunk before checking context."
      },
      {
        "id": "dec-m2",
        "label": "Every vowel means a new syllable",
        "pattern": "The learner splits vowel teams or silent-e patterns apart.",
        "evidenceToDistinguish": [
          "Splits team as te/am or hope as ho/pe",
          "Performs better after vowel teams are boxed"
        ],
        "responsePlan": "Box vowel teams and silent-e patterns before drawing syllable boundaries."
      },
      {
        "id": "dec-m3",
        "label": "Word parts are invisible",
        "pattern": "The learner does not notice a familiar prefix, base, suffix, or compound part.",
        "evidenceToDistinguish": [
          "Reads helpful but not unhelpful",
          "Can explain un- and -ful after they are highlighted"
        ],
        "responsePlan": "Color-code prefix, base, and suffix; read the base first, then rebuild the word."
      },
      {
        "id": "dec-m4",
        "label": "Chunks do not blend",
        "pattern": "The learner reads each chunk correctly but pauses so long that the whole word is not recognized.",
        "evidenceToDistinguish": [
          "Accurate chunk reading",
          "Whole-word attempt loses or repeats a syllable"
        ],
        "responsePlan": "Use a smooth sweep under two chunks at a time, then blend the full word."
      },
      {
        "id": "dec-m5",
        "label": "No check-and-adjust step",
        "pattern": "The learner accepts a pronunciation that does not sound like a word or fit the sentence.",
        "evidenceToDistinguish": [
          "Can produce a plausible alternate vowel sound when prompted",
          "Does not independently ask whether the word makes sense"
        ],
        "responsePlan": "Add the final question: 'Does it sound like a word and make sense here?' Then retry one chunk only."
      }
    ]
  },
  {
    "sequenceId": "ela-04-06-seq-02-sentence-completeness",
    "title": "Build Complete Sentences",
    "summary": "Learners identify subjects and predicates, repair fragments and run-ons, and choose punctuation that matches a sentence's job.",
    "skillId": "ela.language.sentence.complete",
    "gradeBand": {
      "min": 4,
      "max": 6,
      "label": "Grades 4–6",
      "extensible": true
    },
    "modes": {
      "showMe": {
        "title": "Show Me",
        "example": "The two puppies chased the red ball.",
        "steps": [
          "Highlight 'The two puppies' as the complete subject.",
          "Highlight 'chased the red ball' as the complete predicate.",
          "Ask whether the thought feels finished.",
          "Place a period because the sentence tells something."
        ],
        "learnerAction": "Tap or point to the subject, predicate, and punctuation."
      },
      "talkMeThroughIt": {
        "title": "Talk Me Through It",
        "prompts": [
          "Who or what is this about?",
          "What does that subject do, have, or feel?",
          "Does the thought feel finished?",
          "Is there one complete thought or more than one?",
          "Which punctuation matches the sentence's job?"
        ],
        "tutorConstraint": "Do not rewrite the learner's idea; prompt the learner to supply the missing part or connector."
      },
      "letsDoOneTogether": {
        "title": "Let's Do One Together",
        "example": "Because the bus was late.",
        "steps": [
          "Tutor notices that because makes the reader expect more.",
          "Learner says what happened because the bus was late.",
          "Together build: 'Because the bus was late, we entered quietly.'",
          "Learner chooses the end punctuation."
        ],
        "sharedResponsibility": "The learner supplies the completing idea and makes the final edit."
      },
      "differentExample": {
        "title": "Different Example",
        "example": "The bell rang everyone packed up.",
        "whyDifferent": "This example has two complete thoughts instead of a missing part.",
        "steps": [
          "Box 'The bell rang.'",
          "Box 'Everyone packed up.'",
          "Choose a period or a comma plus and.",
          "Learner writes the final version."
        ]
      }
    },
    "guidedPractice": [
      {
        "id": "sen-g1",
        "prompt": "Is 'The striped umbrella by the door.' complete? Repair it if needed.",
        "answer": "Fragment; add a predicate, such as 'The striped umbrella by the door belongs to Ana.'",
        "reasoning": "The group has a subject but no finite predicate."
      },
      {
        "id": "sen-g2",
        "prompt": "Underline the subject and circle the predicate: 'After practice, our team filled the water bottles.'",
        "answer": "Subject: our team. Predicate: filled the water bottles.",
        "reasoning": "After practice is an introductory phrase, not the subject."
      },
      {
        "id": "sen-g3",
        "prompt": "Repair: 'I finished my model it still needed paint.'",
        "answer": "I finished my model, but it still needed paint. OR I finished my model. It still needed paint.",
        "reasoning": "Two complete thoughts need separation or a connector."
      },
      {
        "id": "sen-g4",
        "prompt": "Choose punctuation: 'What a huge kite__'",
        "answer": "!",
        "reasoning": "The sentence expresses strong feeling."
      },
      {
        "id": "sen-g5",
        "prompt": "Revise for a formal class report while preserving meaning: 'We was checking the plants every day.'",
        "answer": "We were checking the plants every day.",
        "reasoning": "Only the requested school-writing convention changes; the learner's idea stays intact."
      }
    ],
    "masteryItems": [
      {
        "id": "sen-mc1",
        "prompt": "Label subject and predicate: 'The old bridge shook in the wind.'",
        "answer": "Subject: The old bridge. Predicate: shook in the wind."
      },
      {
        "id": "sen-mc2",
        "prompt": "Repair: 'While the soup simmered.'",
        "answer": "Add a complete thought, such as 'While the soup simmered, I washed the cutting board.'"
      },
      {
        "id": "sen-mc3",
        "prompt": "Repair: 'The lights flickered we found a flashlight.'",
        "answer": "The lights flickered, so we found a flashlight. OR two sentences."
      },
      {
        "id": "sen-mc4",
        "prompt": "Choose punctuation: 'Where did the trail begin__'",
        "answer": "?"
      },
      {
        "id": "sen-mc5",
        "prompt": "Explain why 'Running beside the fence.' is usually a fragment.",
        "answer": "It does not name who or what is running and does not complete the thought."
      },
      {
        "id": "sen-mc6",
        "prompt": "Revise one sentence from a provided ungraded draft for formal school writing, then explain the convention you changed.",
        "answer": "Answers vary; the learner must preserve the original meaning and identify the convention changed."
      }
    ],
    "masteryPolicy": "This check shows readiness, not final mastery. Confirm the skill across at least two different sets or writing samples. Do not infer ability from dialect, spelling, handwriting, or one correct item.",
    "noMediaFallback": "Write subjects on one set of paper slips, predicates on another, and punctuation on small cards. The learner physically builds, breaks, and repairs sentences. No camera, microphone, or identifiable photo is needed.",
    "parentTeacherReviewNote": "Note the specific need: missing subject, missing predicate, dependent fragment, run-on, or punctuation. Keep dialect and home language separate from the instructional target. Teach formal conventions as an additional register, not as proof that one way of speaking is better.",
    "misconceptions": [
      {
        "id": "sen-m1",
        "label": "A capital and period make any sentence complete",
        "pattern": "The learner judges punctuation but does not check for a subject, predicate, and complete thought.",
        "evidenceToDistinguish": [
          "Accepts 'After the game.' as complete",
          "Can add punctuation correctly to complete sentences"
        ],
        "responsePlan": "Use subject and predicate tiles before adding punctuation."
      },
      {
        "id": "sen-m2",
        "label": "The subject is always the first word",
        "pattern": "The learner labels an introductory phrase or modifier as the subject.",
        "evidenceToDistinguish": [
          "In 'After lunch, the class rehearsed,' labels After as the subject",
          "Finds the subject after asking who or what did the action"
        ],
        "responsePlan": "Temporarily move the introductory phrase away and locate the core sentence."
      },
      {
        "id": "sen-m3",
        "label": "Any verb-looking word creates a predicate",
        "pattern": "The learner treats an -ing phrase without a helping verb as a complete predicate.",
        "evidenceToDistinguish": [
          "Accepts 'The dog barking loudly.'",
          "Repairs it after adding was"
        ],
        "responsePlan": "Compare 'dog barking' with 'dog was barking' using a predicate tile."
      },
      {
        "id": "sen-m4",
        "label": "A long sentence is a run-on",
        "pattern": "The learner uses length instead of clause boundaries to judge run-ons.",
        "evidenceToDistinguish": [
          "Calls a long correctly joined sentence a run-on",
          "Misses a short fused sentence such as 'I came I saw'"
        ],
        "responsePlan": "Box each complete thought and inspect how the boxes are joined."
      },
      {
        "id": "sen-m5",
        "label": "Dialect difference means low ability",
        "pattern": "An adult or system confuses a dialect feature with lack of comprehension.",
        "evidenceToDistinguish": [
          "Learner can explain subject and predicate accurately in their own speech variety",
          "Learner can code-switch after the formal convention is explicitly taught"
        ],
        "responsePlan": "Name the target as a school-writing convention, preserve meaning, and assess the actual sentence skill separately."
      }
    ]
  },
  {
    "sequenceId": "ela-04-06-seq-03-main-idea-details",
    "title": "Find the Main Idea and Supporting Details",
    "summary": "Learners separate topic from main idea, select details that truly support it, and explain the connection in their own words.",
    "skillId": "ela.reading.main-idea.details",
    "gradeBand": {
      "min": 4,
      "max": 6,
      "label": "Grades 4–6",
      "extensible": true
    },
    "modes": {
      "showMe": {
        "title": "Show Me",
        "example": "The Night Garden passage",
        "steps": [
          "Name the topic: night flowers and pollinators.",
          "Combine repeated information: scent attracts insects; insects carry pollen; plants make seeds.",
          "Write a main-idea sentence that includes the topic and the author's point.",
          "Connect each supporting detail with an arrow."
        ],
        "learnerAction": "Point to the sentence that supports each arrow."
      },
      "talkMeThroughIt": {
        "title": "Talk Me Through It",
        "prompts": [
          "What topic appears again and again?",
          "What does the author want us to understand about that topic?",
          "Which two details connect to your idea?",
          "Is your idea too broad or just one detail?",
          "Can you point to evidence in the passage?"
        ],
        "tutorConstraint": "Ask for evidence before confirming an answer. Do not require speed."
      },
      "letsDoOneTogether": {
        "title": "Let's Do One Together",
        "examplePassage": "A town placed small libraries in old newspaper boxes. Neighbors donated books. Readers could take one book and leave another. The boxes made sharing books easy in places far from the main library.",
        "steps": [
          "Tutor identifies the topic: neighborhood book boxes.",
          "Learner states what happened: they made sharing easier.",
          "Together form the main idea.",
          "Learner chooses two supporting details and explains each connection."
        ],
        "sharedResponsibility": "The learner states the final main idea in their own words."
      },
      "differentExample": {
        "title": "Different Example",
        "examplePassage": "Octopuses can squeeze through tiny openings because they have no rigid skeleton. Their soft bodies can change shape, but their beaks are hard. If the beak fits through an opening, the rest of the octopus usually can too.",
        "whyDifferent": "This science passage explains one cause-and-effect idea rather than a process with several actors.",
        "steps": [
          "Topic: octopus movement.",
          "Main idea: a soft body allows an octopus to fit through small spaces, limited by its beak.",
          "Details: no rigid skeleton; body changes shape; beak must fit."
        ]
      }
    },
    "guidedPractice": [
      {
        "id": "mid-g1",
        "passage": "During winter, some city workers spread beet juice mixed with salt on icy roads. The mixture helps salt stick to the pavement and work at lower temperatures. Using it can reduce the total amount of salt needed.",
        "prompt": "State the main idea.",
        "answer": "A beet-juice mixture helps road salt work better in winter and can reduce how much salt is used.",
        "reasoning": "The answer combines all three sentences rather than repeating one detail.",
        "rights": "original"
      },
      {
        "id": "mid-g2",
        "passage": "A school added quiet corners to several classrooms. Each corner had soft lighting, a timer, and simple breathing cards. Students could use the space briefly and then return to learning. Teachers reported fewer interruptions during difficult transitions.",
        "prompt": "Choose two supporting details for the idea that quiet corners helped students reset and return to learning.",
        "answer": "Students used the space briefly before returning; teachers reported fewer interruptions.",
        "reasoning": "Both details show the effect of the quiet corners.",
        "rights": "original"
      },
      {
        "id": "mid-g3",
        "passage": "Honeybees share information through movement. A worker bee returning to the hive performs a waggle dance. The angle and length of the dance help other bees locate food.",
        "prompt": "Which is topic only: 'honeybees' or 'Honeybees use a dance to show other bees where food is'?",
        "answer": "Honeybees is topic only; the full sentence is the main idea.",
        "reasoning": "The main idea states what the author explains about the topic.",
        "rights": "original"
      },
      {
        "id": "mid-g4",
        "passage": "The library's seed exchange began with twelve envelopes. Gardeners added extra seeds from vegetables and flowers. By spring, the cabinet held more than two hundred labeled packets for neighbors to share.",
        "prompt": "Explain why 'The cabinet held more than two hundred packets' is a supporting detail, not the full main idea.",
        "answer": "It is one result showing that the seed exchange grew through community sharing.",
        "reasoning": "The main idea must include the exchange and its growth, not only the final number.",
        "rights": "original"
      }
    ],
    "masteryItems": [
      {
        "id": "mid-mc1",
        "prompt": "State the topic of mid-mp1.",
        "answer": "rooftop gardens and building heat"
      },
      {
        "id": "mid-mc2",
        "prompt": "State the main idea of mid-mp1.",
        "answer": "Rooftop gardens can cool buildings because soil, plants, and evaporation reduce roof heat."
      },
      {
        "id": "mid-mc3",
        "prompt": "Give two supporting details from mid-mp1 and explain one connection.",
        "answer": "Examples: soil and plants absorb less heat; evaporation carries heat away. The details explain how cooling happens."
      },
      {
        "id": "mid-mc4",
        "prompt": "State the main idea of mid-mp2.",
        "answer": "A planned tuning order made orchestra rehearsal faster and easier to hear."
      },
      {
        "id": "mid-mc5",
        "prompt": "Which detail shows the result of the new routine?",
        "answer": "Tuning took less time and musicians could hear their own instruments."
      },
      {
        "id": "mid-mc6",
        "prompt": "Write one answer that is too broad for mid-mp2, then improve it.",
        "answer": "Too broad example: 'Routines help.' Improved: 'A planned tuning order made rehearsal more efficient.'"
      }
    ],
    "masteryPolicy": "This check shows readiness, not final mastery. Use at least two passages of different structures on different occasions before confirming mastery.",
    "noMediaFallback": "Draw one large center box for the main idea and three smaller boxes for details. Use arrows or string to show connections. Read passages aloud when decoding would hide comprehension, but record that accommodation. No camera or photograph is required.",
    "parentTeacherReviewNote": "Record whether difficulty is with recalling details, distinguishing topic from main idea, choosing relevant evidence, or explaining the connection. Do not use reading speed, accent, or vocabulary unfamiliarity as a proxy for comprehension.",
    "misconceptions": [
      {
        "id": "mid-m1",
        "label": "Topic equals main idea",
        "pattern": "The learner answers with one or two topic words instead of a complete statement.",
        "evidenceToDistinguish": [
          "Says 'moths' or 'flowers' for the main idea",
          "Can state what the passage says after a sentence frame is offered"
        ],
        "responsePlan": "Use the frame: 'The passage is mostly about ___, and it says ___.'"
      },
      {
        "id": "mid-m2",
        "label": "Interesting detail wins",
        "pattern": "The learner chooses the most surprising detail rather than the idea supported by most of the passage.",
        "evidenceToDistinguish": [
          "Can recall a vivid fact",
          "Cannot connect at least two other details to the selected idea"
        ],
        "responsePlan": "Place each detail under a candidate main idea and count meaningful connections."
      },
      {
        "id": "mid-m3",
        "label": "Too broad",
        "pattern": "The answer could fit many unrelated passages.",
        "evidenceToDistinguish": [
          "Answers 'Nature is important'",
          "Improves when required to include two key passage words"
        ],
        "responsePlan": "Ask which exact kind of nature and what the author explains about it."
      },
      {
        "id": "mid-m4",
        "label": "Too narrow",
        "pattern": "The learner selects one supporting detail as the main idea.",
        "evidenceToDistinguish": [
          "Answer matches only one sentence",
          "Cannot place the other details beneath it"
        ],
        "responsePlan": "Zoom out: combine what two or three details have in common."
      },
      {
        "id": "mid-m5",
        "label": "Background knowledge replaces evidence",
        "pattern": "The learner supplies a true fact that the passage does not support.",
        "evidenceToDistinguish": [
          "Fact may be accurate",
          "Learner cannot point to a sentence or paraphrase supporting it"
        ],
        "responsePlan": "Use two columns: 'In the text' and 'I already knew.' Both are valuable, but only the first answers this question."
      }
    ]
  },
  {
    "sequenceId": "ela-04-06-seq-04-paragraph-revision",
    "title": "Organize and Revise a Clear Paragraph",
    "summary": "Learners arrange ideas around one focus, strengthen connections and clarity, compare before-and-after revisions, and make the final revision in their own voice.",
    "skillId": "ela.writing.paragraph.organize-revise",
    "gradeBand": {
      "min": 4,
      "max": 6,
      "label": "Grades 4–6",
      "extensible": true
    },
    "modes": {
      "showMe": {
        "title": "Show Me",
        "example": "A separate three-sentence draft about planting basil",
        "steps": [
          "Name the focus: how I planted basil.",
          "Move the planting step before the result.",
          "Place an unrelated sentence in the parking lot.",
          "Clarify one vague word, then stop so the writer can revise their own draft."
        ],
        "learnerAction": "Explain why each card moves before touching the practice draft."
      },
      "talkMeThroughIt": {
        "title": "Talk Me Through It",
        "prompts": [
          "What do you want the reader to understand?",
          "Which sentence helps that focus most?",
          "Does any good detail belong somewhere else?",
          "What order will help the reader follow?",
          "Which one place is unclear or repetitive?",
          "How will you revise it in words that sound like you?"
        ],
        "tutorConstraint": "Never supply a complete replacement paragraph for graded work. Ask the learner to make and enter the final revision."
      },
      "letsDoOneTogether": {
        "title": "Let's Do One Together",
        "exampleDraft": [
          "Our class tested paper bridges.",
          "The bridge bent when we added the fourth book.",
          "We folded the next strip into a triangle shape.",
          "The triangle bridge held seven books."
        ],
        "steps": [
          "Tutor and learner name the focus.",
          "Learner orders test, problem, change, result.",
          "Tutor models adding one connector on a different sentence.",
          "Learner chooses and writes the final connector in this draft."
        ],
        "sharedResponsibility": "The tutor models the process; the learner makes the actual revision."
      },
      "differentExample": {
        "title": "Different Example",
        "exampleDraft": [
          "The community pool should add a shaded bench.",
          "Families wait beside the pool during lessons.",
          "Shade would make the waiting area safer and more comfortable.",
          "The vending machine is blue."
        ],
        "whyDifferent": "This paragraph is organized as claim and reasons, not as time order.",
        "steps": [
          "Identify the claim.",
          "Place reasons after the claim.",
          "Move the unrelated vending-machine detail to the parking lot.",
          "Ask the learner for a closing sentence; do not write it for them."
        ]
      }
    },
    "guidedPractice": [
      {
        "id": "par-g1",
        "prompt": "Order these sentence cards: 'The seedlings stood upright.' 'We moved them closer to the window.' 'At first, the stems leaned toward the light.'",
        "answer": "At first...; We moved...; The seedlings stood...",
        "reasoning": "The order shows problem, action, and result."
      },
      {
        "id": "par-g2",
        "prompt": "Which detail belongs in the parking lot for a paragraph about training a puppy to wait at the door: 'We practiced with a hand signal,' 'The leash is red,' or 'We rewarded calm waiting'?",
        "answer": "The leash is red.",
        "reasoning": "It does not explain the training process unless color matters to the focus."
      },
      {
        "id": "par-g3",
        "prompt": "Revise one vague word: 'The model did a thing when the fan turned on.'",
        "answer": "Answers vary, such as 'The model spun when the fan turned on.'",
        "reasoning": "A precise action verb improves clarity without making the voice unnatural."
      },
      {
        "id": "par-g4",
        "prompt": "Combine without erasing voice: 'I tested the ramp. I tested it again. I changed the height.'",
        "answer": "Answers vary, such as 'I tested the ramp again after I changed the height.'",
        "reasoning": "The revision reduces repetition and shows the relationship."
      },
      {
        "id": "par-g5",
        "prompt": "Name the organizing pattern for a paragraph that explains why a rule changed and what happened afterward.",
        "answer": "Cause and effect.",
        "reasoning": "The relationship is reasons and results, not merely time order."
      }
    ],
    "masteryItems": [
      {
        "id": "par-mc1",
        "prompt": "Write the paragraph focus in one sentence.",
        "answer": "Designing and improving an egg carrier so the egg survives a drop."
      },
      {
        "id": "par-mc2",
        "prompt": "Identify the unrelated sentence and move it to the parking lot.",
        "answer": "My shoes have white laces."
      },
      {
        "id": "par-mc3",
        "prompt": "Arrange the remaining cards in a clear order.",
        "answer": "Goal; first design; failure and cause; revision; successful result. The opening design sentence may come before the goal sentence if the flow stays clear."
      },
      {
        "id": "par-mc4",
        "prompt": "Choose one sentence connection to strengthen and explain why.",
        "answer": "Answers vary; the explanation must name the relationship, such as cause/effect or sequence."
      },
      {
        "id": "par-mc5",
        "prompt": "Revise one vague, repetitive, or choppy place in your own words.",
        "answer": "Answers vary; revision must preserve meaning and improve clarity."
      },
      {
        "id": "par-mc6",
        "prompt": "Make the final paragraph revision yourself, then use the checklist to explain two decisions.",
        "answer": "No single model paragraph is provided. Accept a focused, logically ordered paragraph with related details and two explained revision decisions."
      }
    ],
    "masteryPolicy": "This check shows readiness, not final mastery. The learner must revise at least two original, ungraded practice paragraphs on different occasions. A tutor may provide criteria and questions but may not complete graded writing.",
    "noMediaFallback": "Copy each sentence onto a separate paper strip. Use a labeled parking-lot envelope for unrelated details. Arrange strips on a table, then the learner writes the final version. No camera, photograph, or online service is required.",
    "parentTeacherReviewNote": "Review decisions rather than replacing the paragraph. Ask the learner to explain focus, order, one removed or moved detail, and one clarity change. Preserve dialect and voice. For graded writing, the tutor should stop at prompts, criteria, and a separate modeled example.",
    "misconceptions": [
      {
        "id": "par-m1",
        "label": "Revision means fixing spelling only",
        "pattern": "The learner edits surface errors but does not consider focus, order, clarity, or support.",
        "evidenceToDistinguish": [
          "Corrects capitals and spelling",
          "Leaves an unrelated sentence and confusing order"
        ],
        "responsePlan": "Separate revision from editing. Revise ideas and organization first; edit conventions later."
      },
      {
        "id": "par-m2",
        "label": "Every sentence must stay",
        "pattern": "The learner believes deleting or moving a sentence means the sentence was bad.",
        "evidenceToDistinguish": [
          "Identifies an unrelated detail but refuses to remove it",
          "Accepts moving the detail to a different paragraph"
        ],
        "responsePlan": "Use a parking-lot box for good details that do not belong in this paragraph."
      },
      {
        "id": "par-m3",
        "label": "Order means chronological only",
        "pattern": "The learner tries to use first-next-finally even when cause, importance, or comparison would be clearer.",
        "evidenceToDistinguish": [
          "Adds time words to an explanation paragraph",
          "Can sort once the organizing relationship is named"
        ],
        "responsePlan": "Offer four organizing paths: time, cause/effect, most important, or compare/contrast."
      },
      {
        "id": "par-m4",
        "label": "Better writing means harder words",
        "pattern": "The learner replaces natural language with unfamiliar vocabulary that changes voice or meaning.",
        "evidenceToDistinguish": [
          "Uses a thesaurus word incorrectly",
          "Original sentence was clear and specific"
        ],
        "responsePlan": "Prefer precise familiar words. Ask whether the revision sounds like the writer and says exactly what they mean."
      },
      {
        "id": "par-m5",
        "label": "Tutor should finish the paragraph",
        "pattern": "The learner waits for a complete replacement draft or copies one without making decisions.",
        "evidenceToDistinguish": [
          "Can choose between two options but does not generate the final wording",
          "Improves when given a sentence frame or one modeled example"
        ],
        "responsePlan": "Model on a different example, then return the decision and final wording to the learner."
      }
    ]
  }
];
