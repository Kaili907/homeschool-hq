# Decode Unfamiliar Multisyllable Words

**Sequence ID:** `ela-04-06-seq-01-multisyllable-decoding`  
**Lesson ID:** `ela-04-06-l01-decode-multisyllable-words`  
**Skill ID:** `ela.word.decoding.multisyllable`  
**Grade band:** Grades 4–6  
**Summary:** Learners use syllable patterns, morphemes, and a check-and-adjust routine to read unfamiliar longer words without guessing from the first letters alone.

## Prerequisites

- `ela.word.vowels-and-teams` — **Recognize common vowel sounds and vowel teams**: Can identify the likely vowel sound in one-syllable words such as ship, hope, team, and coin.
- `ela.word.closed-open-syllables` — **Read common closed and open syllables**: Can read short chunks such as fan, rob, ti, and pro.
- `ela.word.common-affixes` — **Recognize a few common prefixes and suffixes**: Can explain that un- can mean not and -ful can mean full of.

## Objectives
- Mark useful word parts before reading the whole word.
- Divide a longer word into pronounceable chunks and blend the chunks.
- Use prefixes, bases, suffixes, and sentence meaning to check a decoding attempt.
- Adjust a split or vowel sound when the first attempt does not make sense.

## Instructional and learner-safety rules
- Teach the skill instead of rewriting all student work.
- Preserve the learner's voice.
- Ask the learner to make the final revision.
- Use respectful, non-shaming language about spelling, grammar, reading speed, dialect, and vocabulary.
- Never treat dialect as evidence of low ability.
- Do not diagnose dyslexia or any other condition.
- Do not complete graded writing.
- Do not claim mastery from one successful item.
- Switch to another explanation when the first explanation does not help.
- Never require a camera or identifiable child photograph.
- Use only original or public-domain passages.

## Diagnostic assessment

**Purpose:** Identify whether the learner mainly needs support with syllable division, word-part recognition, blending, or checking the result in context.

**Directions:** The learner may mark slashes, circle word parts, or read aloud to a trusted adult. Do not time the assessment.

### dec-d1

Mark useful chunks in the word unhelpful, then read the whole word.

*Evidence tags: morpheme-recognition, blending.*

### dec-d2

Which split is most useful for reading fantastic?

- f/a/n/t/a/s/t/i/c
- fan/tas/tic
- fant/astic
- fa/ntas/tic

*Evidence tags: syllable-division.*

### dec-d3

Read preview. Which meaningful parts help you?

*Evidence tags: morpheme-recognition.*

### dec-d4

A learner reads transportation as trans-port. What is the best next move?

- Guess from the picture
- Stop after two chunks
- Mark more vowel sounds and continue: trans/por/ta/tion
- Skip the word every time

*Evidence tags: complete-blending, persistence.*

### dec-d5

In the sentence 'The microscopic seed looked like a speck,' mark chunks in microscopic and try the word.

*Evidence tags: syllable-division, context-check.*

### dec-d6

You try re/mark/a/ble and the word sounds like 'remarkable.' What should you do next?

- Check whether remarkable makes sense in the sentence
- Change every vowel sound
- Use only the first syllable
- Assume a long word is impossible

*Evidence tags: context-check.*

## Likely misconception patterns and distinguishing evidence

### dec-m1 — First-chunk guessing

**Pattern:** The learner reads the first syllable or first few letters and substitutes a familiar word.

**Evidence that distinguishes it:**
- Accurate on isolated syllable chunks but inaccurate on the whole word
- Chooses a word that fits the beginning but not all letters

**Response:** Cover later chunks, reveal one chunk at a time, then blend every chunk before checking context.

### dec-m2 — Every vowel means a new syllable

**Pattern:** The learner splits vowel teams or silent-e patterns apart.

**Evidence that distinguishes it:**
- Splits team as te/am or hope as ho/pe
- Performs better after vowel teams are boxed

**Response:** Box vowel teams and silent-e patterns before drawing syllable boundaries.

### dec-m3 — Word parts are invisible

**Pattern:** The learner does not notice a familiar prefix, base, suffix, or compound part.

**Evidence that distinguishes it:**
- Reads helpful but not unhelpful
- Can explain un- and -ful after they are highlighted

**Response:** Color-code prefix, base, and suffix; read the base first, then rebuild the word.

### dec-m4 — Chunks do not blend

**Pattern:** The learner reads each chunk correctly but pauses so long that the whole word is not recognized.

**Evidence that distinguishes it:**
- Accurate chunk reading
- Whole-word attempt loses or repeats a syllable

**Response:** Use a smooth sweep under two chunks at a time, then blend the full word.

### dec-m5 — No check-and-adjust step

**Pattern:** The learner accepts a pronunciation that does not sound like a word or fit the sentence.

**Evidence that distinguishes it:**
- Can produce a plausible alternate vowel sound when prompted
- Does not independently ask whether the word makes sense

**Response:** Add the final question: 'Does it sound like a word and make sense here?' Then retry one chunk only.

## Visual explanation plan

**Models:** Syllable division, Morpheme and word-part highlighting

**Command file:** `visuals/ela-04-06-seq-01.visual-board.json`

**Accessible description:** The word unpredictable is shown first as one word, then as color-coded parts un + predict + able, and finally as pronounceable chunks un/pre/dict/a/ble. A curved arrow blends the chunks back into the whole word.

## Spoken explanation

Long words become manageable when you look for useful parts. First, spot a prefix, base, suffix, or familiar word part. Next, mark the vowel sounds and divide the rest into chunks you can say. Blend the chunks from left to right. Then check: does the word sound real, and does it make sense in the sentence? If not, change one chunk and try again. Strong readers adjust; they do not have to get every word on the first try.


- Script: `narration/ela-04-06-seq-01.en.txt`
- Captions: `captions/ela-04-06-seq-01.en.vtt`
- Transcript: `transcripts/ela-04-06-seq-01.en.md`

## Show Me mode

**Example:** unpredictable
**Steps:**
- Highlight un-, predict, and -able.
- Mark pronounceable chunks: un/pre/dict/a/ble.
- Blend slowly, then smoothly: unpredictable.
- Check the sentence: 'The weather was unpredictable.' The word makes sense.
**Learner Action:** Point to each chunk as the tutor blends it.

## Talk Me Through It mode

**Prompts:**
- What familiar part do you see first?
- Where do you see vowel sounds or vowel teams?
- What chunk will you try first?
- Blend the chunks. Does that sound like a word?
- Does that word fit the sentence? What one chunk might you adjust?
**Tutor Constraint:** Ask one prompt at a time and wait for the learner's attempt.

## Let's Do One Together mode

**Example:** disagreement
**Steps:**
- Tutor marks dis- and -ment; learner identifies agree.
- Tutor and learner mark dis/a/gree/ment.
- Learner blends the first two chunks; tutor blends the last two.
- Learner says the full word and checks it in: 'Their disagreement ended after they listened.'
**Shared Responsibility:** The tutor models only the next step; the learner completes the final blend.

## Different Example mode

**Example:** carelessness
**Why Different:** This example begins with a familiar base and adds two suffixes instead of a prefix.
**Steps:**
- Highlight care + less + ness.
- Read the base care.
- Add less, then ness.
- Blend care/less/ness and check the meaning.

## Guided practice


### dec-g1

**Prompt:** Mark word parts and syllables in rereading.

**Answer:** re/read/ing

**Reasoning:** The prefix re-, base read, and suffix -ing make useful chunks.

### dec-g2

**Prompt:** Choose the more useful split for important: im/por/tant or imp/o/rt/ant.

**Answer:** im/por/tant

**Reasoning:** Each chunk is pronounceable and preserves common sound patterns.

### dec-g3

**Prompt:** Read impossible in: 'The locked gate made the shortcut impossible.' What parts help?

**Answer:** im/poss/i/ble or im + possible

**Reasoning:** Recognizing im- and possible supports both decoding and meaning.

### dec-g4

**Prompt:** A first attempt at musician sounds wrong. What can you adjust?

**Answer:** Try mu/si/cian and adjust the final chunk to the common /shun/ sound.

**Reasoning:** The learner changes one chunk instead of restarting or guessing.

### dec-g5

**Prompt:** Mark and read environmental.

**Answer:** en/vi/ron/men/tal

**Reasoning:** Five pronounceable chunks preserve all letters and can be blended in pairs.

## Independent mastery check

**Policy:** This check shows readiness, not final mastery. Record results across at least two different practice sets on different occasions. Do not mark mastery from one successful item or one successful session.

### dec-mc1

**Prompt:** Mark useful parts and read unhappiness.

**Answer-key criteria:** un/hap/pi/ness; un + happy + ness

### dec-mc2

**Prompt:** Choose the useful split for celebration: cel/e/bra/tion or ce/lebr/at/ion.

**Answer-key criteria:** cel/e/bra/tion

### dec-mc3

**Prompt:** Read miscommunication and name one meaningful part.

**Answer-key criteria:** mis/com/mu/ni/ca/tion; mis- or communication

### dec-mc4

**Prompt:** In 'The desert temperature changed rapidly,' decode temperature.

**Answer-key criteria:** tem/per/a/ture

### dec-mc5

**Prompt:** Explain what to do when the first pronunciation does not fit the sentence.

**Answer-key criteria:** Adjust one chunk or vowel sound, blend again, and recheck the sentence.

### dec-mc6

**Prompt:** Decode biodegradable using word parts or syllables.

**Answer-key criteria:** bi/o/de/grad/a/ble; bio + degrad(e) + able is also useful

### Readiness rules
- At least 5 of 6 items are accurate on two different sets or occasions.
- The learner independently uses a check-and-adjust step at least once.
- No persistent first-chunk guessing pattern is present in the latest set.
- A teacher or parent reviews oral decoding when oral reading evidence is used.

## Reteaching branch

**Enter when:**
- The learner can read basic syllables but misses multisyllable words
- The learner improves with highlighted chunks

**Path:**
- Use only two-syllable compound words.
- Move to prefix + base words.
- Add suffixes.
- Return to a four-syllable word with the same routine.

**Alternate explanation:** Treat the word like a train: each car is a chunk, but every car must stay connected in order.

## Prerequisite-remediation branch

**Enter when:**
- Common one-syllable vowel patterns are not yet stable
- The learner cannot read the individual chunks even after division

**Path:**
- Practice one vowel pattern at a time.
- Sort closed, open, silent-e, and vowel-team examples.
- Blend two familiar syllables.
- Return to the diagnostic with untimed support.

**Exit evidence:** Reads 8 of 10 taught one-syllable patterns and blends two familiar chunks without guessing.

## Parent/teacher review note

Record which support changed the learner's response: chunking, affix highlighting, blending, or context checking. Avoid labels or diagnoses. A pattern across several sessions can guide instruction, but this package does not diagnose a reading condition.

## No-media fallback

Write the word in large print. Use pencil boxes around prefixes, bases, suffixes, and vowel teams. Add slashes between chunks. The learner points and blends; no audio, camera, or image is required.

## Answer key with reasoning

| Item | Source | Answer / criteria | Reasoning |
|---|---|---|---|
| `dec-d1` | diagnostic | ["un/help/ful"] | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `dec-d2` | diagnostic | fan/tas/tic | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `dec-d3` | diagnostic | ["pre + view", "pre/view"] | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `dec-d4` | diagnostic | Mark more vowel sounds and continue: trans/por/ta/tion | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `dec-d5` | diagnostic | ["mi/cro/scop/ic", "micro/scop/ic"] | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `dec-d6` | diagnostic | Check whether remarkable makes sense in the sentence | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `dec-g1` | guided-practice | re/read/ing | The prefix re-, base read, and suffix -ing make useful chunks. |
| `dec-g2` | guided-practice | im/por/tant | Each chunk is pronounceable and preserves common sound patterns. |
| `dec-g3` | guided-practice | im/poss/i/ble or im + possible | Recognizing im- and possible supports both decoding and meaning. |
| `dec-g4` | guided-practice | Try mu/si/cian and adjust the final chunk to the common /shun/ sound. | The learner changes one chunk instead of restarting or guessing. |
| `dec-g5` | guided-practice | en/vi/ron/men/tal | Five pronounceable chunks preserve all letters and can be blended in pairs. |
| `dec-mc1` | mastery | un/hap/pi/ness; un + happy + ness | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `dec-mc2` | mastery | cel/e/bra/tion | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `dec-mc3` | mastery | mis/com/mu/ni/ca/tion; mis- or communication | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `dec-mc4` | mastery | tem/per/a/ture | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `dec-mc5` | mastery | Adjust one chunk or vowel sound, blend again, and recheck the sentence. | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `dec-mc6` | mastery | bi/o/de/grad/a/ble; bio + degrad(e) + able is also useful | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |

## Source and rights note

All sentences and practice items in this sequence are original to Manuel Academy English v1. No third-party passage text is included.
