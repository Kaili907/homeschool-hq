# Build Complete Sentences

**Sequence ID:** `ela-04-06-seq-02-sentence-completeness`  
**Lesson ID:** `ela-04-06-l02-complete-sentences`  
**Skill ID:** `ela.language.sentence.complete`  
**Grade band:** Grades 4–6  
**Summary:** Learners identify subjects and predicates, repair fragments and run-ons, and choose punctuation that matches a sentence's job.

## Prerequisites

- `ela.language.nouns-verbs` — **Recognize common nouns, pronouns, and verbs**: Can point to who or what and the action or state in a short sentence.
- `ela.language.capital-endmark` — **Use capitals and basic end punctuation**: Can capitalize the first word and choose a period or question mark in a simple sentence.

## Objectives
- Identify the complete subject and complete predicate in a sentence.
- Tell whether a group of words expresses a complete thought.
- Repair fragments and run-ons without changing the learner's intended meaning.
- Choose punctuation based on whether the sentence tells, asks, exclaims, or joins ideas.

## Instructional and learner-safety rules
- Teach the skill instead of rewriting all student work.
- Preserve the learner's voice.
- Ask the learner to make the final revision.
- Use respectful, non-shaming language about spelling, grammar, reading speed, dialect, and vocabulary.
- Never treat dialect as evidence of low ability.
- Do not diagnose dyslexia or any other condition.
- Do not complete graded writing.
- Do not claim mastery from one successful item.
- Switch to another explanation when the first explanation does not help.
- Never require a camera or identifiable child photograph.
- Use only original or public-domain passages.

## Diagnostic assessment

**Purpose:** Distinguish missing-subject, missing-predicate, dependent-fragment, run-on, and punctuation-only needs.

**Directions:** Accept spoken answers, tile movement, or written edits. Evaluate the target skill, not handwriting or dialect.

### sen-d1

Which is a complete sentence?

- After the rain stopped.
- The rain stopped.
- Because the sidewalk was wet.
- Running to the porch.

*Evidence tags: complete-thought.*

### sen-d2

Add a subject to make this complete: '_____ raced across the field.'

*Evidence tags: subject.*

### sen-d3

Add a predicate to make this complete: 'The bright lantern _____. '

*Evidence tags: predicate.*

### sen-d4

Repair this run-on without changing its meaning: 'Mina opened the window the room cooled down.'

*Evidence tags: run-on.*

### sen-d5

Choose the punctuation: 'Did you bring the map__'

- .
- ?
- !
- ,

*Evidence tags: punctuation.*

### sen-d6

A class assignment asks for formal school English. Which edit changes only the convention, not the speaker's ability?

- We was ready. → We were ready.
- Delete the student's idea.
- Call the student's home language wrong.
- Replace every word with harder vocabulary.

*Evidence tags: register-awareness, dialect-respect.*

## Likely misconception patterns and distinguishing evidence

### sen-m1 — A capital and period make any sentence complete

**Pattern:** The learner judges punctuation but does not check for a subject, predicate, and complete thought.

**Evidence that distinguishes it:**
- Accepts 'After the game.' as complete
- Can add punctuation correctly to complete sentences

**Response:** Use subject and predicate tiles before adding punctuation.

### sen-m2 — The subject is always the first word

**Pattern:** The learner labels an introductory phrase or modifier as the subject.

**Evidence that distinguishes it:**
- In 'After lunch, the class rehearsed,' labels After as the subject
- Finds the subject after asking who or what did the action

**Response:** Temporarily move the introductory phrase away and locate the core sentence.

### sen-m3 — Any verb-looking word creates a predicate

**Pattern:** The learner treats an -ing phrase without a helping verb as a complete predicate.

**Evidence that distinguishes it:**
- Accepts 'The dog barking loudly.'
- Repairs it after adding was

**Response:** Compare 'dog barking' with 'dog was barking' using a predicate tile.

### sen-m4 — A long sentence is a run-on

**Pattern:** The learner uses length instead of clause boundaries to judge run-ons.

**Evidence that distinguishes it:**
- Calls a long correctly joined sentence a run-on
- Misses a short fused sentence such as 'I came I saw'

**Response:** Box each complete thought and inspect how the boxes are joined.

### sen-m5 — Dialect difference means low ability

**Pattern:** An adult or system confuses a dialect feature with lack of comprehension.

**Evidence that distinguishes it:**
- Learner can explain subject and predicate accurately in their own speech variety
- Learner can code-switch after the formal convention is explicitly taught

**Response:** Name the target as a school-writing convention, preserve meaning, and assess the actual sentence skill separately.

## Visual explanation plan

**Models:** Sentence-building tiles, Subject and predicate highlighting, Punctuation placement

**Command file:** `visuals/ela-04-06-seq-02.visual-board.json`

**Accessible description:** Blue tiles form the complete subject 'The two puppies.' Green tiles form the complete predicate 'chased the red ball.' A period tile snaps into place after the complete thought. A fragment tile is shown missing its partner, and a run-on is shown as two complete boxes without a connector.

## Spoken explanation

A complete sentence has a subject, a predicate, and a complete thought. The subject tells who or what the sentence is about. The predicate tells what the subject does, has, is, or feels. Punctuation shows the sentence's job, but punctuation cannot repair a missing idea by itself. When two complete thoughts run together, separate them or join them with a correct connector. Different ways of speaking are not signs of low ability. In school writing, we can learn the requested convention while keeping the writer's meaning and voice.


- Script: `narration/ela-04-06-seq-02.en.txt`
- Captions: `captions/ela-04-06-seq-02.en.vtt`
- Transcript: `transcripts/ela-04-06-seq-02.en.md`

## Show Me mode

**Example:** The two puppies chased the red ball.
**Steps:**
- Highlight 'The two puppies' as the complete subject.
- Highlight 'chased the red ball' as the complete predicate.
- Ask whether the thought feels finished.
- Place a period because the sentence tells something.
**Learner Action:** Tap or point to the subject, predicate, and punctuation.

## Talk Me Through It mode

**Prompts:**
- Who or what is this about?
- What does that subject do, have, or feel?
- Does the thought feel finished?
- Is there one complete thought or more than one?
- Which punctuation matches the sentence's job?
**Tutor Constraint:** Do not rewrite the learner's idea; prompt the learner to supply the missing part or connector.

## Let's Do One Together mode

**Example:** Because the bus was late.
**Steps:**
- Tutor notices that because makes the reader expect more.
- Learner says what happened because the bus was late.
- Together build: 'Because the bus was late, we entered quietly.'
- Learner chooses the end punctuation.
**Shared Responsibility:** The learner supplies the completing idea and makes the final edit.

## Different Example mode

**Example:** The bell rang everyone packed up.
**Why Different:** This example has two complete thoughts instead of a missing part.
**Steps:**
- Box 'The bell rang.'
- Box 'Everyone packed up.'
- Choose a period or a comma plus and.
- Learner writes the final version.

## Guided practice


### sen-g1

**Prompt:** Is 'The striped umbrella by the door.' complete? Repair it if needed.

**Answer:** Fragment; add a predicate, such as 'The striped umbrella by the door belongs to Ana.'

**Reasoning:** The group has a subject but no finite predicate.

### sen-g2

**Prompt:** Underline the subject and circle the predicate: 'After practice, our team filled the water bottles.'

**Answer:** Subject: our team. Predicate: filled the water bottles.

**Reasoning:** After practice is an introductory phrase, not the subject.

### sen-g3

**Prompt:** Repair: 'I finished my model it still needed paint.'

**Answer:** I finished my model, but it still needed paint. OR I finished my model. It still needed paint.

**Reasoning:** Two complete thoughts need separation or a connector.

### sen-g4

**Prompt:** Choose punctuation: 'What a huge kite__'

**Answer:** !

**Reasoning:** The sentence expresses strong feeling.

### sen-g5

**Prompt:** Revise for a formal class report while preserving meaning: 'We was checking the plants every day.'

**Answer:** We were checking the plants every day.

**Reasoning:** Only the requested school-writing convention changes; the learner's idea stays intact.

## Independent mastery check

**Policy:** This check shows readiness, not final mastery. Confirm the skill across at least two different sets or writing samples. Do not infer ability from dialect, spelling, handwriting, or one correct item.

### sen-mc1

**Prompt:** Label subject and predicate: 'The old bridge shook in the wind.'

**Answer-key criteria:** Subject: The old bridge. Predicate: shook in the wind.

### sen-mc2

**Prompt:** Repair: 'While the soup simmered.'

**Answer-key criteria:** Add a complete thought, such as 'While the soup simmered, I washed the cutting board.'

### sen-mc3

**Prompt:** Repair: 'The lights flickered we found a flashlight.'

**Answer-key criteria:** The lights flickered, so we found a flashlight. OR two sentences.

### sen-mc4

**Prompt:** Choose punctuation: 'Where did the trail begin__'

**Answer-key criteria:** ?

### sen-mc5

**Prompt:** Explain why 'Running beside the fence.' is usually a fragment.

**Answer-key criteria:** It does not name who or what is running and does not complete the thought.

### sen-mc6

**Prompt:** Revise one sentence from a provided ungraded draft for formal school writing, then explain the convention you changed.

**Answer-key criteria:** Answers vary; the learner must preserve the original meaning and identify the convention changed.

### Readiness rules
- At least 5 of 6 items are accurate on two occasions or in two different contexts.
- The learner correctly distinguishes a fragment from a run-on.
- The learner makes the final edit rather than copying a completed graded response.
- Dialect and vocabulary choice are evaluated separately from sentence completeness.

## Reteaching branch

**Enter when:**
- Nouns and verbs are recognized, but complete thoughts are not
- Punctuation is accurate while fragments persist

**Path:**
- Build two-word subject-predicate sentences with tiles.
- Expand each tile with modifiers.
- Compare a complete sentence with one missing tile.
- Join two complete sentence boxes correctly.

**Alternate explanation:** A sentence is a small stage: someone or something must be on the stage, and something must happen or be true.

## Prerequisite-remediation branch

**Enter when:**
- The learner cannot locate a basic noun or verb
- The learner cannot distinguish a question from a statement

**Path:**
- Sort people/places/things and action/state words.
- Build oral two-word sentences.
- Match sentence jobs to punctuation cards.
- Return to subject-predicate tiles.

**Exit evidence:** Identifies the noun/pronoun and verb in 8 of 10 simple sentences.

## Parent/teacher review note

Note the specific need: missing subject, missing predicate, dependent fragment, run-on, or punctuation. Keep dialect and home language separate from the instructional target. Teach formal conventions as an additional register, not as proof that one way of speaking is better.

## No-media fallback

Write subjects on one set of paper slips, predicates on another, and punctuation on small cards. The learner physically builds, breaks, and repairs sentences. No camera, microphone, or identifiable photo is needed.

## Answer key with reasoning

| Item | Source | Answer / criteria | Reasoning |
|---|---|---|---|
| `sen-d1` | diagnostic | The rain stopped. | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `sen-d2` | diagnostic | ["any clear noun or pronoun subject"] | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `sen-d3` | diagnostic | ["any predicate with a finite verb that completes the thought"] | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `sen-d4` | diagnostic | ["Mina opened the window, and the room cooled down.", "Mina opened the window. The room cooled down."] | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `sen-d5` | diagnostic | ? | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `sen-d6` | diagnostic | We was ready. → We were ready. | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `sen-g1` | guided-practice | Fragment; add a predicate, such as 'The striped umbrella by the door belongs to Ana.' | The group has a subject but no finite predicate. |
| `sen-g2` | guided-practice | Subject: our team. Predicate: filled the water bottles. | After practice is an introductory phrase, not the subject. |
| `sen-g3` | guided-practice | I finished my model, but it still needed paint. OR I finished my model. It still needed paint. | Two complete thoughts need separation or a connector. |
| `sen-g4` | guided-practice | ! | The sentence expresses strong feeling. |
| `sen-g5` | guided-practice | We were checking the plants every day. | Only the requested school-writing convention changes; the learner's idea stays intact. |
| `sen-mc1` | mastery | Subject: The old bridge. Predicate: shook in the wind. | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `sen-mc2` | mastery | Add a complete thought, such as 'While the soup simmered, I washed the cutting board.' | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `sen-mc3` | mastery | The lights flickered, so we found a flashlight. OR two sentences. | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `sen-mc4` | mastery | ? | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `sen-mc5` | mastery | It does not name who or what is running and does not complete the thought. | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `sen-mc6` | mastery | Answers vary; the learner must preserve the original meaning and identify the convention changed. | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |

## Source and rights note

All sentences and practice items in this sequence are original to Manuel Academy English v1. No third-party passage text is included.
