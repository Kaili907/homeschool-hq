# Organize and Revise a Clear Paragraph

**Sequence ID:** `ela-04-06-seq-04-paragraph-revision`  
**Lesson ID:** `ela-04-06-l04-organize-revise-paragraph`  
**Skill ID:** `ela.writing.paragraph.organize-revise`  
**Grade band:** Grades 4–6  
**Summary:** Learners arrange ideas around one focus, strengthen connections and clarity, compare before-and-after revisions, and make the final revision in their own voice.

## Prerequisites

- `ela.language.sentence.complete` — **Write or dictate complete sentences**: Can produce a subject-predicate sentence and choose an end mark.
- `ela.writing.topic-detail` — **Tell a focused idea and related details**: Can name what a paragraph is mostly about and give two related facts or events.

## Objectives
- State or identify a clear paragraph focus.
- Order sentences by time, importance, cause, or another clear relationship.
- Remove or relocate details that do not support the focus.
- Revise vague, repetitive, or choppy language while preserving the writer's voice.
- Make and explain the final revision independently.

## Instructional and learner-safety rules
- Teach the skill instead of rewriting all student work.
- Preserve the learner's voice.
- Ask the learner to make the final revision.
- Use respectful, non-shaming language about spelling, grammar, reading speed, dialect, and vocabulary.
- Never treat dialect as evidence of low ability.
- Do not diagnose dyslexia or any other condition.
- Do not complete graded writing.
- Do not claim mastery from one successful item.
- Switch to another explanation when the first explanation does not help.
- Never require a camera or identifiable child photograph.
- Use only original or public-domain passages.

## Diagnostic assessment

**Purpose:** Distinguish organization, focus, elaboration, sentence-connection, and editing needs without completing the learner's writing.

**Directions:** Use the original ungraded practice draft. The tutor may point, ask, and model on a separate example, but the learner makes every final change.


### Diagnostic draft — Cardboard Arcade

1. On Saturday, I built a cardboard arcade game.
2. The marble kept rolling past the scoring cups.
3. My favorite cereal is cinnamon squares.
4. First, I cut three holes and taped paper cups underneath.
5. I raised one side of the ramp, and the marble finally dropped into a cup.
6. I felt proud when the score counter worked.

### par-d1

State the paragraph's likely focus in one sentence.

*Evidence tags: focus.*

### par-d2

Which sentence does not support the focus?

- The marble kept rolling past the scoring cups.
- My favorite cereal is cinnamon squares.
- First, I cut three holes and taped paper cups underneath.
- I felt proud when the score counter worked.

*Evidence tags: relevance.*

### par-d3

Move the sentence beginning 'First' to a clearer position. Where should it go?

*Evidence tags: sequence.*

### par-d4

Which two sentences show a problem and solution?

*Evidence tags: connection.*

### par-d5

Choose one sentence to revise for clarity. Explain the change, but do not rewrite the whole paragraph.

*Evidence tags: revision-control, voice.*

## Likely misconception patterns and distinguishing evidence

### par-m1 — Revision means fixing spelling only

**Pattern:** The learner edits surface errors but does not consider focus, order, clarity, or support.

**Evidence that distinguishes it:**
- Corrects capitals and spelling
- Leaves an unrelated sentence and confusing order

**Response:** Separate revision from editing. Revise ideas and organization first; edit conventions later.

### par-m2 — Every sentence must stay

**Pattern:** The learner believes deleting or moving a sentence means the sentence was bad.

**Evidence that distinguishes it:**
- Identifies an unrelated detail but refuses to remove it
- Accepts moving the detail to a different paragraph

**Response:** Use a parking-lot box for good details that do not belong in this paragraph.

### par-m3 — Order means chronological only

**Pattern:** The learner tries to use first-next-finally even when cause, importance, or comparison would be clearer.

**Evidence that distinguishes it:**
- Adds time words to an explanation paragraph
- Can sort once the organizing relationship is named

**Response:** Offer four organizing paths: time, cause/effect, most important, or compare/contrast.

### par-m4 — Better writing means harder words

**Pattern:** The learner replaces natural language with unfamiliar vocabulary that changes voice or meaning.

**Evidence that distinguishes it:**
- Uses a thesaurus word incorrectly
- Original sentence was clear and specific

**Response:** Prefer precise familiar words. Ask whether the revision sounds like the writer and says exactly what they mean.

### par-m5 — Tutor should finish the paragraph

**Pattern:** The learner waits for a complete replacement draft or copies one without making decisions.

**Evidence that distinguishes it:**
- Can choose between two options but does not generate the final wording
- Improves when given a sentence frame or one modeled example

**Response:** Model on a different example, then return the decision and final wording to the learner.

## Visual explanation plan

**Models:** Paragraph sequencing, Before-and-after revision views, Supporting-detail organizers

**Command file:** `visuals/ela-04-06-seq-04.visual-board.json`

**Accessible description:** Six sentence cards from the Cardboard Arcade draft are arranged. One unrelated sentence moves to a parking-lot area. The remaining cards are reordered into opening, build step, problem, solution, and reflection. A before-and-after view highlights only the moved and clarified parts, not a replacement paragraph.

## Spoken explanation

Revision means making ideas clearer for a reader. Start by naming the paragraph's focus. Check whether every sentence supports that focus. Put the sentences in an order the reader can follow, such as time, cause and effect, or importance. Then improve one unclear, repeated, or choppy place. Keep words that sound like the writer unless they hide the meaning. A tutor can model a skill and ask questions, but the writer makes the final revision. Editing spelling and punctuation comes after the ideas are working.


- Script: `narration/ela-04-06-seq-04.en.txt`
- Captions: `captions/ela-04-06-seq-04.en.vtt`
- Transcript: `transcripts/ela-04-06-seq-04.en.md`

## Show Me mode

**Example:** A separate three-sentence draft about planting basil
**Steps:**
- Name the focus: how I planted basil.
- Move the planting step before the result.
- Place an unrelated sentence in the parking lot.
- Clarify one vague word, then stop so the writer can revise their own draft.
**Learner Action:** Explain why each card moves before touching the practice draft.

## Talk Me Through It mode

**Prompts:**
- What do you want the reader to understand?
- Which sentence helps that focus most?
- Does any good detail belong somewhere else?
- What order will help the reader follow?
- Which one place is unclear or repetitive?
- How will you revise it in words that sound like you?
**Tutor Constraint:** Never supply a complete replacement paragraph for graded work. Ask the learner to make and enter the final revision.

## Let's Do One Together mode

**Example Draft:**
- Our class tested paper bridges.
- The bridge bent when we added the fourth book.
- We folded the next strip into a triangle shape.
- The triangle bridge held seven books.
**Steps:**
- Tutor and learner name the focus.
- Learner orders test, problem, change, result.
- Tutor models adding one connector on a different sentence.
- Learner chooses and writes the final connector in this draft.
**Shared Responsibility:** The tutor models the process; the learner makes the actual revision.

## Different Example mode

**Example Draft:**
- The community pool should add a shaded bench.
- Families wait beside the pool during lessons.
- Shade would make the waiting area safer and more comfortable.
- The vending machine is blue.
**Why Different:** This paragraph is organized as claim and reasons, not as time order.
**Steps:**
- Identify the claim.
- Place reasons after the claim.
- Move the unrelated vending-machine detail to the parking lot.
- Ask the learner for a closing sentence; do not write it for them.

## Guided practice


### par-g1

**Prompt:** Order these sentence cards: 'The seedlings stood upright.' 'We moved them closer to the window.' 'At first, the stems leaned toward the light.'

**Answer:** At first...; We moved...; The seedlings stood...

**Reasoning:** The order shows problem, action, and result.

### par-g2

**Prompt:** Which detail belongs in the parking lot for a paragraph about training a puppy to wait at the door: 'We practiced with a hand signal,' 'The leash is red,' or 'We rewarded calm waiting'?

**Answer:** The leash is red.

**Reasoning:** It does not explain the training process unless color matters to the focus.

### par-g3

**Prompt:** Revise one vague word: 'The model did a thing when the fan turned on.'

**Answer:** Answers vary, such as 'The model spun when the fan turned on.'

**Reasoning:** A precise action verb improves clarity without making the voice unnatural.

### par-g4

**Prompt:** Combine without erasing voice: 'I tested the ramp. I tested it again. I changed the height.'

**Answer:** Answers vary, such as 'I tested the ramp again after I changed the height.'

**Reasoning:** The revision reduces repetition and shows the relationship.

### par-g5

**Prompt:** Name the organizing pattern for a paragraph that explains why a rule changed and what happened afterward.

**Answer:** Cause and effect.

**Reasoning:** The relationship is reasons and results, not merely time order.

## Independent mastery check

**Policy:** This check shows readiness, not final mastery. The learner must revise at least two original, ungraded practice paragraphs on different occasions. A tutor may provide criteria and questions but may not complete graded writing.


### Practice draft — par-mp1

1. Our group designed a carrier for a raw egg.
2. We wanted the egg to survive a one-meter drop.
3. The first carrier used only crumpled paper.
4. My shoes have white laces.
5. The egg cracked because it struck the bottom of the box.
6. We added a cardboard sling that held the egg in the center.
7. On the second drop, the egg stayed whole.

*Rights: original.*

### par-mc1

**Prompt:** Write the paragraph focus in one sentence.

**Answer-key criteria:** Designing and improving an egg carrier so the egg survives a drop.

### par-mc2

**Prompt:** Identify the unrelated sentence and move it to the parking lot.

**Answer-key criteria:** My shoes have white laces.

### par-mc3

**Prompt:** Arrange the remaining cards in a clear order.

**Answer-key criteria:** Goal; first design; failure and cause; revision; successful result. The opening design sentence may come before the goal sentence if the flow stays clear.

### par-mc4

**Prompt:** Choose one sentence connection to strengthen and explain why.

**Answer-key criteria:** Answers vary; the explanation must name the relationship, such as cause/effect or sequence.

### par-mc5

**Prompt:** Revise one vague, repetitive, or choppy place in your own words.

**Answer-key criteria:** Answers vary; revision must preserve meaning and improve clarity.

### par-mc6

**Prompt:** Make the final paragraph revision yourself, then use the checklist to explain two decisions.

**Answer-key criteria:** No single model paragraph is provided. Accept a focused, logically ordered paragraph with related details and two explained revision decisions.

### Readiness rules
- The learner independently identifies focus and removes or relocates unrelated material.
- The learner organizes two different practice paragraphs using an appropriate pattern.
- The learner improves at least one unclear connection or sentence while preserving voice.
- Readiness is confirmed across at least two occasions; one polished paragraph is not enough.
- The learner, not the tutor, makes the final revision.

## Reteaching branch

**Enter when:**
- Complete sentences are present, but focus or order is unclear
- The learner can choose revisions but cannot explain them

**Path:**
- Use only three sentence cards.
- Name one focus sentence.
- Sort related versus parking-lot details.
- Choose one organizing arrow: time, cause, importance, or comparison.
- Add one connection and return authorship to the learner.

**Alternate explanation:** A paragraph is a trail. Every sentence should help the reader reach the same destination, and signs should show where to go next.

## Prerequisite-remediation branch

**Enter when:**
- Sentences are incomplete enough to block organization
- The learner cannot state a focused idea orally

**Path:**
- Dictate one clear idea.
- Build complete sentences from oral ideas.
- Sort two related and one unrelated detail.
- Sequence three picture-free sentence cards.
- Return to a short paragraph.

**Exit evidence:** Produces or dictates three complete sentences about one focus and identifies one unrelated sentence.

## Parent/teacher review note

Review decisions rather than replacing the paragraph. Ask the learner to explain focus, order, one removed or moved detail, and one clarity change. Preserve dialect and voice. For graded writing, the tutor should stop at prompts, criteria, and a separate modeled example.

## No-media fallback

Copy each sentence onto a separate paper strip. Use a labeled parking-lot envelope for unrelated details. Arrange strips on a table, then the learner writes the final version. No camera, photograph, or online service is required.

## Answer key with reasoning

| Item | Source | Answer / criteria | Reasoning |
|---|---|---|---|
| `par-d1` | diagnostic | ["building and improving a cardboard arcade game"] | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `par-d2` | diagnostic | My favorite cereal is cinnamon squares. | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `par-d3` | diagnostic | ["immediately after the opening sentence"] | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `par-d4` | diagnostic | ["The marble kept rolling past the scoring cups; I raised one side of the ramp..."] | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `par-d5` | diagnostic | ["answers vary; revision must preserve meaning and improve clarity"] | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `par-g1` | guided-practice | At first...; We moved...; The seedlings stood... | The order shows problem, action, and result. |
| `par-g2` | guided-practice | The leash is red. | It does not explain the training process unless color matters to the focus. |
| `par-g3` | guided-practice | Answers vary, such as 'The model spun when the fan turned on.' | A precise action verb improves clarity without making the voice unnatural. |
| `par-g4` | guided-practice | Answers vary, such as 'I tested the ramp again after I changed the height.' | The revision reduces repetition and shows the relationship. |
| `par-g5` | guided-practice | Cause and effect. | The relationship is reasons and results, not merely time order. |
| `par-mc1` | mastery | Designing and improving an egg carrier so the egg survives a drop. | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `par-mc2` | mastery | My shoes have white laces. | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `par-mc3` | mastery | Goal; first design; failure and cause; revision; successful result. The opening design sentence may come before the goal sentence if the flow stays clear. | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `par-mc4` | mastery | Answers vary; the explanation must name the relationship, such as cause/effect or sequence. | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `par-mc5` | mastery | Answers vary; revision must preserve meaning and improve clarity. | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `par-mc6` | mastery | No single model paragraph is provided. Accept a focused, logically ordered paragraph with related details and two explained revision decisions. | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |

## Source and rights note

Every draft and practice paragraph in this sequence is original to Manuel Academy English v1. No copyrighted third-party passage text is included.
