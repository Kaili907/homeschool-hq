# Find the Main Idea and Supporting Details

**Sequence ID:** `ela-04-06-seq-03-main-idea-details`  
**Lesson ID:** `ela-04-06-l03-main-idea-supporting-details`  
**Skill ID:** `ela.reading.main-idea.details`  
**Grade band:** Grades 4–6  
**Summary:** Learners separate topic from main idea, select details that truly support it, and explain the connection in their own words.

## Prerequisites

- `ela.reading.literal-details` — **Recall stated details**: Can answer who, what, where, and when questions about a short passage.
- `ela.reading.paraphrase` — **Restate a sentence in new words**: Can explain one sentence without copying it word for word.

## Objectives
- Name the topic and state what the author says about it.
- Choose details that directly support the main idea.
- Reject details that are interesting but not central.
- Explain how a supporting detail connects to the main idea.

## Instructional and learner-safety rules
- Teach the skill instead of rewriting all student work.
- Preserve the learner's voice.
- Ask the learner to make the final revision.
- Use respectful, non-shaming language about spelling, grammar, reading speed, dialect, and vocabulary.
- Never treat dialect as evidence of low ability.
- Do not diagnose dyslexia or any other condition.
- Do not complete graded writing.
- Do not claim mastery from one successful item.
- Switch to another explanation when the first explanation does not help.
- Never require a camera or identifiable child photograph.
- Use only original or public-domain passages.

## Diagnostic assessment

**Purpose:** Distinguish topic-only answers, overly broad ideas, overly narrow details, and unsupported background-knowledge answers.

**Directions:** The learner may reread the original passage as often as needed. Reading speed is not scored.


### Diagnostic passage — The Night Garden

Some flowers save their strongest scent for nighttime. Moths and other night insects follow the scent to find nectar. As the insects move from flower to flower, they carry pollen. This helps the plants make seeds even when most daytime pollinators are resting.

*Rights: original.*

### mid-d1

What is the topic?

*Evidence tags: topic.*

### mid-d2

Which is the best main idea?

- Moths can fly at night.
- Night-blooming flowers use scent to attract pollinators that help them make seeds.
- Flowers have many colors.
- Pollen is yellow dust.

*Evidence tags: main-idea.*

### mid-d3

Which detail best supports the main idea?

- Some gardens have fences.
- Night insects follow the flowers' scent to find nectar.
- Moths have wings.
- Seeds can be different sizes.

*Evidence tags: supporting-detail.*

### mid-d4

Explain how carrying pollen supports the main idea.

*Evidence tags: connection.*

### mid-d5

Which answer uses outside knowledge instead of the passage?

- The flowers release scent at night.
- The insects carry pollen.
- All moths live only one week.
- Pollination helps make seeds.

*Evidence tags: text-evidence.*

## Likely misconception patterns and distinguishing evidence

### mid-m1 — Topic equals main idea

**Pattern:** The learner answers with one or two topic words instead of a complete statement.

**Evidence that distinguishes it:**
- Says 'moths' or 'flowers' for the main idea
- Can state what the passage says after a sentence frame is offered

**Response:** Use the frame: 'The passage is mostly about ___, and it says ___.'

### mid-m2 — Interesting detail wins

**Pattern:** The learner chooses the most surprising detail rather than the idea supported by most of the passage.

**Evidence that distinguishes it:**
- Can recall a vivid fact
- Cannot connect at least two other details to the selected idea

**Response:** Place each detail under a candidate main idea and count meaningful connections.

### mid-m3 — Too broad

**Pattern:** The answer could fit many unrelated passages.

**Evidence that distinguishes it:**
- Answers 'Nature is important'
- Improves when required to include two key passage words

**Response:** Ask which exact kind of nature and what the author explains about it.

### mid-m4 — Too narrow

**Pattern:** The learner selects one supporting detail as the main idea.

**Evidence that distinguishes it:**
- Answer matches only one sentence
- Cannot place the other details beneath it

**Response:** Zoom out: combine what two or three details have in common.

### mid-m5 — Background knowledge replaces evidence

**Pattern:** The learner supplies a true fact that the passage does not support.

**Evidence that distinguishes it:**
- Fact may be accurate
- Learner cannot point to a sentence or paraphrase supporting it

**Response:** Use two columns: 'In the text' and 'I already knew.' Both are valuable, but only the first answers this question.

## Visual explanation plan

**Models:** Main-idea maps, Supporting-detail organizers

**Command file:** `visuals/ela-04-06-seq-03.visual-board.json`

**Accessible description:** A central main-idea box reads 'Night flowers attract pollinators that help make seeds.' Three arrows connect to details about scent, nectar, and pollen. An interesting but unsupported fact sits outside the map with a label that says 'not evidence from this passage.'

## Spoken explanation

The topic names what a passage is about. The main idea tells what the author wants you to understand about that topic. A strong main idea is not so broad that it fits almost anything, and it is not so narrow that it matches only one sentence. Supporting details explain, prove, or give examples of the main idea. You can test an idea by asking, 'Do several details connect to it?' Use the passage, not just what you already know.


- Script: `narration/ela-04-06-seq-03.en.txt`
- Captions: `captions/ela-04-06-seq-03.en.vtt`
- Transcript: `transcripts/ela-04-06-seq-03.en.md`

## Show Me mode

**Example:** The Night Garden passage
**Steps:**
- Name the topic: night flowers and pollinators.
- Combine repeated information: scent attracts insects; insects carry pollen; plants make seeds.
- Write a main-idea sentence that includes the topic and the author's point.
- Connect each supporting detail with an arrow.
**Learner Action:** Point to the sentence that supports each arrow.

## Talk Me Through It mode

**Prompts:**
- What topic appears again and again?
- What does the author want us to understand about that topic?
- Which two details connect to your idea?
- Is your idea too broad or just one detail?
- Can you point to evidence in the passage?
**Tutor Constraint:** Ask for evidence before confirming an answer. Do not require speed.

## Let's Do One Together mode

**Example Passage:** A town placed small libraries in old newspaper boxes. Neighbors donated books. Readers could take one book and leave another. The boxes made sharing books easy in places far from the main library.
**Steps:**
- Tutor identifies the topic: neighborhood book boxes.
- Learner states what happened: they made sharing easier.
- Together form the main idea.
- Learner chooses two supporting details and explains each connection.
**Shared Responsibility:** The learner states the final main idea in their own words.

## Different Example mode

**Example Passage:** Octopuses can squeeze through tiny openings because they have no rigid skeleton. Their soft bodies can change shape, but their beaks are hard. If the beak fits through an opening, the rest of the octopus usually can too.
**Why Different:** This science passage explains one cause-and-effect idea rather than a process with several actors.
**Steps:**
- Topic: octopus movement.
- Main idea: a soft body allows an octopus to fit through small spaces, limited by its beak.
- Details: no rigid skeleton; body changes shape; beak must fit.

## Guided practice


### mid-g1 passage

During winter, some city workers spread beet juice mixed with salt on icy roads. The mixture helps salt stick to the pavement and work at lower temperatures. Using it can reduce the total amount of salt needed.

*Rights: original.*

### mid-g1

**Prompt:** State the main idea.

**Answer:** A beet-juice mixture helps road salt work better in winter and can reduce how much salt is used.

**Reasoning:** The answer combines all three sentences rather than repeating one detail.

### mid-g2 passage

A school added quiet corners to several classrooms. Each corner had soft lighting, a timer, and simple breathing cards. Students could use the space briefly and then return to learning. Teachers reported fewer interruptions during difficult transitions.

*Rights: original.*

### mid-g2

**Prompt:** Choose two supporting details for the idea that quiet corners helped students reset and return to learning.

**Answer:** Students used the space briefly before returning; teachers reported fewer interruptions.

**Reasoning:** Both details show the effect of the quiet corners.

### mid-g3 passage

Honeybees share information through movement. A worker bee returning to the hive performs a waggle dance. The angle and length of the dance help other bees locate food.

*Rights: original.*

### mid-g3

**Prompt:** Which is topic only: 'honeybees' or 'Honeybees use a dance to show other bees where food is'?

**Answer:** Honeybees is topic only; the full sentence is the main idea.

**Reasoning:** The main idea states what the author explains about the topic.

### mid-g4 passage

The library's seed exchange began with twelve envelopes. Gardeners added extra seeds from vegetables and flowers. By spring, the cabinet held more than two hundred labeled packets for neighbors to share.

*Rights: original.*

### mid-g4

**Prompt:** Explain why 'The cabinet held more than two hundred packets' is a supporting detail, not the full main idea.

**Answer:** It is one result showing that the seed exchange grew through community sharing.

**Reasoning:** The main idea must include the exchange and its growth, not only the final number.

## Independent mastery check

**Policy:** This check shows readiness, not final mastery. Use at least two passages of different structures on different occasions before confirming mastery.


### mid-mp1

A rooftop garden can cool the building below it. Soil and plants absorb less heat than a dark roof. Water evaporating from leaves also carries heat away. Together, these effects can lower roof temperatures on hot days.

*Rights: original.*


### mid-mp2

The first rehearsal was noisy because everyone tuned at once. The conductor created a new routine: strings tuned first, then woodwinds, brass, and percussion. At the next rehearsal, tuning took less time and musicians could hear their own instruments.

*Rights: original.*

### mid-mc1

**Prompt:** State the topic of mid-mp1.

**Answer-key criteria:** rooftop gardens and building heat

### mid-mc2

**Prompt:** State the main idea of mid-mp1.

**Answer-key criteria:** Rooftop gardens can cool buildings because soil, plants, and evaporation reduce roof heat.

### mid-mc3

**Prompt:** Give two supporting details from mid-mp1 and explain one connection.

**Answer-key criteria:** Examples: soil and plants absorb less heat; evaporation carries heat away. The details explain how cooling happens.

### mid-mc4

**Prompt:** State the main idea of mid-mp2.

**Answer-key criteria:** A planned tuning order made orchestra rehearsal faster and easier to hear.

### mid-mc5

**Prompt:** Which detail shows the result of the new routine?

**Answer-key criteria:** Tuning took less time and musicians could hear their own instruments.

### mid-mc6

**Prompt:** Write one answer that is too broad for mid-mp2, then improve it.

**Answer-key criteria:** Too broad example: 'Routines help.' Improved: 'A planned tuning order made rehearsal more efficient.'

### Readiness rules
- At least 5 of 6 items are accurate across two different passage sets.
- The learner states a main idea as a complete thought, not topic words only.
- The learner connects at least two details to the main idea.
- The learner distinguishes text evidence from background knowledge.

## Reteaching branch

**Enter when:**
- Literal details are accurate but main ideas are too broad or narrow
- Topic words are given instead of a statement

**Path:**
- Sort topic cards and main-idea sentences.
- Map two details under one idea.
- Compare one too-broad and one too-narrow answer.
- Create a main idea using the frame topic + author's point.

**Alternate explanation:** The main idea is an umbrella. The supporting details should fit underneath it without the umbrella being enormous.

## Prerequisite-remediation branch

**Enter when:**
- The learner cannot recall stated details
- The learner's answers are unrelated to the passage

**Path:**
- Read one sentence at a time.
- Answer who/what questions.
- Paraphrase each sentence.
- Combine two related paraphrases.

**Exit evidence:** Accurately recalls or locates 4 of 5 stated details in an untimed short passage.

## Parent/teacher review note

Record whether difficulty is with recalling details, distinguishing topic from main idea, choosing relevant evidence, or explaining the connection. Do not use reading speed, accent, or vocabulary unfamiliarity as a proxy for comprehension.

## No-media fallback

Draw one large center box for the main idea and three smaller boxes for details. Use arrows or string to show connections. Read passages aloud when decoding would hide comprehension, but record that accommodation. No camera or photograph is required.

## Answer key with reasoning

| Item | Source | Answer / criteria | Reasoning |
|---|---|---|---|
| `mid-d1` | diagnostic | ["night-blooming flowers", "night pollination", "flowers and night insects"] | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `mid-d2` | diagnostic | Night-blooming flowers use scent to attract pollinators that help them make seeds. | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `mid-d3` | diagnostic | Night insects follow the flowers' scent to find nectar. | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `mid-d4` | diagnostic | ["It explains how the insects help the flowers make seeds after being attracted by scent."] | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `mid-d5` | diagnostic | All moths live only one week. | Use the evidence tags to identify the instructional need; accept equivalent wording when the target skill is demonstrated. |
| `mid-g1` | guided-practice | A beet-juice mixture helps road salt work better in winter and can reduce how much salt is used. | The answer combines all three sentences rather than repeating one detail. |
| `mid-g2` | guided-practice | Students used the space briefly before returning; teachers reported fewer interruptions. | Both details show the effect of the quiet corners. |
| `mid-g3` | guided-practice | Honeybees is topic only; the full sentence is the main idea. | The main idea states what the author explains about the topic. |
| `mid-g4` | guided-practice | It is one result showing that the seed exchange grew through community sharing. | The main idea must include the exchange and its growth, not only the final number. |
| `mid-mc1` | mastery | rooftop gardens and building heat | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `mid-mc2` | mastery | Rooftop gardens can cool buildings because soil, plants, and evaporation reduce roof heat. | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `mid-mc3` | mastery | Examples: soil and plants absorb less heat; evaporation carries heat away. The details explain how cooling happens. | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `mid-mc4` | mastery | A planned tuning order made orchestra rehearsal faster and easier to hear. | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `mid-mc5` | mastery | Tuning took less time and musicians could hear their own instruments. | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |
| `mid-mc6` | mastery | Too broad example: 'Routines help.' Improved: 'A planned tuning order made rehearsal more efficient.' | Score the target skill and reasoning, not reading speed, dialect, handwriting, or exact wording. |

## Source and rights note

Every passage in this sequence is original to Manuel Academy English v1. No copyrighted third-party passage text is included.
