# Director integration handoff — TUTOR-ENGLISH

## Package

- Package ID: `manuel-academy-adaptive-english-v1`
- Owned root: `adaptive-tutor/subjects/english/**`
- Structured entry point: `data/package.manifest.json`
- Typed entry point: `metadata/manifest.ts`
- Sequence registry: `metadata/sequences.ts`
- Standalone preview: `demo/index.html`

## Completed sequence order

1. `ela-04-06-seq-01-multisyllable-decoding`
2. `ela-04-06-seq-02-sentence-completeness`
3. `ela-04-06-seq-03-main-idea-details`
4. `ela-04-06-seq-04-paragraph-revision`

## Integration steps

1. Wait for the shared adaptive-tutor core contract to be finalized.
2. Load the JSON package manifest and preserve the four-sequence order.
3. Replace or formally adopt `adapters/provisional-core-adapter.ts`; do not copy its compatibility compromises into shared core.
4. Resolve the seven requests in `core-change-requests.md`, especially native grade 5, learner-neutral answer fields, explicit explanation modes, multi-occasion mastery, accessible visual commands, and the graded-writing boundary.
5. Render unknown visual-board commands as readable steps until the shared renderer supports them.
6. Treat mastery results as `ready-for-review` until evidence from at least two occasions is available.
7. Keep all practice passage rights metadata with the imported content.
8. Run `npm run check` from the English package root before and after integration.

## Validation

- TypeScript: PASS
- Node tests: 12/12 PASS
- Content validation: 21/21 PASS
- Diagnostic items: 22
- Guided-practice items: 19
- Independent-mastery items: 24
- Misconception patterns: 20
- Answer-key entries: 65

## Integration boundaries

No GitHub, shared core, Ready for Life, math, Supabase, Netlify, Lovable, database, authentication, identity, storage, or progress-synchronization changes are included.
