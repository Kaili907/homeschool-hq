import type { EnglishSequenceMetadata } from '../metadata/types'

/** Current live Academy tutor compatibility shape, kept outside shared core. */
export interface LegacyTutorContext {
  grade: '4' | '6'
  problem: string
  correctAnswer: string
  herAnswer: string
}

export interface NeutralTutorContext {
  learnerGrade: 4 | 5 | 6
  problem: string
  expectedEvidence: string
  studentAnswer: string
  graded: false
  sequenceId: string
  skillId: string
  mode: 'show-me' | 'talk-me-through-it' | 'together' | 'different-example' | 'guided-practice'
}

export interface LegacyCompatibilityResult {
  context: LegacyTutorContext
  compatibilityNotes: string[]
}

/**
 * Provisional only. Grade 5 maps to the existing grade-4 vocabulary setting
 * while actual grade and skill remain in the problem context. This is not a
 * mastery mapping and must be removed when the shared core supports grade 5.
 */
export function toLegacyTutorContext(input: NeutralTutorContext): LegacyCompatibilityResult {
  const compatibilityNotes: string[] = []
  const grade: '4' | '6' = input.learnerGrade === 6 ? '6' : '4'
  if (input.learnerGrade === 5) {
    compatibilityNotes.push('CR-001: grade 5 temporarily uses the grade-4 vocabulary setting; actual grade remains explicit in the problem text.')
  }
  compatibilityNotes.push('CR-002: neutral studentAnswer is copied to legacy herAnswer only at the boundary.')
  return {
    context: {
      grade,
      problem: `[English ${input.sequenceId}; actual grade ${input.learnerGrade}; mode ${input.mode}] ${input.problem}`,
      correctAnswer: input.expectedEvidence,
      herAnswer: input.studentAnswer,
    },
    compatibilityNotes,
  }
}

export function getNoMediaFallback(sequence: EnglishSequenceMetadata): string {
  return sequence.noMediaFallback
}

export function shouldOfferDifferentExplanation(attemptedModes: string[]): boolean {
  return attemptedModes.length > 0 && !attemptedModes.includes('different-example')
}

export function canClaimMastery(successfulSessions: number, latestSetMetRules: boolean): boolean {
  return successfulSessions >= 2 && latestSetMetRules
}
