# Provisional core adapter

This adapter is intentionally contained within `adaptive-tutor/subjects/english/**`. It does not modify the shared tutor core.

It provides:

- a neutral English-content context;
- a temporary boundary conversion to the current legacy tutor context;
- explicit grade-5 compatibility notes;
- no-media fallback access;
- a minimum two-session mastery guard;
- a helper that offers a different explanation after an unsuccessful mode.

Remove or replace the adapter when the Director integrates a finalized shared adaptive-tutor contract.
