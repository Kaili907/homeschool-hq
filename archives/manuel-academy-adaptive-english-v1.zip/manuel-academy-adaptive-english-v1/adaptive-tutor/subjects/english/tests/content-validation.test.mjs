import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const manifest = JSON.parse(fs.readFileSync(path.join(root,'data/package.manifest.json'),'utf8'));
const sequences = manifest.sequenceOrder.map(id => JSON.parse(fs.readFileSync(path.join(root,`data/sequences/${id}.json`),'utf8')));

test('manifest contains four stable ordered sequences', () => {
  assert.equal(sequences.length, 4);
  assert.deepEqual(sequences.map(s => s.order), [1,2,3,4]);
  assert.equal(new Set(sequences.map(s => s.skillId)).size, 4);
});

test('each sequence includes complete adaptive modes and branches', () => {
  for (const s of sequences) {
    for (const key of ['showMe','talkMeThroughIt','letsDoOneTogether','differentExample']) assert.ok(s.modes[key], `${s.sequenceId} missing ${key}`);
    assert.ok(s.branches.reteaching);
    assert.ok(s.branches.prerequisiteRemediation);
    assert.ok(s.parentTeacherReviewNote.length > 40);
    assert.ok(s.noMediaFallback.length > 40);
  }
});

test('mastery is never based on one successful item', () => {
  for (const s of sequences) {
    const text = `${s.independentMasteryCheck.policy} ${s.independentMasteryCheck.readinessRules.join(' ')}`;
    assert.match(text, /two|multiple|more than one/i);
    assert.doesNotMatch(text, /one (successful|correct) (item|session).*(is enough|confirms mastery)/i);
  }
});

test('answer keys cover diagnostic, guided, and mastery items', () => {
  for (const s of sequences) {
    const required = [...s.diagnostic.items,...s.guidedPractice,...s.independentMasteryCheck.items].map(i => i.id);
    const keyIds = new Set(s.answerKey.map(k => k.itemId));
    for (const id of required) assert.ok(keyIds.has(id), `${s.sequenceId} missing key ${id}`);
  }
});

test('all passages and drafts declare original rights', () => {
  for (const s of sequences) assert.match(s.sourceRights.passages, /original/i);
});

test('paragraph sequence returns final revision to the learner', () => {
  const paragraph = sequences.find(s => s.skillId === 'ela.writing.paragraph.organize-revise');
  assert.ok(paragraph);
  const body = JSON.stringify(paragraph).toLowerCase();
  assert.match(body, /learner.*final revision|final revision.*learner/);
  assert.match(body, /do not complete graded writing|may not complete graded writing/);
});
