import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

test('caption files are valid basic WebVTT', () => {
  const files = fs.readdirSync(path.join(root,'captions')).filter(f => f.endsWith('.vtt'));
  assert.equal(files.length, 4);
  for (const file of files) {
    const text = fs.readFileSync(path.join(root,'captions',file),'utf8');
    assert.ok(text.startsWith('WEBVTT'));
    assert.match(text, /00:00:\d{2}\.\d{3} --> 00:00:\d{2}\.\d{3}/);
  }
});

test('standalone demo has no external network or camera dependency', () => {
  const html = fs.readFileSync(path.join(root,'demo/index.html'),'utf8');
  const js = fs.readFileSync(path.join(root,'demo/app.js'),'utf8');
  assert.doesNotMatch(html+js, /https?:\/\//);
  assert.doesNotMatch(html+js, /getUserMedia|mediaDevices|enumerateDevices/i);
});

test('core changes are requests, not shared-core edits', () => {
  assert.ok(fs.existsSync(path.join(root,'core-change-requests.md')));
  assert.ok(fs.existsSync(path.join(root,'adapters/provisional-core-adapter.ts')));
  assert.equal(fs.existsSync(path.resolve(root,'../../core')), false);
});
