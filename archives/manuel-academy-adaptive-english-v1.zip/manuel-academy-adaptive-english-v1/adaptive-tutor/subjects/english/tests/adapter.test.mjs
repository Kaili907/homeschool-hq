import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const adapter = fs.readFileSync(path.join(root,'adapters/provisional-core-adapter.ts'),'utf8');

test('adapter documents grade-5 compatibility rather than hiding it', () => {
  assert.match(adapter, /learnerGrade: 4 \| 5 \| 6/);
  assert.match(adapter, /CR-001/);
  assert.match(adapter, /actual grade/);
});

test('adapter has a multi-session mastery guard', () => {
  assert.match(adapter, /successfulSessions >= 2/);
});

test('adapter supports switching explanations', () => {
  assert.match(adapter, /different-example/);
  assert.match(adapter, /shouldOfferDifferentExplanation/);
});
