# Safety Report

## Verified Core gap

Tutor Core declares nine safety categories. Runtime rules exist for academic
integrity, identifying information, diagnosis requests, disputed grading, and
high-stakes placement. Persistent difficulty has a separate engine route.

The two declared urgent categories have no runtime rule:

- `self-harm-or-immediate-danger`
- `abuse-or-neglect-disclosure`

No Core rule can currently emit `urgent-escalation` or
`continueTutoringAllowed:false`, so Core's guard cannot stop academic flow for
those categories.

## Bridge gateway

`evaluatePreCoreUrgentSafety`:

- runs on transient text before `AdaptiveTutorEngine.submit`;
- bounds input to 4,000 characters;
- uses a deterministic reviewed English-language pattern corpus;
- ignores prompt-injection instructions because patterns are not model
  instructions;
- stops normal instruction on a match;
- returns fixed learner-safe language;
- proposes a `student-support` adult hook with exact urgent reason codes;
- marks delivery `proposed-not-delivered`;
- retains no raw or matched text;
- makes no diagnosis.

A safe result registers an opaque event/session/time-bound permit in a
module-private capability registry. `adaptFrozenTutorCoreResult` requires that
permit, so the authority-granting adapter cannot be used without the gateway.
Urgent and invalid results never receive a permit.

An invalid/oversized gateway input fails closed and requires adult review.

## Adult review

The canonical Study category is `student-support`. Exact urgent category and
rule IDs remain in the bridge-owned adult-only hook because the canonical
review request has no urgent reason field.

The bridge never auto-creates a `ParentTeacherPrivateNote`. Only an authorized
parent or teacher can author that record.

## Safeguards

- One-answer mastery claims are quarantined.
- Low accuracy produces no engagement concern.
- Unknown versions/events/fields quarantine.
- Learner messages use fixed, supportive, non-blaming text.
- Safety hooks contain no disclosure text, contact detail, credential,
  transcript, or private note.

## Limitation

The pattern gateway cannot guarantee complete disclosure detection and is not
an emergency service. Authorization, adult messaging, emergency routing,
delivery, and production monitoring remain outside this session.
