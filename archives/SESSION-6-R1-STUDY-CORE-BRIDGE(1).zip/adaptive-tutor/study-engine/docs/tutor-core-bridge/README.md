# Study Core Bridge v1.0.0

This bridge connects the canonical Study Engine v1 contracts to frozen
Adaptive Tutor Core v0.2.0 without changing either authority.

## Integration order

1. Verify all four external ZIPs and the Tutor Core manifest with
   `bridges/tutor-core/scripts/verify-sources.mjs`.
2. Load Session 1's `inspectContractVersion` and
   `learningEvidenceSchema` through `createStudySchemaRegistryPort`.
3. Register explicit Study ID to Tutor stable-ID mappings. Never normalize a
   canonical Study ID.
4. For every learner response, call `evaluatePreCoreUrgentSafety` before
   constructing `LearnerInput` or calling `AdaptiveTutorEngine.submit`. Keep
   the returned opaque permit; only a non-urgent result has one.
5. Call the frozen Tutor Core only when the urgent gateway permits it.
6. Pass the actual Core program/response/review through
   `adaptFrozenTutorCoreResult`, using injected frozen Core runtime validators
   and a governed skill registry. The adapter requires the event-bound
   pre-Core permit and rejects caller-constructed or copied permits. Only this
   adapter can register the immutable capability accepted by the Study
   projector.
7. Project only aggregate evidence with `projectTutorEventToStudy`.
   The canonical Session 1 schema registry is mandatory.
   `validateTutorBridgeEvent` is a low-level structural gate and never grants
   Tutor authority by itself.
8. Ask the Study Engine to produce pacing/review timing, then build a
   `StudyRecommendationV1`. The bridge never makes a pacing or calendar
   placement decision.
9. Build durable hook proposals with `buildOutboxEvents`.
10. Persist exact recovery state only through a `PersistenceSidecarPort`.
11. Treat every unsupported version, event, unknown field, or conflicting
    event ID as quarantine. Do not coerce or guess.

The bridge source barrel is:

```text
adaptive-tutor/study-engine/bridges/tutor-core/src/index.ts
```

## Non-negotiable call order

```text
transient learner text
  -> pre-Core urgent gateway
  -> exact package/event validation
  -> Tutor Core
  -> minimized Study evidence
  -> Study-owned recommendation
  -> durable outbox proposal
  -> review/calendar/parent hook proposals
```

Urgent gateway results that stop instruction must not call Tutor Core. A
proposed adult hook is not proof that an adult was contacted.

Production integration should use `executeStudyCoreBridgeCycle`. It evaluates
the exact transient learner text and invokes the supplied Core submission
callback only on a safe gateway result. Direct adaptation remains permit
gated for replay and integration tests.

Validated Core spoken turns and visual commands are exposed only as a
sanitized transient `learnerMedia` projection on the verified wrapper. They
are not copied into persistence-bound Study evidence.

## Validation commands

Use Node 22 and the repository package manager:

```powershell
node --experimental-strip-types --test adaptive-tutor/study-engine/tests/tutor-core-bridge
node node_modules/typescript/bin/tsc -p adaptive-tutor/study-engine/bridges/tutor-core/tsconfig.json --noEmit
```

The compatibility suite accepts `SESSION6_SOURCE_ROOT` to locate verified,
external extracted fixtures. Source ZIPs remain external and are never placed
in the bridge package.

## Storage boundary

This package defines ports only. It does not implement a database, durable
queue, calendar, parent dashboard, authentication, authorization, messaging,
or production persistence.
