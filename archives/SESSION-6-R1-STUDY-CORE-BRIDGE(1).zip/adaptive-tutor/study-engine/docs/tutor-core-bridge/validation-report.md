# Session 6-R1 Validation Report

Validation was performed on Node 22.23.1 with external authoritative
artifacts kept outside the repository package. Test-only dependencies were
installed in an isolated system temporary directory.

## Results

| Gate | Result | Evidence |
|---|---|---|
| Four authoritative archive checksums | PASS | 4/4 exact SHA-256 matches |
| Frozen Tutor Core manifest | PASS | 248/248 files, 0 mismatches, 0 unlisted files |
| Strict bridge TypeScript typecheck | PASS | 0 diagnostics |
| Owned bridge compatibility suite | PASS | 15 passed, 0 failed, 0 skipped |
| Frozen Tutor Core compatibility suite | PASS | 21 passed, 0 failed |
| Session 1 canonical contract suite | PASS | 7 files; 116 passed, 0 failed |
| Session 2 Study Engine suite | PASS | 21 files; 325 passed, 0 failed |
| Frozen Core static TypeScript build in isolated copy | PASS | declarations, JavaScript, source maps, prototype assets, and 14 schemas emitted |
| Frozen Core package validation in isolated copy | PASS | 19/19 checks |
| Independent frozen Core static-asset smoke | PASS | 7/7 required asset assertions |
| Sixteen machine-readable bridge traces | PASS | unique, complete, privacy-safe, deterministic |
| Final authority/safety/privacy audit | PASS | all eight concrete findings corrected and re-reviewed; no residual defect |
| Dependency audit | NOT APPLICABLE | bridge has no dependency manifest and no third-party runtime imports |
| Raw ZIP central-directory audit | PASS | forward slashes only; 0 absolute, traversal, duplicate, case-colliding, symlink, or out-of-ownership entries |
| Windows extraction and packaged manifest replay | PASS | all packaged manifest entries rehashed successfully |

Executable test total: **477 passed, 0 failed, 0 skipped**.

## Owned suite coverage

The owned suite exercises the actual frozen Core validators and graph
functions plus the actual Session 1 schema registry. It covers:

- source checksum and Core manifest verification;
- contract, runtime schema, and validation-result compatibility;
- canonical Study projection conformance;
- malformed, unknown, and unsupported-version quarantine;
- forged mastery and prerequisite-authority rejection;
- one-answer mastery prohibition and pacing/mastery separation;
- low-accuracy and approved-break safeguards;
- both urgent pre-Core stop categories;
- raw answer, transcript, identifier, credential, diagnosis, and adult-private
  exclusion;
- no-voice, missing-media, and unknown visual-command fallback;
- governed identifiers, phase/task mappings, and provisional-directive
  retirement;
- exact checkpoint acceptance, stale rejection, deduplication, and collision
  quarantine;
- outbox, review, calendar, parent-enforcement, retry, timezone, and provenance
  boundaries;
- all 16 required deterministic traces.

## Build smoke note

The frozen Core's provided `smoke-prototype.mjs` did not complete on Windows
because it passes a URL pathname directly to `fs.stat`; the resulting pathname
has a leading slash before the drive letter. The frozen file was not changed.
An independent smoke over the emitted assets passed the same seven content
assertions: title, module and stylesheet references, speech fallback,
non-human identity disclosure, reduced-motion support, and Jarvis styling.
This is an upstream cross-platform smoke-runner limitation, not a bridge
runtime or build failure.

## Reproduction

Set `SESSION6_SOURCE_ROOT` to a verified extraction root and set the four
`SESSION6_*_ZIP` variables to the authoritative external archives. Then run:

```powershell
node --experimental-strip-types --test adaptive-tutor/study-engine/tests/tutor-core-bridge/bridge.test.mjs
node node_modules/typescript/bin/tsc -p adaptive-tutor/study-engine/bridges/tutor-core/tsconfig.json --noEmit
```

The source verifier also accepts explicit `--tutor-zip`,
`--study-contracts-zip`, `--study-engine-zip`, `--reconciliation-zip`, and
`--tutor-root` arguments.
