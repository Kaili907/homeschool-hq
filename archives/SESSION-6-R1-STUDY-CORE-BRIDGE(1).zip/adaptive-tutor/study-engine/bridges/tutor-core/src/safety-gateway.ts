import {
  BRIDGE_CONTRACT_VERSION,
  type LearnerSafeProjectionV1,
  type SafetyCategory,
} from "./contracts.ts";
import { isRFC3339 } from "./validation.ts";

type UrgentSafetyCategory =
  | "self-harm-or-immediate-danger"
  | "abuse-or-neglect-disclosure";

interface UrgentRule {
  readonly ruleId: string;
  readonly category: UrgentSafetyCategory;
  readonly patterns: readonly RegExp[];
  readonly adultSummaryCode: string;
}

export interface PreCoreProcessingPermitV1 {
  /**
   * Opaque capability. Only `evaluatePreCoreUrgentSafety` can register a
   * usable permit; copied or caller-constructed objects are rejected.
   */
  readonly contract: "study-core-bridge.pre-core-permit.v1";
}

interface PermitContext {
  readonly eventId: string;
  readonly sessionId: string;
  readonly occurredAt: string;
}

const PRE_CORE_PERMITS = new WeakMap<object, PermitContext>();

/**
 * Bridge-owned stop rules for the two urgent categories declared by frozen
 * Tutor Core v0.2 but absent from its runtime safetyRules. This corpus is
 * intentionally small, deterministic, and replaceable only through review.
 */
const URGENT_RULES: readonly UrgentRule[] = [
  {
    ruleId: "bridge-urgent-self-harm-immediate-danger-v1",
    category: "self-harm-or-immediate-danger",
    patterns: [
      /\b(?:want|going|plan(?:ning)?|about)\s+to\s+(?:kill|hurt)\s+(?:myself|me)\b/i,
      /\b(?:kill myself|end my life|ending my life|suicide|self[- ]?harm)\b/i,
      /\b(?:i am|i'm|we are|we're)\s+(?:in immediate danger|not safe right now)\b/i,
      /\b(?:someone|they|he|she)\s+(?:has a weapon|is trying to hurt me)\b/i,
    ],
    adultSummaryCode: "urgent-learner-safety-support-needed",
  },
  {
    ruleId: "bridge-urgent-abuse-neglect-disclosure-v1",
    category: "abuse-or-neglect-disclosure",
    patterns: [
      /\b(?:an adult|my parent|my guardian|my teacher|someone at home)\s+(?:hits|hurts|touches|threatens)\s+me\b/i,
      /\b(?:i am|i'm|we are|we're)\s+(?:being abused|being neglected)\b/i,
      /\b(?:no one|nobody)\s+(?:feeds|takes care of)\s+me\b/i,
      /\b(?:unsafe|afraid)\s+(?:at home|with my caregiver)\b/i,
    ],
    adultSummaryCode: "urgent-safeguarding-review-needed",
  },
] as const;

export interface PreCoreGatewayContext {
  readonly eventId: string;
  readonly sessionId: string;
  readonly occurredAt: string;
}

export interface UrgentAdultReviewHookV1 {
  readonly contract: "study-core-bridge.adult-review-hook.v1";
  readonly contractVersion: typeof BRIDGE_CONTRACT_VERSION;
  readonly hookId: string;
  readonly idempotencyKey: string;
  readonly sessionId: string;
  readonly sourceEventId: string;
  readonly occurredAt: string;
  readonly canonicalStudyCategory: "student-support";
  readonly urgency: "urgent";
  readonly categories: readonly UrgentSafetyCategory[];
  readonly ruleIds: readonly string[];
  readonly summaryCodes: readonly string[];
  readonly deliveryStatus: "proposed-not-delivered";
  readonly matchedTextIncluded: false;
  readonly rawTextIncluded: false;
  readonly directIdentifiersIncluded: false;
}

export type PreCoreUrgentSafetyResult =
  | {
      readonly status: "continue-to-tutor-core";
      readonly continueToTutorCore: true;
      readonly rawTextStored: false;
      readonly permit: PreCoreProcessingPermitV1;
    }
  | {
      readonly status: "stop-for-urgent-adult-review";
      readonly continueToTutorCore: false;
      readonly mustStopAcademicFlow: true;
      readonly adultReviewRequired: true;
      readonly learner: LearnerSafeProjectionV1;
      readonly adultHook: UrgentAdultReviewHookV1;
      readonly rawTextStored: false;
      readonly matchedTextStored: false;
      readonly diagnosisMade: false;
    }
  | {
      readonly status: "stop-invalid-input";
      readonly continueToTutorCore: false;
      readonly mustStopAcademicFlow: true;
      readonly adultReviewRequired: true;
      readonly learner: LearnerSafeProjectionV1;
      readonly reasonCode: "urgent-gateway-input-limit" | "urgent-gateway-invalid-context";
      readonly rawTextStored: false;
      readonly matchedTextStored: false;
      readonly diagnosisMade: false;
    };

const URGENT_LEARNER_MESSAGE: LearnerSafeProjectionV1 = {
  messageCode: "lesson-paused-get-trusted-adult",
  message:
    "The lesson is paused. Please get a trusted adult who can help right now. You are not in trouble.",
  mayContinue: false,
  adultReviewPending: true,
};

function validOpaqueId(value: string): boolean {
  return /^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$/.test(value);
}

/**
 * Must run on transient learner text before AdaptiveTutorEngine.submit().
 * The raw string is neither returned nor placed in any hook or projection.
 */
export function evaluatePreCoreUrgentSafety(
  transientLearnerText: string,
  context: PreCoreGatewayContext,
): PreCoreUrgentSafetyResult {
  if (
    !validOpaqueId(context.eventId) ||
    !validOpaqueId(context.sessionId) ||
    !isRFC3339(context.occurredAt)
  ) {
    return {
      status: "stop-invalid-input",
      continueToTutorCore: false,
      mustStopAcademicFlow: true,
      adultReviewRequired: true,
      learner: URGENT_LEARNER_MESSAGE,
      reasonCode: "urgent-gateway-invalid-context",
      rawTextStored: false,
      matchedTextStored: false,
      diagnosisMade: false,
    };
  }
  if (
    typeof transientLearnerText !== "string" ||
    transientLearnerText.length > 4_000
  ) {
    return {
      status: "stop-invalid-input",
      continueToTutorCore: false,
      mustStopAcademicFlow: true,
      adultReviewRequired: true,
      learner: URGENT_LEARNER_MESSAGE,
      reasonCode: "urgent-gateway-input-limit",
      rawTextStored: false,
      matchedTextStored: false,
      diagnosisMade: false,
    };
  }
  const matchedRules = URGENT_RULES.filter((rule) =>
    rule.patterns.some((pattern) => pattern.test(transientLearnerText)),
  );
  if (matchedRules.length === 0) {
    const permit = Object.freeze({
      contract: "study-core-bridge.pre-core-permit.v1" as const,
    });
    PRE_CORE_PERMITS.set(permit, {
      eventId: context.eventId,
      sessionId: context.sessionId,
      occurredAt: context.occurredAt,
    });
    return {
      status: "continue-to-tutor-core",
      continueToTutorCore: true,
      rawTextStored: false,
      permit,
    };
  }
  const categories = [
    ...new Set(matchedRules.map((rule) => rule.category)),
  ] as UrgentSafetyCategory[];
  return {
    status: "stop-for-urgent-adult-review",
    continueToTutorCore: false,
    mustStopAcademicFlow: true,
    adultReviewRequired: true,
    learner: URGENT_LEARNER_MESSAGE,
    adultHook: {
      contract: "study-core-bridge.adult-review-hook.v1",
      contractVersion: BRIDGE_CONTRACT_VERSION,
      hookId: `adult-review-${context.eventId}`,
      idempotencyKey: `urgent-safety:${context.eventId}:v1`,
      sessionId: context.sessionId,
      sourceEventId: context.eventId,
      occurredAt: context.occurredAt,
      canonicalStudyCategory: "student-support",
      urgency: "urgent",
      categories,
      ruleIds: matchedRules.map((rule) => rule.ruleId),
      summaryCodes: matchedRules.map((rule) => rule.adultSummaryCode),
      deliveryStatus: "proposed-not-delivered",
      matchedTextIncluded: false,
      rawTextIncluded: false,
      directIdentifiersIncluded: false,
    },
    rawTextStored: false,
    matchedTextStored: false,
    diagnosisMade: false,
  };
}

export function getBridgeUrgentCategoryCoverage(): readonly SafetyCategory[] {
  return URGENT_RULES.map((rule) => rule.category);
}

export function isValidPreCoreProcessingPermit(
  permit: PreCoreProcessingPermitV1,
  context: PermitContext,
): boolean {
  const registered = PRE_CORE_PERMITS.get(permit);
  return (
    registered !== undefined &&
    registered.eventId === context.eventId &&
    registered.sessionId === context.sessionId &&
    registered.occurredAt === context.occurredAt
  );
}
