$ErrorActionPreference = 'Stop'

$packageRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$releaseDirectory = Join-Path $packageRoot 'releases'
$stageDirectory = Join-Path $packageRoot '.release-stage'
$archiveName = 'manuel-academy-adaptive-english-v0.2.0.zip'
$archivePath = Join-Path $releaseDirectory $archiveName
$checksumPath = "$archivePath.sha256"

if (-not $stageDirectory.StartsWith($packageRoot, [System.StringComparison]::OrdinalIgnoreCase) -or
    ([System.IO.Path]::GetFileName($stageDirectory) -ne '.release-stage')) {
  throw 'Refusing to use an unexpected release staging directory.'
}

if (Test-Path -LiteralPath $stageDirectory) {
  Remove-Item -LiteralPath $stageDirectory -Recurse -Force
}
New-Item -ItemType Directory -Path $stageDirectory | Out-Null
New-Item -ItemType Directory -Path $releaseDirectory -Force | Out-Null

$excludedRoots = @('node_modules', 'releases', '.build-dist', '.test-dist', '.validation-dist', '.release-stage')
$sourceFiles = @(
  Get-ChildItem -LiteralPath $packageRoot -Force | Where-Object { $excludedRoots -notcontains $_.Name } | ForEach-Object {
    if (-not $_.PSIsContainer) {
      $_
    } else {
      Get-ChildItem -LiteralPath $_.FullName -File -Recurse
    }
  }
)

foreach ($sourceFile in $sourceFiles) {
  $relative = $sourceFile.FullName.Substring($packageRoot.Length).TrimStart([System.IO.Path]::DirectorySeparatorChar)
  $target = Join-Path $stageDirectory $relative
  $targetDirectory = Split-Path -Parent $target
  New-Item -ItemType Directory -Path $targetDirectory -Force | Out-Null
  Copy-Item -LiteralPath $sourceFile.FullName -Destination $target
}

if (Test-Path -LiteralPath $archivePath) {
  Remove-Item -LiteralPath $archivePath -Force
}
Compress-Archive -Path (Join-Path $stageDirectory '*') -DestinationPath $archivePath -CompressionLevel Optimal

Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::OpenRead($archivePath)
try {
  $entryNames = @($zip.Entries | Where-Object { $_.Name } | ForEach-Object { $_.FullName.Replace('/', '\') })
  foreach ($entry in $zip.Entries | Where-Object { $_.Name }) {
    $stream = $entry.Open()
    try {
      $buffer = New-Object byte[] 81920
      while ($stream.Read($buffer, 0, $buffer.Length) -gt 0) { }
    } finally {
      $stream.Dispose()
    }
  }
} finally {
  $zip.Dispose()
}

$expectedNames = @($sourceFiles | ForEach-Object { $_.FullName.Substring($packageRoot.Length).TrimStart([System.IO.Path]::DirectorySeparatorChar) })
$missing = @($expectedNames | Where-Object { $_ -notin $entryNames })
if ($missing.Count -gt 0 -or $entryNames.Count -ne $expectedNames.Count) {
  throw "ZIP integrity mismatch. Missing: $($missing -join ', '); entries: $($entryNames.Count); expected: $($expectedNames.Count)"
}

$checksum = (Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant()
[System.IO.File]::WriteAllText($checksumPath, "$checksum  $archiveName`n", [System.Text.UTF8Encoding]::new($false))
Remove-Item -LiteralPath $stageDirectory -Recurse -Force

Write-Output "ZIP=$archivePath"
Write-Output "SHA256=$checksum"
Write-Output "ENTRIES=$($entryNames.Count)"
Write-Output 'ZIP_INTEGRITY=PASS'
Write-Output 'CHECKSUM_VERIFICATION=PASS'
